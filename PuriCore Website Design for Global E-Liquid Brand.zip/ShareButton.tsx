// PuriCore ShareButton — Gold brand identity, warm dark theme
// Floating share menu with WhatsApp, Twitter/X, Facebook, and Copy Link

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Share2, Copy, Check, X } from 'lucide-react';

interface ShareButtonProps {
  productName: string;
  productId: string;
  /** Optional extra class for the trigger button wrapper */
  className?: string;
  /** Size variant */
  size?: 'sm' | 'md';
}

function TwitterXIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function FacebookIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  );
}

function WhatsAppIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  );
}

export default function ShareButton({ productName, productId, className = '', size = 'md' }: ShareButtonProps) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const productUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/flavors/${productId}`
    : `/flavors/${productId}`;

  const shareText = `Check out ${productName} by PuriCore — premium e-liquid flavors crafted for connoisseurs.`;

  const platforms = [
    {
      label: 'WhatsApp',
      icon: <WhatsAppIcon size={15} />,
      color: '#25D366',
      bg: 'rgba(37,211,102,0.10)',
      border: 'rgba(37,211,102,0.22)',
      href: `https://wa.me/?text=${encodeURIComponent(`${shareText}\n${productUrl}`)}`,
    },
    {
      label: 'Twitter / X',
      icon: <TwitterXIcon size={15} />,
      color: '#e7e9ea',
      bg: 'rgba(231,233,234,0.08)',
      border: 'rgba(231,233,234,0.15)',
      href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(productUrl)}`,
    },
    {
      label: 'Facebook',
      icon: <FacebookIcon size={15} />,
      color: '#1877F2',
      bg: 'rgba(24,119,242,0.10)',
      border: 'rgba(24,119,242,0.22)',
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(productUrl)}`,
    },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(productUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback: select input
    }
  };

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const btnSize = size === 'sm' ? 'w-7 h-7' : 'w-8 h-8';
  const iconSize = size === 'sm' ? 13 : 15;

  return (
    <div ref={ref} className={`relative ${className}`}>
      {/* Trigger */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.92 }}
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpen((v) => !v); }}
        className={`${btnSize} rounded-full flex items-center justify-center transition-all`}
        style={{
          background: open ? 'oklch(0.76 0.12 75 / 0.20)' : 'oklch(0 0 0 / 0.45)',
          border: `1px solid ${open ? 'oklch(0.76 0.12 75 / 0.50)' : 'oklch(1 0 0 / 0.15)'}`,
          backdropFilter: 'blur(8px)',
          color: open ? 'oklch(0.82 0.10 78)' : 'rgba(255,255,255,0.75)',
        }}
        title="Share"
        aria-label="Share product"
      >
        <Share2 size={iconSize} />
      </motion.button>

      {/* Popover menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.88, y: 6 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 6 }}
            transition={{ type: 'spring', stiffness: 380, damping: 28 }}
            className="absolute right-0 bottom-full mb-2 z-50 min-w-[190px] rounded-2xl overflow-hidden shadow-2xl"
            style={{
              background: 'oklch(0.14 0.04 38)',
              border: '1px solid oklch(0.76 0.12 75 / 0.20)',
              boxShadow: '0 8px 32px oklch(0 0 0 / 0.55), 0 0 0 1px oklch(0.76 0.12 75 / 0.08)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: 'oklch(1 0 0 / 0.07)' }}>
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.76 0.12 75)' }}>
                Share
              </span>
              <button
                onClick={() => setOpen(false)}
                className="text-white/30 hover:text-white/70 transition-colors"
              >
                <X size={12} />
              </button>
            </div>

            {/* Platform buttons */}
            <div className="p-2 space-y-1">
              {platforms.map((p) => (
                <motion.a
                  key={p.label}
                  href={p.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ x: 3 }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all cursor-pointer"
                  style={{ background: p.bg, border: `1px solid ${p.border}` }}
                  onClick={() => setOpen(false)}
                >
                  <span style={{ color: p.color }}>{p.icon}</span>
                  <span className="text-sm font-medium text-white/80">{p.label}</span>
                </motion.a>
              ))}

              {/* Copy link */}
              <motion.button
                whileHover={{ x: 3 }}
                onClick={handleCopy}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all"
                style={{
                  background: copied ? 'rgba(37,211,102,0.10)' : 'oklch(1 0 0 / 0.04)',
                  border: `1px solid ${copied ? 'rgba(37,211,102,0.25)' : 'oklch(1 0 0 / 0.08)'}`,
                }}
              >
                {copied ? (
                  <Check size={15} style={{ color: '#25D366' }} />
                ) : (
                  <Copy size={15} className="text-white/50" />
                )}
                <span className="text-sm font-medium" style={{ color: copied ? '#25D366' : 'rgba(255,255,255,0.7)' }}>
                  {copied ? 'Copied!' : 'Copy Link'}
                </span>
              </motion.button>
            </div>

            {/* Gold shimmer line at top */}
            <div
              className="absolute top-0 left-0 right-0 h-[1.5px]"
              style={{ background: 'linear-gradient(90deg, transparent, oklch(0.76 0.12 75 / 0.6), transparent)' }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
