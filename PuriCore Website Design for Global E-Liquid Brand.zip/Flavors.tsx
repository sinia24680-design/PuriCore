// PuriCore Flavors Overview Page — "Tropical Drift" design
// Showcases all flavor categories with clickable references

import { useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowRight, Droplets } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { fruitProducts, dessertProducts, tobaccoProducts, drinkProducts, Product, categoryColors } from '@/lib/products';

const FRUIT_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-label-fvUU5KTK5HuhJCyPHevnCt.webp';
const DESSERT_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-label-BSFWK9cJZD6UKCeDJyFRq7.webp';
const TOBACCO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-label-V6ULjKJATUtRoGATM5atx3.webp';
const DRINK_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-drink-label-eySVoLDhmpgTwbbD6JdwaD.webp';

function FlavorRow({ product }: { product: Product }) {
  const colors = categoryColors[product.category];
  return (
    <Link href={`/flavors/${product.id}`}>
      <motion.div
        whileHover={{ x: 4 }}
        className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-all cursor-pointer group"
      >
        <div className="w-14 h-14 rounded-xl overflow-hidden bg-[oklch(0.14_0.03_240)] shrink-0">
          <img src={product.image} alt={product.name} className="w-full h-full object-contain p-1" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-medium text-sm truncate group-hover:text-orange-300 transition-colors">
            {product.name}
          </p>
          <div className="flex gap-1 mt-1">
            {product.flavorNotes.slice(0, 2).map((note) => (
              <span key={note} className="text-white/30 text-xs">{note}</span>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }, (_, i) => (
              <div key={i} className={`w-1.5 h-1.5 rounded-full ${i < product.intensity ? 'bg-orange-500' : 'bg-white/10'}`} />
            ))}
          </div>
          <ArrowRight size={14} className="text-white/20 group-hover:text-orange-400 transition-colors" />
        </div>
      </motion.div>
    </Link>
  );
}

function CategorySection({
  title,
  description,
  image,
  products,
  href,
  accentColor,
  flavorsLabel,
}: {
  title: string;
  description: string;
  image: string;
  products: Product[];
  href: string;
  accentColor: string;
  flavorsLabel: string;
}) {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start"
    >
      {/* Category Banner */}
      <div className="relative rounded-3xl overflow-hidden h-80 group">
        <img src={image} alt={title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h2 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            {title}
          </h2>
          <p className="text-white/70 mb-4">{description}</p>
          <Link href={href}>
            <button className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-sm font-semibold transition-all ${accentColor}`}>
              {t.products.viewAll}
              <ArrowRight size={16} />
            </button>
          </Link>
        </div>
      </div>

      {/* Flavor List */}
      <div
        className="rounded-3xl p-4 max-h-80 overflow-y-auto"
        style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
      >
        <div className="flex items-center gap-2 px-3 mb-3">
          <Droplets size={16} className="text-white/30" />
          <span className="text-white/40 text-xs uppercase tracking-wider">{products.length} {flavorsLabel}</span>
        </div>
        {products.map((product) => (
          <FlavorRow key={product.id} product={product} />
        ))}
      </div>
    </motion.div>
  );
}

export default function Flavors() {
  const { t, language } = useLanguage();

  const pageContent = {
    zh: { title: '探索所有口味', subtitle: '四大独特口味系列，每款都由精心调制。找到您的完美搭配。', flavors: '款口味' },
    en: { title: 'Explore All Flavors', subtitle: 'Four distinct flavor families, each crafted with precision and passion. Find your perfect match.', flavors: 'flavors' },
    ar: { title: 'استكشف جميع النكهات', subtitle: 'أربع عائلات نكهات متميزة، كل منها مصنوعة بدقة وشغف. اعثر على تطابقك المثالي.', flavors: 'نكهة' },
    ru: { title: 'Изучите все вкусы', subtitle: 'Четыре уникальных вкусовых семьи, каждая создана с точностью и страстью. Найдите своё идеальное сочетание.', flavors: 'вкусов' },
    ko: { title: '전체 맛 탐색', subtitle: '네 가지 독특한 맛 가족, 각각 정밀함과 열정으로 제조되었습니다. 완벽한 매치를 찾아보세요.', flavors: '가지 맛' },
  };
  const pc = pageContent[language as keyof typeof pageContent] || pageContent.zh;

  return (
    <div className="min-h-screen py-12">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-14"
        >
          <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-2">
            {t.nav.flavors}
          </p>
          <h1 className="text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            {pc.title}
          </h1>
          <p className="text-white/50 text-lg max-w-2xl">
            {pc.subtitle}
          </p>
        </motion.div>

        {/* Category Sections */}
        <div className="space-y-16">
          <CategorySection
            title={t.categories.fruit}
            description={t.categories.fruitDesc}
            image={FRUIT_IMG}
            products={fruitProducts}
            href="/products?category=fruit"
            accentColor="bg-emerald-500 hover:bg-emerald-400"
            flavorsLabel={pc.flavors}
          />
          <CategorySection
            title={t.categories.dessert}
            description={t.categories.dessertDesc}
            image={DESSERT_IMG}
            products={dessertProducts}
            href="/products?category=dessert"
            accentColor="bg-amber-500 hover:bg-amber-400"
            flavorsLabel={pc.flavors}
          />
          <CategorySection
            title={t.categories.tobacco}
            description={t.categories.tobaccoDesc}
            image={TOBACCO_IMG}
            products={tobaccoProducts}
            href="/products?category=tobacco"
            accentColor="bg-blue-500 hover:bg-blue-400"
            flavorsLabel={pc.flavors}
          />
          <CategorySection
            title={t.categories.drink}
            description={t.categories.drinkDesc}
            image={DRINK_IMG}
            products={drinkProducts}
            href="/products?category=drink"
            accentColor="bg-cyan-500 hover:bg-cyan-400"
            flavorsLabel={pc.flavors}
          />
        </div>
      </div>
    </div>
  );
}
