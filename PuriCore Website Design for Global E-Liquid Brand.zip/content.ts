
export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  category: 'industry' | 'flavors' | 'lifestyle' | 'science';
  date: string;
  readTime: number;
  image: string;
  tags: string[];
}

export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  location: string;
  image: string;
  challenge: string;
  solution: string;
  result: string;
  metrics: { label: string; value: string }[];
  tags: string[];
}

export const blogPosts: BlogPost[] = [
  {
    id: 'art-of-flavor-crafting',
    title: 'The Art of Flavor Crafting: How PuriCore Develops New Tastes',
    excerpt: 'Behind every bottle of PuriCore e-liquid lies months of research, testing, and refinement. Our master flavorists share their creative process.',
    content: `Creating a new e-liquid flavor is part science, part art. At PuriCore, our team of master flavorists begins each project with a concept — a memory, a destination, a sensation. From there, the process involves hundreds of iterations before a flavor earns its place in our lineup.

The journey starts with sourcing. We work exclusively with food-grade flavor concentrates from certified suppliers across Europe, North America, and Asia. Each ingredient undergoes rigorous purity testing before it enters our facility.

Next comes the blending phase. Our flavorists work in small batches, adjusting ratios by fractions of a percentage until the profile achieves the perfect balance. For our Caramel Macchiato, for example, we went through 47 iterations before finding the exact espresso-to-caramel ratio that captures that café experience.

Finally, every flavor undergoes a panel review where our team evaluates it across multiple dimensions: initial hit, mid-note development, and the lingering finish. Only flavors that score above 8.5 out of 10 across all three dimensions make it to production.`,
    author: {
      name: 'Dr. Sarah Chen',
      role: 'Head Flavorist',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    },
    category: 'flavors',
    date: 'March 10, 2025',
    readTime: 8,
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=450&fit=crop',
    tags: ['Flavor Development', 'Craftsmanship', 'Behind the Scenes'],
  },
  {
    id: 'global-vaping-trends-2025',
    title: 'Global Vaping Trends 2025: What the Data Tells Us',
    excerpt: 'An analysis of emerging markets, flavor preferences, and regulatory landscapes shaping the future of the vaping industry.',
    content: `The global vaping market continues to evolve at a remarkable pace. In 2025, we are seeing several key trends emerge that are reshaping how brands like PuriCore approach product development and market strategy.

**Asia-Pacific Dominance**: The APAC region now accounts for 38% of global e-liquid consumption, with South Korea and Japan leading in premium segment growth. Korean consumers in particular show a strong preference for complex, layered flavors — a trend that directly influenced our recent Matcha Latte and Brown Sugar Bubble Tea releases.

**The Premiumization Wave**: Across all markets, consumers are trading up. The premium segment (products priced above $15 per 30ml) grew 42% year-over-year, while the value segment contracted by 8%. This reflects a broader consumer shift toward quality over quantity.

**Regulatory Convergence**: As regulations mature in key markets, we are seeing a convergence toward stricter ingredient disclosure requirements. PuriCore has been ahead of this curve, maintaining full ingredient transparency since our founding.`,
    author: {
      name: 'Marcus Okafor',
      role: 'Market Research Director',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    },
    category: 'industry',
    date: 'February 28, 2025',
    readTime: 12,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=450&fit=crop',
    tags: ['Market Trends', 'Industry Analysis', '2025'],
  },
  {
    id: 'nicotine-salt-science',
    title: 'The Science Behind Nicotine Salts: A Deep Dive',