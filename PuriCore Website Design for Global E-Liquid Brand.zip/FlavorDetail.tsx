// PuriCore Flavor Detail Page — "Tropical Drift" design
// Clickable flavor note references filter related products by matching notes
import { useState } from 'react';
import { Link, useParams, useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ShoppingCart, Star, Zap, Info, Tag, ChevronRight, Copy, Check } from 'lucide-react';
import { allProducts, categoryColors } from '@/lib/products';
import { useLanguage } from '@/contexts/LanguageContext';
import ProductCard from '@/components/ProductCard';
import ShareButton from '@/components/ShareButton';
import { toast } from 'sonner';

export default function FlavorDetail() {
  const { id } = useParams<{ id: string }>();
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();

  const localText = {
    zh: {
      notFound: '未找到该口味',
      backToProducts: '返回产品',
      category: '类别',
      moreFlavors: '更多',
      addedToCart: '已加入购物车！',
      comingSoon: '功能即将推出，敬请期待。',
      flavorReference: '口味参考',
      flavorReferenceDesc: '点击标签探索相似口味',
      similarFlavors: '相似口味',
      noSimilar: '暂无相似口味',
      inquire: '立即询价',
      specs: '产品规格',
      vgPg: '产品编号',
      nicotineLevel: '尼古丁含量',
      categoryLabel: '类别',
      relatedTitle: '同类推荐',
      copiedToast: '编号已复制！',
      clickToCopy: '点击复制编号',
    },
    en: {
      notFound: 'Flavor not found',
      backToProducts: 'Back to Products',
      category: 'Category',
      moreFlavors: 'More',
      addedToCart: 'Added to cart!',
      comingSoon: 'Feature coming soon — stay tuned.',
      flavorReference: 'Flavor Reference',
      flavorReferenceDesc: 'Click a tag to explore similar flavors',
      similarFlavors: 'Similar Flavors',
      noSimilar: 'No similar flavors found',
      inquire: 'Inquire Now',
      specs: 'Product Specs',
      vgPg: 'Product ID',
      nicotineLevel: 'Nicotine Level',
      categoryLabel: 'Category',
      relatedTitle: 'You May Also Like',
      copiedToast: 'Product ID copied!',
      clickToCopy: 'Click to copy',
    },
    ar: {
      notFound: 'النكهة غير موجودة',
      backToProducts: 'العودة إلى المنتجات',
      category: 'الفئة',
      moreFlavors: 'المزيد من',
      addedToCart: 'تمت الإضافة إلى السلة!',
      comingSoon: 'قريباً متاح.',
      flavorReference: 'مرجع النكهة',
      flavorReferenceDesc: 'انقر على علامة لاستكشاف نكهات مماثلة',
      similarFlavors: 'نكهات مماثلة',
      noSimilar: 'لا توجد نكهات مماثلة',
      inquire: 'استفسر الآن',
      specs: 'مواصفات المنتج',
      vgPg: 'معرف المنتج',
      nicotineLevel: 'مستوى النيكوتين',
      categoryLabel: 'الفئة',
      relatedTitle: 'قد يعجبك أيضاً',
      copiedToast: 'تم نسخ المعرف!',
      clickToCopy: 'انقر للنسخ',
    },
    ru: {
      notFound: 'Вкус не найден',
      backToProducts: 'Назад к продуктам',
      category: 'Категория',
      moreFlavors: 'Ещё',
      addedToCart: 'Добавлено в корзину!',
      comingSoon: 'Функция скоро появится.',
      flavorReference: 'Ссылки на вкус',
      flavorReferenceDesc: 'Нажмите тег для похожих вкусов',
      similarFlavors: 'Похожие вкусы',
      noSimilar: 'Похожих вкусов не найдено',
      inquire: 'Запросить сейчас',
      specs: 'Характеристики',
      vgPg: 'ID продукта',
      nicotineLevel: 'Уровень никотина',
      categoryLabel: 'Категория',
      relatedTitle: 'Вам также понравится',
      copiedToast: 'ID скопирован!',
      clickToCopy: 'Нажмите для копирования',
    },
    ko: {
      notFound: '맛을 찾을 수 없습니다',
      backToProducts: '제품으로 돌아가기',
      category: '카테고리',
      moreFlavors: '더 보기',
      addedToCart: '장바구니에 추가되었습니다!',
      comingSoon: '곧 출시 예정입니다.',
      flavorReference: '향미 참조',
      flavorReferenceDesc: '태그를 클릭하여 유사한 향미 탐색',
      similarFlavors: '유사한 향미',
      noSimilar: '유사한 향미가 없습니다',
      inquire: '지금 문의',
      specs: '제품 사양',
      vgPg: '제품 ID',
      nicotineLevel: '니코틴 함량',
      categoryLabel: '카테고리',
      relatedTitle: '이런 제품도 좋아하실 수 있어요',
      copiedToast: 'ID가 복사되었습니다!',
      clickToCopy: '클릭하여 복사',
    },
  };
  const lc = localText[language as keyof typeof localText] || localText.zh;

  const [selectedNicotine, setSelectedNicotine] = useState(0);
  const [activeNote, setActiveNote] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const product = allProducts.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔍</div>
          <h2 className="text-white text-2xl font-bold mb-4">{lc.notFound}</h2>
          <Link href="/products">
            <button className="px-6 py-3 rounded-xl bg-orange-500 text-white font-semibold">
              {lc.backToProducts}
            </button>
          </Link>
        </div>
      </div>
    );
  }

  const colors = categoryColors[product.category];

  // Related products from same category (excluding current)
  const relatedProducts = allProducts
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  // Products that share the active flavor note (clickable reference)
  const noteMatchedProducts = activeNote
    ? allProducts
        .filter((p) => p.id !== product.id && p.flavorNotes.some(n => n.toLowerCase() === activeNote.toLowerCase()))
        .slice(0, 6)
    : [];

  const handleInquire = () => {
    const nicotine = product.nicotineOptions[selectedNicotine] ?? '';
    const msg = encodeURIComponent(
      `Hello PuriCore! I'm interested in ordering:\n\nProduct: ${product.name}\nNicotine: ${nicotine}\nCategory: ${product.category}\n\nPlease provide pricing and availability. Thank you!`
    );
    window.open(`https://wa.me/8619820224886?text=${msg}`, '_blank', 'noopener,noreferrer');
  };

  const handleNoteClick = (note: string) => {
    if (activeNote === note) {
      setActiveNote(null);
    } else {
      setActiveNote(note);
    }
  };

  const categoryBannerImages: Record<string, string> = {
    fruit: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-category-ErbibXEuBcvXhQNoLRpEih.webp',
    dessert: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-category-gm9WfuHKAjo7dsYpSTQ2wW.webp',
    tobacco: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-category-2cwJiMsJJKQ9PvNv9LUEAf.webp',
  };

  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={categoryBannerImages[product.category]}
          alt={product.category}
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[oklch(0.13_0.025_40)]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.13_0.025_40/0.5)] to-transparent" />
      </div>

      <div className="container -mt-12 relative z-10 pb-20">
        {/* Back Button */}
        <Link href="/products">
          <button className="flex items-center gap-2 text-white/50 hover:text-white text-sm mb-8 transition-colors">
            <ArrowLeft size={16} />
            {lc.backToProducts}
          </button>
        </Link>

        {/* Product Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div
              className="rounded-3xl overflow-hidden aspect-square flex items-center justify-center p-8"
              style={{ background: 'linear-gradient(135deg, #1A2B6B 0%, #0F1F5C 60%, #162055 100%)', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-contain"
                style={{ animation: 'float 3s ease-in-out infinite' }}
              />
            </div>

            {/* Category Badge */}
            <div className={`absolute top-6 left-6 px-3 py-1.5 rounded-full text-sm font-semibold ${colors.bg} ${colors.text} border ${colors.border}`}>
              {t.categories[product.category as keyof typeof t.categories]}
            </div>

            {product.featured && (
              <div className="absolute top-6 right-6 px-3 py-1.5 rounded-full bg-orange-500 text-white text-sm font-semibold flex items-center gap-1.5">
                <Zap size={14} className="fill-current" />
                {t.products.featured}
              </div>
            )}
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex flex-col justify-center"
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
              {product.name}
            </h1>

            <p className="text-white/60 text-lg leading-relaxed mb-8">
              {product.description}
            </p>

            {/* ── Flavor Reference (Clickable Tags) ── */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Tag size={14} className="text-[oklch(0.76_0.12_75)]" />
                <p className="text-white/40 text-xs uppercase tracking-wider">{lc.flavorReference}</p>
                <span className="text-white/25 text-xs">— {lc.flavorReferenceDesc}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.flavorNotes.map((note) => (
                  <motion.button
                    key={note}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleNoteClick(note)}
                    className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all cursor-pointer ${
                      activeNote === note
                        ? 'bg-orange-500 text-white border-orange-500 shadow-lg shadow-orange-500/30'
                        : `${colors.bg} ${colors.text} ${colors.border} hover:opacity-80`
                    }`}
                  >
                    {note}
                    {activeNote === note && <span className="ml-1.5 text-xs opacity-75">✕</span>}
                  </motion.button>
                ))}
              </div>

              {/* Note-matched products panel */}
              <AnimatePresence>
                {activeNote && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="mt-4 p-4 rounded-2xl border border-white/10" style={{ background: 'oklch(0.17 0.03 38)' }}>
                      <p className="text-white/50 text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <ChevronRight size={12} className="text-[oklch(0.76_0.12_75)]" />
                        {lc.similarFlavors} — <span className={`${colors.text} font-semibold`}>{activeNote}</span>
                        <span className="text-white/30">({noteMatchedProducts.length})</span>
                      </p>
                      {noteMatchedProducts.length > 0 ? (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {noteMatchedProducts.map((p) => (
                            <Link key={p.id} href={`/flavors/${p.id}`}>
                              <motion.div
                                whileHover={{ scale: 1.03 }}
                                className="flex items-center gap-2 p-2 rounded-xl cursor-pointer transition-all hover:bg-white/5"
                              >
                                <img
                                  src={p.image}
                                  alt={p.name}
                                  className="w-10 h-10 object-contain rounded-lg flex-shrink-0"
                                  style={{ background: 'oklch(0.20 0.04 240)' }}
                                />
                                <span className="text-white/70 text-xs font-medium leading-tight line-clamp-2 hover:text-white transition-colors">
                                  {p.name}
                                </span>
                              </motion.div>
                            </Link>
                          ))}
                        </div>
                      ) : (
                        <p className="text-white/30 text-sm">{lc.noSimilar}</p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Intensity */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <p className="text-white/40 text-xs uppercase tracking-wider">{t.products.intensity}</p>
                <span className="text-[oklch(0.76_0.12_75)] text-sm font-semibold">{product.intensity}/5</span>
              </div>
              <div className="flex gap-2">
                {Array.from({ length: 5 }, (_, i) => (
                  <div
                    key={i}
                    className={`h-2 flex-1 rounded-full transition-all ${
                      i < product.intensity ? 'bg-gradient-to-r from-[oklch(0.68_0.24_42)] to-[oklch(0.76_0.12_75)]' : 'bg-white/10'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 gap-3 mb-8">
              <div
                className="p-4 rounded-xl bg-white/5 border border-white/5 text-center cursor-pointer group/id hover:bg-white/8 transition-all relative"
                onClick={() => {
                  navigator.clipboard.writeText(product.vgPgRatio);
                  setCopiedId(true);
                  toast.success(lc.copiedToast || 'Copied!');
                  setTimeout(() => setCopiedId(false), 2000);
                }}
                title={lc.clickToCopy || 'Click to copy'}
              >
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">{lc.vgPg}</p>
                <div className="flex items-center justify-center gap-1.5">
                  <p className="text-white font-bold text-lg">{product.vgPgRatio}</p>
                  {copiedId ? (
                    <Check size={14} className="text-green-400 shrink-0" />
                  ) : (
                    <Copy size={14} className="text-white/30 group-hover/id:text-white/60 transition-colors shrink-0" />
                  )}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-center">
                <p className="text-white/40 text-xs uppercase tracking-wider mb-1">{lc.categoryLabel}</p>
                <p className={`font-bold text-lg capitalize ${colors.text}`}>
                  {t.categories[product.category as keyof typeof t.categories]}
                </p>
              </div>
            </div>

            {/* Nicotine Selector */}
            <div className="mb-8">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-3">{lc.nicotineLevel}</p>
              <div className="flex gap-2 flex-wrap">
                {product.nicotineOptions.map((nic, i) => (
                  <button
                    key={nic}
                    onClick={() => setSelectedNicotine(i)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      selectedNicotine === i
                        ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'
                        : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white border border-white/5'
                    }`}
                  >
                    {nic}
                  </button>
                ))}
              </div>
            </div>

            {/* Inquire + Share row */}
            <div className="flex gap-3 items-stretch">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleInquire}
                className="flex-1 flex items-center justify-center gap-3 py-4 rounded-2xl bg-gradient-to-r from-[oklch(0.68_0.24_42)] to-[oklch(0.76_0.12_75)] text-white font-bold text-lg shadow-xl hover:shadow-[oklch(0.76_0.12_75/0.30)] transition-all"
              >
                <ShoppingCart size={22} />
                {lc.inquire} — {product.nicotineOptions[selectedNicotine]}
              </motion.button>
              {/* Share button */}
              <div className="flex items-center">
                <ShareButton productName={product.name} productId={product.id} size="md" />
              </div>
            </div>

            {/* Info Note */}
            <div className="mt-4 flex items-start gap-2 p-3 rounded-xl bg-white/3 border border-white/5">
              <Info size={14} className="text-white/30 mt-0.5 shrink-0" />
              <p className="text-white/30 text-xs leading-relaxed">
                {t.footer.warning}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
              {lc.relatedTitle}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
