import re

filepath = '/home/ubuntu/puricore/client/src/lib/products.ts'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

def fix_name(match):
    prefix = match.group(1)
    name = match.group(2)
    suffix = match.group(3)
    
    # Fix PuriCore brand name (case-insensitive)
    name = re.sub(r'\bPuricore\b', 'PuriCore', name, flags=re.IGNORECASE)
    
    # Fix RY4 (should be all caps)
    name = re.sub(r'\bRy4\b', 'RY4', name, flags=re.IGNORECASE)
    
    # Fix LAPOSA (brand name, keep caps)
    name = re.sub(r'\bLaposa\b', 'LAPOSA', name)
    
    # Lowercase common English prepositions/conjunctions/articles (but not at start)
    small_words = ['And', 'Of', 'The', 'No', 'In', 'On', 'At', 'To', 'For', 'A', 'An']
    words = name.split(' ')
    for i in range(1, len(words)):  # skip first word
        if words[i] in small_words:
            words[i] = words[i].lower()
    name = ' '.join(words)
    
    return prefix + name + suffix

pattern = r"(name:\s*['\"])([^'\"]+)(['\"])"
new_content = re.sub(pattern, fix_name, content)

# Show changes
old_names = re.findall(r"name:\s*['\"]([^'\"]+)['\"]", content)
new_names = re.findall(r"name:\s*['\"]([^'\"]+)['\"]", new_content)

changed = 0
for old, new in zip(old_names, new_names):
    if old != new:
        changed += 1
        print(f"  {old} -> {new}")

print(f"\nTotal products: {len(old_names)}, Fixed: {changed}")

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("File updated successfully.")
