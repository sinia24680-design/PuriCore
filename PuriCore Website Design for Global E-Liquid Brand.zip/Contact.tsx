// PuriCore Contact Page — "Tropical Drift" design
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, MapPin, Phone, Send, MessageSquare, MessageCircle, Clock, Zap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

export default function Contact() {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);

  const WA_NUMBER = '8619820224886';

  const waContent: Record<string, { headline: string; sub: string; badge: string; cta: string; note: string; topics: string[] }> = {
    zh: {
      headline: '立即通过 WhatsApp 联系我们',
      sub: '无需等待，直接与我们的专业团队对话。产品咨询、样品申请、经销商合作，一键直达。',
      badge: '即时响应',
      cta: '立即开始对话',
      note: '通常在 5 分钟内回复',
      topics: ['产品报价', '样品申请', '成为经销商', '定制研发'],
    },
    en: {
      headline: 'Chat with Us on WhatsApp',
      sub: 'Skip the wait. Talk directly to our team for product inquiries, sample requests, or distributor partnerships.',
      badge: 'Instant Response',
      cta: 'Start a Conversation',
      note: 'Typically replies within 5 minutes',
      topics: ['Product Pricing', 'Sample Request', 'Become a Distributor', 'Custom R&D'],
    },
    ar: {
      headline: 'تحدث معنا عبر واتساب',
      sub: 'تجاوز الانتظار. تحدث مباشرة مع فريقنا للاستفسارات والعينات وشراكات التوزيع.',
      badge: 'استجابة فورية',
      cta: 'ابدأ محادثة',
      note: 'يرد عادةً خلال 5 دقائق',
      topics: ['أسعار المنتجات', 'طلب عينة', 'أصبح موزعاً', 'بحث وتطوير مخصص'],
    },
    ru: {
      headline: 'Напишите нам в WhatsApp',
      sub: 'Без ожидания. Общайтесь напрямую с нашей командой по вопросам продуктов, образцов и дистрибуции.',
      badge: 'Мгновенный ответ',
      cta: 'Начать разговор',
      note: 'Обычно отвечаем в течение 5 минут',
      topics: ['Цены на продукты', 'Запрос образца', 'Стать дистрибьютором', 'Разработка на заказ'],
    },
    ko: {
      headline: 'WhatsApp으로 바로 문의하세요',
      sub: '기다림 없이 팀과 직접 대화하세요. 제품 문의, 샘플 요청, 유통 파트너십 모두 가능합니다.',
      badge: '즉시 응답',
      cta: '대화 시작하기',
      note: '보통 5분 이내에 답변',
      topics: ['제품 가격', '샘플 요청', '유통업체 신청', '맞춤형 R&D'],
    },
  };

  const wa = waContent[language as keyof typeof waContent] || waContent.zh;

  const content = {
    zh: {
      title: '联系我们',
      subtitle: '对我们的产品有疑问，或想成为经销商？欢迎与我们联系。',
      email: '邮箱',
      phone: '电话',
      address: '地址',
      hours: '营业时间',
      monFri: '周一 – 周五',
      saturday: '周六',
      sunday: '周日',
      closed: '休息',
      namePlaceholder: '您的姓名',
      emailPlaceholder: 'your@email.com',
      messagePlaceholder: '请告诉我们您的需求...',
      selectTopic: '选择主题',
      distributor: '成为经销商',
      rdInquiry: '定制研发咨询',
      general: '一般问询',
      addressValue: '广东省深圳市宝安区华丰科技园10栋8楼 PuriCore',
      nameLabel: '姓名',
      emailLabel: '邮箱',
      subjectLabel: '主题',
      messageLabel: '留言',
      sendMessage: '发送消息',
      successMsg: '消息已发送！',
      successDesc: '我们将在24小时内回复您。',
    },
    en: {
      title: 'Get In Touch',
      subtitle: "Have questions about our products or want to become a distributor? We'd love to hear from you.",
      email: 'Email',
      phone: 'Phone',
      address: 'Address',
      hours: 'Business Hours',
      monFri: 'Mon – Fri',
      saturday: 'Saturday',
      sunday: 'Sunday',
      closed: 'Closed',
      namePlaceholder: 'Your name',
      emailPlaceholder: 'your@email.com',
      messagePlaceholder: 'Tell us how we can help...',
      selectTopic: 'Select a topic',
      distributor: 'Become a Distributor',
      rdInquiry: 'Custom R&D Inquiry',
      general: 'General Inquiry',
      addressValue: 'PuriCore, Bldg 10 Fl.8, Huafeng Tech Park, Bao\'an District, Shenzhen, Guangdong, China',
      nameLabel: 'Name',
      emailLabel: 'Email',
      subjectLabel: 'Subject',
      messageLabel: 'Message',
      sendMessage: 'Send Message',
      successMsg: 'Message sent!',
      successDesc: "We'll get back to you within 24 hours.",
    },
    ar: {
      title: 'تواصل معنا',
      subtitle: 'هل لديك أسئلة حول منتجاتنا أو تريد أن تصبح موزعاً؟ يسعدنا سماعك.',
      email: 'البريد الإلكتروني',
      phone: 'الهاتف',
      address: 'العنوان',
      hours: 'ساعات العمل',
      monFri: 'الاثنين – الجمعة',
      saturday: 'السبت',
      sunday: 'الأحد',
      closed: 'مغلق',
      namePlaceholder: 'اسمك',
      emailPlaceholder: 'your@email.com',
      messagePlaceholder: 'أخبرنا كيف يمكننا المساعدة...',
      selectTopic: 'اختر موضوعاً',
      distributor: 'أصبح موزعاً',
      rdInquiry: 'استفسار بحث وتطوير مخصص',
      general: 'استفسار عام',
      addressValue: 'PuriCore، الطابق 8، مبنى 10، حديقة هوافينغ التقنية، منطقة باوآن، شنتشن، الصين',
      nameLabel: 'الاسم',
      emailLabel: 'البريد الإلكتروني',
      subjectLabel: 'الموضوع',
      messageLabel: 'الرسالة',
      sendMessage: 'إرسال الرسالة',
      successMsg: 'تم إرسال الرسالة!',
      successDesc: 'سنرد عليك خلال 24 ساعة.',
    },
    ru: {
      title: 'Свяжитесь с нами',
      subtitle: 'Есть вопросы о наших продуктах или хотите стать дистрибьютором? Мы рады вас слышать.',
      email: 'Email',
      phone: 'Телефон',
      address: 'Адрес',
      hours: 'Рабочие часы',
      monFri: 'Пн – Пт',
      saturday: 'Суббота',
      sunday: 'Воскресенье',
      closed: 'Закрыто',
      namePlaceholder: 'Ваше имя',
      emailPlaceholder: 'your@email.com',
      messagePlaceholder: 'Расскажите, чем мы можем помочь...',
      selectTopic: 'Выберите тему',
      distributor: 'Стать дистрибьютором',
      rdInquiry: 'Запрос на разработку',
      general: 'Общий вопрос',
      addressValue: 'PuriCore, Здание 10, этаж 8, Технопарк Хуафэн, район Баоань, Шэньчжэнь, Китай',
      nameLabel: 'Имя',
      emailLabel: 'Email',
      subjectLabel: 'Тема',
      messageLabel: 'Сообщение',
      sendMessage: 'Отправить сообщение',
      successMsg: 'Сообщение отправлено!',
      successDesc: 'Мы ответим вам в течение 24 часов.',
    },
    ko: {
      title: '문의하기',
      subtitle: '제품에 대한 질문이 있거나 유통업체가 되고 싶으신가요? 연락 주세요.',
      email: '이메일',
      phone: '전화',
      address: '주소',
      hours: '영업 시간',
      monFri: '월 – 금',
      saturday: '토요일',
      sunday: '일요일',
      closed: '휴무',
      namePlaceholder: '이름',
      emailPlaceholder: 'your@email.com',
      messagePlaceholder: '어떻게 도와드릴까요?',
      selectTopic: '주제 선택',
      distributor: '유통업체 신청',
      rdInquiry: '맞춤형 R&D 문의',
      general: '일반 문의',
      addressValue: 'PuriCore, 화풍과기원 10동 8층, 바오안구, 선전, 광둥성, 중국',
      nameLabel: '이름',
      emailLabel: '이메일',
      subjectLabel: '주제',
      messageLabel: '메시지',
      sendMessage: '메시지 보내기',
      successMsg: '메시지가 전송되었습니다!',
      successDesc: '24시간 이내에 답변 드리겠습니다.',
    },
  };

  const c = content[language as keyof typeof content] || content.zh;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 1500));
    setSending(false);
    toast.success(c.successMsg, { description: c.successDesc });
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const contactInfo = [
    { icon: Mail, label: c.email, value: 'joseluissalamanca3@gmail.com', href: 'mailto:joseluissalamanca3@gmail.com' },
    { icon: Phone, label: 'WhatsApp', value: '+86 198 2022 4886', href: 'https://wa.me/8619820224886' },
    { icon: MapPin, label: c.address, value: c.addressValue, href: 'https://maps.google.com/?q=华丰科技园,宝安区,深圳' },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <p className="text-[oklch(0.76_0.12_75)] text-sm font-semibold uppercase tracking-wider mb-2">
            {t.nav.contact}
          </p>
          <h1 className="text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            {c.title}
          </h1>
          <p className="text-white/50 text-lg max-w-2xl">
            {c.subtitle}
          </p>
        </motion.div>

        {/* WhatsApp Direct Card — full width, above the grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mb-10 relative overflow-hidden rounded-3xl"
          style={{
            background: 'linear-gradient(135deg, oklch(0.14 0.04 150 / 0.95), oklch(0.12 0.05 160 / 0.95))',
            border: '1px solid rgba(37,211,102,0.25)',
            boxShadow: '0 0 60px rgba(37,211,102,0.10), 0 8px 32px oklch(0 0 0 / 0.4)',
          }}
        >
          {/* Background glow blobs */}
          <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full opacity-10" style={{ background: '#25D366', filter: 'blur(60px)' }} />
          <div className="absolute -bottom-10 -left-10 w-48 h-48 rounded-full opacity-8" style={{ background: '#128C7E', filter: 'blur(50px)' }} />

          <div className="relative z-10 p-8 md:p-10">
            <div className="flex flex-col md:flex-row md:items-center gap-8">
              {/* Left: Icon + Text */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-4">
                  {/* WhatsApp icon circle */}
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0"
                    style={{ background: 'linear-gradient(135deg, #25D366, #128C7E)', boxShadow: '0 4px 20px rgba(37,211,102,0.4)' }}
                  >
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                  </div>
                  <div>
                    <span
                      className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full mb-1"
                      style={{ background: 'rgba(37,211,102,0.15)', color: '#25D366', border: '1px solid rgba(37,211,102,0.3)' }}
                    >
                      <Zap size={10} />
                      {wa.badge}
                    </span>
                    <h2 className="text-2xl md:text-3xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
                      {wa.headline}
                    </h2>
                  </div>
                </div>
                <p className="text-white/55 text-base leading-relaxed mb-5 max-w-xl">{wa.sub}</p>
                {/* Topic chips */}
                <div className="flex flex-wrap gap-2">
                  {wa.topics.map((topic) => (
                    <motion.button
                      key={topic}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        const msg = encodeURIComponent(`Hello PuriCore! I'd like to inquire about: ${topic}`);
                        window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`, '_blank', 'noopener,noreferrer');
                      }}
                      className="text-sm px-4 py-1.5 rounded-full font-medium transition-all cursor-pointer"
                      style={{
                        background: 'rgba(37,211,102,0.08)',
                        color: 'rgba(255,255,255,0.7)',
                        border: '1px solid rgba(37,211,102,0.18)',
                      }}
                    >
                      {topic}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Right: CTA */}
              <div className="flex flex-col items-start md:items-center gap-3 shrink-0">
                <motion.a
                  href={`https://wa.me/${WA_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-3 px-8 py-4 rounded-2xl text-white font-bold text-lg shadow-2xl transition-all"
                  style={{
                    background: 'linear-gradient(135deg, #25D366 0%, #128C7E 100%)',
                    boxShadow: '0 8px 32px rgba(37,211,102,0.45)',
                  }}
                >
                  <MessageCircle size={22} />
                  {wa.cta}
                </motion.a>
                <div className="flex items-center gap-2 text-white/40 text-sm">
                  <Clock size={13} />
                  <span>{wa.note}</span>
                </div>
                <div className="text-white/30 text-sm font-mono">+86 198 2022 4886</div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            {contactInfo.map(({ icon: Icon, label, value, href }) => (
              <a
                key={label}
                href={href}
                className="flex items-start gap-4 p-5 rounded-2xl group transition-all hover:bg-white/5"
                style={{ background: 'oklch(0.17 0.03 38)', border: '1px solid oklch(1 0 0 / 0.08)' }}
              >
                <div className="w-10 h-10 rounded-xl bg-[oklch(0.76_0.12_75/0.10)] flex items-center justify-center shrink-0">
                  <Icon className="text-[oklch(0.76_0.12_75)]" size={18} />
                </div>
                <div>
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-1">{label}</p>
                  <p className="text-white font-medium group-hover:text-[oklch(0.82_0.10_78)] transition-colors">{value}</p>
                </div>
              </a>
            ))}

            {/* Business Hours */}
            <div
              className="p-5 rounded-2xl"
              style={{ background: 'oklch(0.17 0.03 38)', border: '1px solid oklch(1 0 0 / 0.08)' }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <MessageSquare className="text-blue-400" size={18} />
                </div>
                <p className="text-white font-medium">{c.hours}</p>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-white/40">{c.monFri}</span>
                  <span className="text-white">9:00 AM – 6:00 PM SGT</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/40">{c.saturday}</span>
                  <span className="text-white">10:00 AM – 2:00 PM SGT</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/40">{c.sunday}</span>
                  <span className="text-white/40">{c.closed}</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="lg:col-span-2"
          >
            <form
              onSubmit={handleSubmit}
              className="p-8 rounded-3xl space-y-5"
              style={{ background: 'oklch(0.17 0.03 38)', border: '1px solid oklch(1 0 0 / 0.08)' }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">{c.nameLabel}</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder={c.namePlaceholder}
                    required
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/20 focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] transition-all"
                  />
                </div>
                <div>
                  <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">{c.emailLabel}</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder={c.emailPlaceholder}
                    required
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/20 focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">{c.subjectLabel}</label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] transition-all cursor-pointer"
                  style={{ background: 'oklch(0.17 0.03 38)' }}
                >
                  <option value="" className="bg-[oklch(0.17_0.03_38)]">{c.selectTopic}</option>
                  <option value="distributor" className="bg-[oklch(0.17_0.03_38)]">{c.distributor}</option>
                  <option value="rd" className="bg-[oklch(0.17_0.03_38)]">{c.rdInquiry}</option>
                  <option value="general" className="bg-[oklch(0.17_0.03_38)]">{c.general}</option>
                </select>
              </div>

              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">{c.messageLabel}</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder={c.messagePlaceholder}
                  required
                  rows={5}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/20 focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] transition-all resize-none"
                />
              </div>

              <motion.button
                type="submit"
                disabled={sending}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-center gap-3 py-4 rounded-xl bg-gradient-to-r from-[oklch(0.68_0.24_42)] to-[oklch(0.76_0.12_75)] text-white font-bold text-lg shadow-xl hover:shadow-[oklch(0.76_0.12_75/0.30)] transition-all disabled:opacity-60"
              >
                {sending ? (
                  <div className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                ) : (
                  <>
                    <Send size={20} />
                    {c.sendMessage}
                  </>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
