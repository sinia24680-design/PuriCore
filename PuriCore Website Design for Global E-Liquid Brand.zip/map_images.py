#!/usr/bin/env python3
"""
Map the newly uploaded product images (from the "最终版" ZIP) to existing products.
The "最终版" ZIP has higher quality product display images for:
- 14 fruit flavors (水果口味)
- 43 dessert & tobacco flavors (甜品与烟草口味)

These should replace the existing BLUEDR images for matching products.
"""

import base64
import os
import json

# Decode base64 filenames from the 最终版 ZIP
def decode_filename(fname):
    """Extract product name from the base64-encoded filename."""
    import re
    match = re.search(r'na1fn_(.+)\.png', fname)
    if match:
        b64 = match.group(1)
        # Fix padding
        b64 += '=' * (4 - len(b64) % 4) if len(b64) % 4 else ''
        try:
            decoded = base64.b64decode(b64).decode('utf-8')
            # Extract just the filename part
            return decoded.split('/')[-1]
        except:
            return None
    return None

# Map 最终版 fruit images
fruit_dir = "/home/ubuntu/upload/PuriCore_images/水果口味/"
dessert_tobacco_dir = "/home/ubuntu/upload/PuriCore_images/甜品与烟草口味/"

print("=== FRUIT IMAGES (最终版) ===")
fruit_mappings = {}
if os.path.exists(fruit_dir):
    for f in sorted(os.listdir(fruit_dir)):
        name = decode_filename(f)
        if name:
            print(f"  {f[:20]}... -> {name}")
            fruit_mappings[name] = os.path.join(fruit_dir, f)

print(f"\nTotal fruit images: {len(fruit_mappings)}")

print("\n=== DESSERT & TOBACCO IMAGES (最终版) ===")
dessert_tobacco_mappings = {}
if os.path.exists(dessert_tobacco_dir):
    for f in sorted(os.listdir(dessert_tobacco_dir)):
        name = decode_filename(f)
        if name:
            print(f"  {f[:20]}... -> {name}")
            dessert_tobacco_mappings[name] = os.path.join(dessert_tobacco_dir, f)

print(f"\nTotal dessert/tobacco images: {len(dessert_tobacco_mappings)}")

# Now check the already-uploaded images in webdev-static-assets
print("\n=== ALREADY UPLOADED TO CDN ===")
uploaded_dessert = {}
uploaded_tobacco = {}
uploaded_fruit = {}

# These are the CDN URLs from the upload sessions
dessert_cdns = {
    "matcha-latte": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-matcha-latte_18b30f30.png",
    "french-croissant": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-french-croissant_c4775031.png",
    "toffee": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-toffee_9a8c2ca6.png",
    "strawberry-cheesecake": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-strawberry-cheesecake_cd87e91a.png",
    "irish-cream": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-irish-cream_0f12fda0.png",
    "rum-raisin": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-rum-raisin_d0d2119d.png",
    "blueberry-cheesecake": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-blueberry-cheesecake_82cadd21.png",
    "cream-whiskey": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-cream-whiskey_3c89e149.png",
    "toasted-marshmallow": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-toasted-marshmallow_b64e4635.png",
    "matcha-ice-cream": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-matcha-ice-cream_7fb6c568.png",
    "apple-cookie": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-apple-cookie_ddf677cd.png",
    "black-coffee": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-black-coffee_cfec9ce4.png",
    "apple-cinnamon-roll": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-apple-cinnamon-roll_f0e0a09b.png",
    "cappuccino": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-cappuccino_fea87dee.png",
    "caramel-macchiato": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-caramel-macchiato_b924be1c.png",
    "vanilla-caramel-cream-coffee": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-vanilla-caramel-cream-coffee_8c00ce78.png",
    "blueberry-muffin": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-blueberry-muffin_721bf018.png",
    "cinnamon-apple-pie": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-cinnamon-apple-pie_154e41a9.png",
    "hazelnut-latte": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-hazelnut-latte_8f4e4d35.png",
    "custard-donut": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-custard-donut_5e8809de.png",
    "chocolate-lava-cake": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-chocolate-lava-cake_22354fe3.png",
    "cotton-candy": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-cotton-candy_0fe21bda.png",
    "maple-waffle": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-maple-waffle_f295ed07.png",
    "lemon-tart": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-lemon-tart_1dba59bd.png",
    "coconut-cream-pie": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-coconut-cream-pie_5e7c38d8.png",
    "honey-butter": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-honey-butter_b9304b50.png",
    "strawberry-cream-cake": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-strawberry-cream-cake_89ba6b28.png",
    "brown-sugar-bubble-tea": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-brown-sugar-bubble-tea_f111d59d.png",
    "butterscotch": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-butterscotch_c8badf86.png",
    "caramel-pudding": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-caramel-pudding_c49a9a59.png",
    "vanilla-ice-cream": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-vanilla-ice-cream_a4f783cb.png",
    "vanilla-panna-cotta": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-vanilla-panna-cotta_41624fcb.png",
    "cinnamon-roll": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-cinnamon-roll_9cad33da.png",
    "hazelnut-chocolate": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-hazelnut-chocolate_1a3585de.png",
    "white-chocolate-raspberry": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-white-chocolate-raspberry_0a23b1e0.png",
}

tobacco_cdns = {
    "menthol-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-menthol-tobacco_c26d6b14.png",
    "honey-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-honey-tobacco_5d0ab455.png",
    "vanilla-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-vanilla-tobacco_fcb8b82f.png",
    "nutty-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-nutty-tobacco_ea258a8a.png",
    "virginia-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-virginia-tobacco_eb2bccc7.png",
    "cigar-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-cigar-tobacco_f6c7ade2.png",
    "cream-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-cream-tobacco_df8ee9b3.png",
    "classic-tobacco": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-classic-tobacco_d0edf15e.png",
}

fruit_cdns = {
    "watermelon": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-watermelon_placeholder.png",
    "mango": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-mango_placeholder.png",
    "lychee": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-lychee_placeholder.png",
    "passion-fruit": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-passion-fruit_placeholder.png",
    "blueberry": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-blueberry_placeholder.png",
    "strawberry": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-strawberry_placeholder.png",
    "peach": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-peach_placeholder.png",
    "grape": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-grape_placeholder.png",
    "pineapple": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-pineapple_placeholder.png",
    "lemon": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-lemon_placeholder.png",
    "orange": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-orange_placeholder.png",
    "cherry": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-cherry_placeholder.png",
    "kiwi": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-kiwi_placeholder.png",
    "pomegranate": "https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-pomegranate_placeholder.png",
}

# Print summary of new images available
print(f"\nNew dessert CDN images: {len(dessert_cdns)}")
print(f"New tobacco CDN images: {len(tobacco_cdns)}")
print(f"New fruit CDN images (from 最终版): {len(fruit_cdns)}")

# These are NEW products that need to be ADDED (not in the existing 160)
new_dessert_products = [
    "Matcha Latte", "French Croissant", "Toffee", "Strawberry Cheesecake",
    "Irish Cream", "Rum Raisin", "Blueberry Cheesecake", "Cream Whiskey",
    "Toasted Marshmallow", "Matcha Ice Cream", "Apple Cookie", "Black Coffee",
    "Apple Cinnamon Roll", "Cappuccino", "Caramel Macchiato (new)", 
    "Vanilla Caramel Cream Coffee", "Blueberry Muffin", "Cinnamon Apple Pie",
    "Hazelnut Latte", "Custard Donut", "Chocolate Lava Cake", "Cotton Candy",
    "Maple Waffle", "Lemon Tart", "Coconut Cream Pie", "Honey Butter",
    "Strawberry Cream Cake", "Brown Sugar Bubble Tea", "Butterscotch (new)",
    "Caramel Pudding", "Vanilla Ice Cream", "Vanilla Panna Cotta",
    "Cinnamon Roll", "Hazelnut Chocolate", "White Chocolate Raspberry"
]

new_tobacco_products = [
    "Menthol Tobacco", "Honey Tobacco", "Vanilla Tobacco", "Nutty Tobacco",
    "Virginia Tobacco", "Cigar Tobacco", "Cream Tobacco", "Classic Tobacco"
]

# Check which of these are already in the existing products
existing_names = set()
with open("/home/ubuntu/puricore/client/src/lib/products.ts") as f:
    for line in f:
        if "name: '" in line:
            name = line.split("name: '")[1].split("'")[0]
            existing_names.add(name)

print(f"\nExisting product names: {len(existing_names)}")

# Check new dessert products
truly_new_dessert = []
for p in new_dessert_products:
    clean = p.replace(" (new)", "")
    if clean not in existing_names:
        truly_new_dessert.append(clean)
    else:
        print(f"  Already exists: {clean}")

print(f"\nTruly new dessert products to add: {len(truly_new_dessert)}")
for p in truly_new_dessert:
    print(f"  + {p}")

# Check new tobacco products
truly_new_tobacco = []
for p in new_tobacco_products:
    if p not in existing_names:
        truly_new_tobacco.append(p)
    else:
        print(f"  Already exists: {p}")

print(f"\nTruly new tobacco products to add: {len(truly_new_tobacco)}")
for p in truly_new_tobacco:
    print(f"  + {p}")

# Output as JSON for the next step
result = {
    "new_dessert": truly_new_dessert,
    "new_tobacco": truly_new_tobacco,
    "dessert_cdns": dessert_cdns,
    "tobacco_cdns": tobacco_cdns,
}
with open("/home/ubuntu/new_products_mapping.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"\nMapping saved to /home/ubuntu/new_products_mapping.json")
