// PuriCore Blog Post Detail Page — "Tropical Drift" design
import { Link, useParams } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft, Clock, Calendar, Tag } from 'lucide-react';
import { blogPosts } from '@/lib/content';
import { useLanguage } from '@/contexts/LanguageContext';

const categoryColors: Record<string, string> = {
  industry: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  flavors: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  lifestyle: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  science: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
};

export default function BlogPost() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();

  const post = blogPosts.find((p) => p.id === id);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">📝</div>
          <h2 className="text-white text-2xl font-bold mb-4">Post not found</h2>
          <Link href="/blog">
            <button className="px-6 py-3 rounded-xl bg-orange-500 text-white font-semibold">
              Back to Blog
            </button>
          </Link>
        </div>
      </div>
    );
  }

  const relatedPosts = blogPosts
    .filter((p) => p.category === post.category && p.id !== post.id)
    .slice(0, 3);

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Back */}
        <Link href="/blog">
          <button className="flex items-center gap-2 text-white/50 hover:text-white text-sm mb-8 transition-colors">
            <ArrowLeft size={16} />
            {t.blog.title}
          </button>
        </Link>

        {/* Article */}
        <motion.article
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Meta */}
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${categoryColors[post.category]}`}>
              {t.blog.categories[post.category]}
            </span>
            <span className="text-white/30 text-sm flex items-center gap-1.5">
              <Clock size={14} />
              {post.readTime} {t.blog.minRead}
            </span>
            <span className="text-white/30 text-sm flex items-center gap-1.5">
              <Calendar size={14} />
              {post.date}
            </span>
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight"
            style={{ fontFamily: 'Syne, sans-serif' }}>
            {post.title}
          </h1>

          {/* Author */}
          <div className="flex items-center gap-4 mb-8 pb-8 border-b border-white/5">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-orange-500/30"
            />
            <div>
              <p className="text-white font-semibold">{post.author.name}</p>
              <p className="text-white/40 text-sm">{post.author.role}</p>
            </div>
          </div>

          {/* Hero Image */}
          <div className="rounded-2xl overflow-hidden mb-10 h-72">
            <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
          </div>

          {/* Excerpt */}
          <p className="text-white/70 text-xl leading-relaxed mb-8 font-medium border-l-4 border-orange-500 pl-6">
            {post.excerpt}
          </p>

          {/* Content */}
          <div className="prose prose-invert max-w-none">
            {post.content.split('\n\n').map((paragraph, i) => {
              if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                return (
                  <h3 key={i} className="text-white text-xl font-bold mt-8 mb-4"
                    style={{ fontFamily: 'Syne, sans-serif' }}>
                    {paragraph.replace(/\*\*/g, '')}
                  </h3>
                );
              }
              // Handle **bold** within paragraph
              const parts = paragraph.split(/(\*\*[^*]+\*\*)/g);
              return (
                <p key={i} className="text-white/60 leading-relaxed mb-5 text-base">
                  {parts.map((part, j) => {
                    if (part.startsWith('**') && part.endsWith('**')) {
                      return <strong key={j} className="text-white font-semibold">{part.replace(/\*\*/g, '')}</strong>;
                    }
                    return part;
                  })}
                </p>
              );
            })}
          </div>

          {/* Tags */}
          <div className="mt-10 pt-8 border-t border-white/5 flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <span key={tag} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm bg-white/5 text-white/50 border border-white/5">
                <Tag size={12} />
                {tag}
              </span>
            ))}
          </div>
        </motion.article>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
              Related Articles
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedPosts.map((relPost) => (
                <Link key={relPost.id} href={`/blog/${relPost.id}`}>
                  <motion.div
                    whileHover={{ y: -4 }}
                    className="rounded-2xl overflow-hidden cursor-pointer group"
                    style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
                  >
                    <div className="h-36 overflow-hidden">
                      <img src={relPost.image} alt={relPost.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="p-4">
                      <p className="text-white font-semibold text-sm group-hover:text-orange-300 transition-colors line-clamp-2"
                        style={{ fontFamily: 'Syne, sans-serif' }}>
                        {relPost.title}
                      </p>
                      <p className="text-white/40 text-xs mt-1">{relPost.author.name}</p>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
