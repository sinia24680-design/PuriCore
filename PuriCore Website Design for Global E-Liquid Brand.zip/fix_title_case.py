import re

filepath = '/home/ubuntu/puricore/client/src/lib/products.ts'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

def to_title_case(match):
    prefix = match.group(1)  # "  name: '"
    name = match.group(2)    # the product name
    suffix = match.group(3)  # "'"
    
    # Title case: capitalize first letter of each word
    titled = name.title()
    
    return prefix + titled + suffix

# Match lines like:  name: 'some product name',
# Also handle double quotes
pattern = r"(name:\s*['\"])([^'\"]+)(['\"])"
new_content = re.sub(pattern, to_title_case, content)

# Count changes
old_names = re.findall(r"name:\s*['\"]([^'\"]+)['\"]", content)
new_names = re.findall(r"name:\s*['\"]([^'\"]+)['\"]", new_content)

changed = 0
for old, new in zip(old_names, new_names):
    if old != new:
        changed += 1
        print(f"  {old} -> {new}")

print(f"\nTotal products: {len(old_names)}, Changed: {changed}")

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("File updated successfully.")
