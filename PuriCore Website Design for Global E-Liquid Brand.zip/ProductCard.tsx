// PuriCore ProductCard — "Tropical Drift" design
// Color-coded by category: fruit=emerald, dessert=amber, tobacco=blue

import { useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ShoppingCart, Info, Zap } from 'lucide-react';
import ShareButton from '@/components/ShareButton';
import { Product, categoryColors } from '@/lib/products';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

interface ProductCardProps {
  product: Product;
  showCompare?: boolean;
  onCompare?: (product: Product) => void;
  isCompared?: boolean;
}

export default function ProductCard({ product, showCompare, onCompare, isCompared }: ProductCardProps) {
  const { t, language } = useLanguage();

  const toastText = {
    zh: { added: '已加入购物车！', comingSoon: '功能即将探出，敬请期待。' },
    en: { added: 'added to cart!', comingSoon: 'Feature coming soon — stay tuned.' },
    ar: { added: 'تمت الإضافة إلى السلة!', comingSoon: 'قريباً متاح.' },
    ru: { added: 'добавлено в корзину!', comingSoon: 'Функция скоро появится.' },
    ko: { added: '장바구니에 추가되었습니다!', comingSoon: '공스 예정입니다.' },
  };
  const tt = toastText[language as keyof typeof toastText] || toastText.zh;
  const [imageLoaded, setImageLoaded] = useState(false);
  const colors = categoryColors[product.category];

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    toast.success(`${product.name} ${tt.added}`, {
      description: tt.comingSoon,
      duration: 2000,
    });
  };

  const handleCompare = (e: React.MouseEvent) => {
    e.preventDefault();
    onCompare?.(product);
  };

  const intensityDots = Array.from({ length: 5 }, (_, i) => i < product.intensity);

  return (
    <Link href={`/flavors/${product.id}`}>
      <motion.div
        whileHover={{ y: -6 }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className="product-card relative rounded-2xl overflow-hidden cursor-pointer group"
        style={{
          background: 'oklch(0.17 0.03 38)',
          border: '1px solid oklch(1 0 0 / 0.08)',
        }}
      >
        {/* Product Image */}
        <div className="relative h-52 overflow-hidden" style={{ background: 'linear-gradient(135deg, #1A2B6B 0%, #0F1F5C 60%, #162055 100%)' }}>
          {!imageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-8 h-8 rounded-full border-2 border-[oklch(0.76_0.12_75/0.30)] border-t-orange-500 animate-spin" />
            </div>
          )}
          <img
            src={product.image}
            alt={product.name}
            onLoad={() => setImageLoaded(true)}
            className={`w-full h-full object-contain p-4 transition-all duration-500 group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />

          {/* Category Badge */}
          <div className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold ${colors.bg} ${colors.text} border ${colors.border}`}>
            {t.categories[product.category]}
          </div>

          {/* Featured Badge */}
          {product.featured && (
            <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-orange-500 text-white text-xs font-semibold flex items-center gap-1">
              <Zap size={10} className="fill-current" />
              {t.products.featured}
            </div>
          )}

          {/* Hover Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.10_0.03_240/0.8)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between px-3 pb-3">
            <div className="flex gap-2">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleAddToCart}
                className="p-2.5 rounded-xl bg-orange-500 text-white shadow-lg hover:bg-orange-400 transition-colors"
              >
                <ShoppingCart size={16} />
              </motion.button>
              {showCompare && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handleCompare}
                  className={`p-2.5 rounded-xl text-white shadow-lg transition-colors ${
                    isCompared ? 'bg-blue-500 hover:bg-blue-400' : 'bg-white/20 hover:bg-white/30'
                  }`}
                >
                  <Info size={16} />
                </motion.button>
              )}
            </div>
            {/* Share button — bottom-right of overlay */}
            <ShareButton productName={product.name} productId={product.id} size="sm" />
          </div>
        </div>

        {/* Product Info */}
        <div className="p-4">
          <h3 className="text-white font-semibold text-sm mb-2 truncate" style={{ fontFamily: 'Syne, sans-serif' }}>
            {product.name}
          </h3>

          {/* Flavor Notes */}
          <div className="flex flex-wrap gap-1 mb-3">
            {product.flavorNotes.slice(0, 3).map((note) => (
              <span
                key={note}
                className="px-2 py-0.5 rounded-full text-xs text-white/50 bg-white/5 border border-white/5"
              >
                {note}
              </span>
            ))}
          </div>

          {/* Intensity */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-white/40 text-xs">{t.products.intensity}</span>
              <div className="flex gap-1">
                {intensityDots.map((active, i) => (
                  <div
                    key={i}
                    className={`intensity-dot ${active ? 'active' : 'inactive'}`}
                  />
                ))}
              </div>
            </div>
            <span className="text-white/40 text-xs">{product.vgPgRatio}</span>
          </div>

          {/* Nicotine Options */}
          <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
            <div className="flex gap-1 flex-wrap">
              {product.nicotineOptions.slice(0, 3).map((nic) => (
                <span key={nic} className="text-xs text-white/40 bg-white/5 px-1.5 py-0.5 rounded">
                  {nic}
                </span>
              ))}
            </div>
            <span className="text-[oklch(0.76_0.12_75)] text-xs font-medium group-hover:text-[oklch(0.82_0.10_78)] transition-colors">
              {t.products.learnMore} →
            </span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
