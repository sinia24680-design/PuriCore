// PuriCore Footer — "Tropical Drift" design
import { Link } from 'wouter';
import { Instagram, Twitter, Youtube, Facebook, Send } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import PuriCoreLogo from '@/components/PuriCoreLogo';

export default function Footer() {
  const { t } = useLanguage();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const footerLinks = {
    [t.footer.products]: [
      { label: t.categories.fruit, href: '/products?category=fruit' },
      { label: t.categories.dessert, href: '/products?category=dessert' },
      { label: t.categories.tobacco, href: '/products?category=tobacco' },
      { label: t.nav.flavors, href: '/flavors' },
    ],
    [t.footer.company]: [
      { label: t.nav.about, href: '/about' },
      { label: t.nav.caseStudies, href: '/case-studies' },
      { label: t.nav.contact, href: '/contact' },
    ],
    [t.footer.legal]: [
      { label: 'Privacy Policy', href: '/privacy' },
      { label: 'Terms of Service', href: '/terms' },
      { label: 'Age Verification', href: '/age-policy' },
      { label: 'Compliance', href: '/compliance' },
    ],
  };

  return (
    <footer className="border-t" style={{ background: 'oklch(0.10 0.02 38)', borderColor: 'oklch(0.76 0.12 75 / 0.12)' }}>
      {/* Main Footer */}
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link href="/">
              <div className="flex items-start mb-4">
                <div className="gold-glow transition-all">
                  <PuriCoreLogo size={52} showText={true} showTagline={false} />
                </div>
              </div>
            </Link>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-xs">
              {t.footer.tagline}
            </p>

            {/* Newsletter */}
            <div>
              <p className="text-white/70 text-sm font-semibold mb-3">{t.footer.newsletter}</p>
              {subscribed ? (
                <div className="flex items-center gap-2 text-emerald-400 text-sm">
                  <span>✓</span>
                  <span>Thank you for subscribing!</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t.footer.newsletterPlaceholder}
                    className="flex-1 px-4 py-2.5 rounded-lg text-white text-sm placeholder:text-white/30 focus:outline-none transition-all" style={{ background: 'oklch(1 0 0 / 0.05)', border: '1px solid oklch(0.76 0.12 75 / 0.20)' }}
                  />
                  <button
                    type="submit"
                    className="p-2.5 rounded-lg text-white transition-all" style={{ background: 'linear-gradient(135deg, oklch(0.68 0.24 42), oklch(0.76 0.12 75))' }}
                  >
                    <Send size={16} />
                  </button>
                </form>
              )}
            </div>

            {/* Social Links */}
            <div className="mt-6">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-3">{t.footer.followUs}</p>
              <div className="flex gap-3">
                {[
                  { icon: Instagram, href: 'https://www.instagram.com/bluedr.123?igsh=cDZzbnU4a24zdW9o&utm_source=qr', label: 'Instagram' },
                  { icon: Twitter, href: '#', label: 'Twitter' },
                  { icon: Youtube, href: '#', label: 'YouTube' },
                  { icon: Facebook, href: 'https://www.facebook.com/share/184hp3CEhR/?mibextid=wwXIfr', label: 'Facebook' },
                ].map(({ icon: Icon, href, label }) => (
                  <a
                    key={label}
                    href={href}
                    aria-label={label}
                    target={href !== '#' ? '_blank' : undefined}
                    rel={href !== '#' ? 'noopener noreferrer' : undefined}
                    className="w-9 h-9 rounded-lg flex items-center justify-center transition-all" style={{ background: 'oklch(1 0 0 / 0.05)', color: 'oklch(0.76 0.12 75 / 0.6)' }}
                  >
                    <Icon size={16} />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-semibold text-sm mb-4 uppercase tracking-wider text-gradient-gold">{title}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href}>
                      <span className="text-white/50 hover:text-white text-sm transition-colors">
                        {link.label}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t" style={{ borderColor: 'oklch(0.76 0.12 75 / 0.08)' }}>
        <div className="container py-5 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-white/30 text-xs">{t.footer.rights}</p>
          <p className="text-white/20 text-xs text-center max-w-lg">
            {t.footer.warning}
          </p>
        </div>
      </div>
    </footer>
  );
}
