    >
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <img
          src={study.image}
          alt={study.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute bottom-4 left-4 flex items-center gap-1.5 text-white/70 text-sm">
          <MapPin size={14} />
          {study.location}
        </div>
      </div>

      {/* Info */}
      <div className="p-5">
        <div className="flex flex-wrap gap-1.5 mb-3">
          {study.tags.slice(0, 2).map((tag) => (
            <span key={tag} className="px-2 py-0.5 rounded-full text-xs bg-orange-500/10 text-orange-400 border border-orange-500/20">
              {tag}
            </span>
          ))}
        </div>

        <h3 className="text-white font-bold text-lg mb-1 group-hover:text-orange-300 transition-colors"
          style={{ fontFamily: 'Syne, sans-serif' }}>
          {study.title}
        </h3>
        <p className="text-orange-400 text-sm mb-4">{study.client}</p>

        {/* Key Metric */}
        <div className="flex items-center justify-between pt-4 border-t border-white/5">
          <div className="flex items-center gap-2">
            <TrendingUp size={14} className="text-emerald-400" />
            <span className="text-emerald-400 text-sm font-semibold">{study.metrics[0].value}</span>
            <span className="text-white/40 text-xs">{study.metrics[0].label}</span>
          </div>
          <span className="text-orange-400 text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
            {t.caseStudies.readMore}
            <ArrowRight size={14} />
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export default function CaseStudies() {
  const { t } = useLanguage();
  const [selectedStudy, setSelectedStudy] = useState<CaseStudy | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container">
        {/* Header */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="mb-12"
        >
          <motion.p variants={itemVariants} className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-2">
            {t.caseStudies.title}
          </motion.p>
          <motion.h1 variants={itemVariants} className="text-5xl font-bold text-white mb-4"
            style={{ fontFamily: 'Syne, sans-serif' }}>
            {t.caseStudies.title}
          </motion.h1>
          <motion.p variants={itemVariants} className="text-white/50 text-lg max-w-2xl">
            {t.caseStudies.subtitle}
          </motion.p>
        </motion.div>

        {/* Featured Case Study Carousel */}
        <div className="mb-16 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.4 }}
              className="relative rounded-3xl overflow-hidden h-80"
            >
              <img
                src={caseStudies[currentSlide].image}
                alt={caseStudies[currentSlide].title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.10_0.03_240/0.90)] via-[oklch(0.10_0.03_240/0.60)] to-transparent" />
              <div className="absolute inset-0 flex flex-col justify-center p-10">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin size={16} className="text-orange-400" />
                  <span className="text-orange-400 text-sm">{caseStudies[currentSlide].location}</span>
                </div>
                <h2 className="text-4xl font-bold text-white mb-2 max-w-lg" style={{ fontFamily: 'Syne, sans-serif' }}>
                  {caseStudies[currentSlide].title}
                </h2>
                <p className="text-white/60 mb-6 max-w-md">{caseStudies[currentSlide].client}</p>
                <div className="flex gap-4 items-center">
                  {caseStudies[currentSlide].metrics.slice(0, 2).map((m) => (
                    <div key={m.label} className="text-center">
                      <div className="text-2xl font-bold text-orange-400" style={{ fontFamily: 'Syne, sans-serif' }}>{m.value}</div>
                      <div className="text-white/40 text-xs">{m.label}</div>
                    </div>
                  ))}
                  <button
                    onClick={() => setSelectedStudy(caseStudies[currentSlide])}
                    className="ml-4 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-orange-500 text-white text-sm font-semibold hover:bg-orange-400 transition-colors"
                  >
                    {t.caseStudies.readMore}
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Carousel Controls */}
          <div className="flex items-center gap-3 mt-4 justify-end">
            <button
              onClick={() => setCurrentSlide((prev) => (prev - 1 + caseStudies.length) % caseStudies.length)}
              className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex gap-2">
              {caseStudies.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === currentSlide ? 'w-6 bg-orange-400' : 'w-1.5 bg-white/20'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => setCurrentSlide((prev) => (prev + 1) % caseStudies.length)}
              className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        {/* All Case Studies Grid */}
        <motion.div