// QuickPreviewModal — PuriCore product quick-view dialog
// Gold brand identity, warm dark background, no page navigation required

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight, Zap, Droplets, Star, MessageCircle } from 'lucide-react';
import { Link } from 'wouter';
import { Product } from '@/lib/products';

interface QuickPreviewModalProps {
  product: Product | null;
  onClose: () => void;
  accentColor?: string;
}

const GOLD = 'oklch(0.76 0.12 75)';
const GOLD_BG = 'oklch(0.76 0.12 75 / 0.12)';
const GOLD_BORDER = 'oklch(0.76 0.12 75 / 0.3)';

// Intensity label map
const intensityLabel = ['', 'Very Mild', 'Mild', 'Medium', 'Bold', 'Intense'];

export default function QuickPreviewModal({ product, onClose, accentColor = GOLD }: QuickPreviewModalProps) {
  const [selectedNicotine, setSelectedNicotine] = useState<string>('');

  // Reset nicotine selection when product changes
  useEffect(() => {
    if (product) {
      setSelectedNicotine(product.nicotineOptions[0] ?? '');
    }
  }, [product?.id]);

  // Close on Escape key
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  // Prevent body scroll when open
  useEffect(() => {
    if (product) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [product]);

  const accent = accentColor || GOLD;
  const accentBg = accent.replace(')', ' / 0.12)').replace('oklch(', 'oklch(');
  const accentBorder = accent.replace(')', ' / 0.28)').replace('oklch(', 'oklch(');

  return (
    <AnimatePresence>
      {product && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[200] cursor-pointer"
            style={{ background: 'oklch(0 0 0 / 0.72)', backdropFilter: 'blur(6px)' }}
            onClick={onClose}
          />

          {/* Modal panel */}
          <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 16 }}
            transition={{ type: 'spring', stiffness: 340, damping: 28 }}
            className="fixed inset-0 z-[201] flex items-center justify-center p-4 pointer-events-none"
          >
            <div
              className="relative w-full max-w-2xl rounded-2xl overflow-hidden pointer-events-auto"
              style={{
                background: 'linear-gradient(135deg, oklch(0.14 0.025 40), oklch(0.18 0.03 38))',
                border: `1px solid ${accentBorder}`,
                boxShadow: `0 32px 80px oklch(0 0 0 / 0.6), 0 0 0 1px ${accentBorder}`,
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all"
                style={{ background: 'oklch(1 0 0 / 0.08)', color: 'oklch(1 0 0 / 0.6)' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'oklch(1 0 0 / 0.15)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'oklch(1 0 0 / 0.08)')}
              >
                <X size={16} />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Left: Product image */}
                <div
                  className="relative aspect-square md:aspect-auto md:min-h-[380px] overflow-hidden"
                  style={{ background: 'linear-gradient(135deg, oklch(0.18 0.04 240), oklch(0.22 0.06 235))' }}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  {/* Category badge */}
                  <div
                    className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold capitalize"
                    style={{ background: accentBg, color: accent, border: `1px solid ${accentBorder}` }}
                  >
                    {product.category}
                  </div>
                  {/* Intensity overlay */}
                  <div
                    className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs"
                    style={{ background: 'oklch(0 0 0 / 0.55)', color: 'oklch(1 0 0 / 0.8)' }}
                  >
                    <Zap size={11} style={{ color: accent }} />
                    <span>{intensityLabel[product.intensity] ?? 'Medium'}</span>
                    <div className="flex gap-0.5 ml-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div
                          key={i}
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ background: i < product.intensity ? accent : 'oklch(1 0 0 / 0.2)' }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right: Product details */}
                <div className="p-6 flex flex-col justify-between">
                  <div>
                    {/* Name */}
                    <h3
                      className="text-2xl font-bold text-white mb-2 leading-tight"
                      style={{ fontFamily: 'Syne, sans-serif' }}
                    >
                      {product.name}
                    </h3>

                    {/* Product ID */}
                    <div className="flex items-center gap-2 mb-4">
                      <Droplets size={13} style={{ color: accent }} />
                      <span className="text-xs" style={{ color: 'oklch(1 0 0 / 0.45)' }}>
                        ID: <span className="text-white/70">{product.vgPgRatio}</span>
                      </span>
                      <span className="text-white/20">·</span>
                      <Star size={12} style={{ color: accent }} />
                      <span className="text-xs" style={{ color: 'oklch(1 0 0 / 0.45)' }}>
                        {product.featured ? 'Featured' : 'Standard'}
                      </span>
                    </div>

                    {/* Description */}
                    <p className="text-sm leading-relaxed mb-5" style={{ color: 'oklch(1 0 0 / 0.55)' }}>
                      {product.description}
                    </p>

                    {/* Flavor notes */}
                    <div className="mb-5">
                      <p className="text-xs uppercase tracking-wider mb-2" style={{ color: 'oklch(1 0 0 / 0.35)' }}>
                        Flavor Notes
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {product.flavorNotes.map(note => (
                          <span
                            key={note}
                            className="px-2.5 py-1 rounded-full text-xs font-medium"
                            style={{ background: accentBg, color: accent, border: `1px solid ${accentBorder}` }}
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Nicotine strength selector */}
                    <div className="mb-6">
                      <p className="text-xs uppercase tracking-wider mb-2" style={{ color: 'oklch(1 0 0 / 0.35)' }}>
                        Nicotine Strength
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {product.nicotineOptions.map(opt => (
                          <button
                            key={opt}
                            onClick={() => setSelectedNicotine(opt)}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200"
                            style={{
                              background: selectedNicotine === opt
                                ? `linear-gradient(135deg, ${accent}, oklch(0.68 0.24 42))`
                                : 'oklch(1 0 0 / 0.06)',
                              color: selectedNicotine === opt ? 'oklch(0.10 0.02 38)' : 'oklch(1 0 0 / 0.55)',
                              border: selectedNicotine === opt
                                ? `1px solid ${accent}`
                                : '1px solid oklch(1 0 0 / 0.10)',
                              boxShadow: selectedNicotine === opt
                                ? `0 2px 10px ${accentBg}`
                                : 'none',
                            }}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-col gap-2">
                    {/* WhatsApp Inquire Now — primary CTA */}
                    <motion.button
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        const nicotine = selectedNicotine || product.nicotineOptions[0] || '';
                        const msg = encodeURIComponent(
                          `Hello PuriCore! I'm interested in ordering:\n\nProduct: ${product.name}\nNicotine: ${nicotine}\nCategory: ${product.category}\n\nPlease provide pricing and availability. Thank you!`
                        );
                        window.open(`https://wa.me/8619820224886?text=${msg}`, '_blank', 'noopener,noreferrer');
                      }}
                      className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-bold text-white transition-all"
                      style={{
                        background: 'linear-gradient(135deg, #25D366, #128C7E)',
                        boxShadow: '0 4px 16px rgba(37, 211, 102, 0.35)',
                      }}
                    >
                      <MessageCircle size={16} />
                      立即询价 / Inquire Now
                    </motion.button>
                    <div className="flex gap-2">
                      <Link href={`/flavors/${product.id}`} onClick={onClose} className="flex-1">
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.97 }}
                          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white transition-all"
                          style={{
                            background: `linear-gradient(135deg, oklch(0.68 0.24 42), ${accent})`,
                            boxShadow: `0 2px 10px ${accentBg}`,
                          }}
                        >
                          View Details
                          <ArrowRight size={12} />
                        </motion.button>
                      </Link>
                      <button
                        onClick={onClose}
                        className="px-4 py-2.5 rounded-xl text-xs font-medium transition-all"
                        style={{
                          background: 'oklch(1 0 0 / 0.06)',
                          color: 'oklch(1 0 0 / 0.55)',
                          border: '1px solid oklch(1 0 0 / 0.10)',
                        }}
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Gold shimmer line at top */}
              <div
                className="absolute top-0 left-0 right-0 h-[2px]"
                style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)` }}
              />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
