// PuriCore FlavorCompare — Interactive side-by-side flavor comparison modal
import { motion } from 'framer-motion';
import { X, ArrowLeftRight, Plus } from 'lucide-react';
import { Product, categoryColors, allProducts } from '@/lib/products';
import { useLanguage } from '@/contexts/LanguageContext';
import { useState } from 'react';

interface FlavorCompareProps {
  products: Product[];
  onClose: () => void;
  onRemove: (id: string) => void;
}

function IntensityBar({ value, max = 5 }: { value: number; max?: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: max }, (_, i) => (
        <div
          key={i}
          className={`h-2 flex-1 rounded-full transition-all ${
            i < value ? 'bg-orange-500' : 'bg-white/10'
          }`}
        />
      ))}
    </div>
  );
}

function ProductSlot({
  product,
  onRemove,
  onSelect,
}: {
  product?: Product;
  onRemove?: () => void;
  onSelect?: (p: Product) => void;
}) {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const searchPH = { zh: '搜索...', en: 'Search...', ar: 'بحث...', ru: 'Поиск...', ko: '검색...' };
  const slotText = {
    zh: { flavorNotes: '口味特征', intensity: '浓度', nicotine: '尼古丁选项', vgpg: '产品编号', category: '类别' },
    en: { flavorNotes: 'Flavor Notes', intensity: 'Intensity', nicotine: 'Nicotine Options', vgpg: 'Product ID', category: 'Category' },
    ar: { flavorNotes: 'ملاحظات النكهة', intensity: 'الشدة', nicotine: 'خيارات النيكوتين', vgpg: 'معرف المنتج', category: 'الفئة' },
    ru: { flavorNotes: 'Вкусовые ноты', intensity: 'Интенсивность', nicotine: 'Варианты никотина', vgpg: 'ID продукта', category: 'Категория' },
    ko: { flavorNotes: '맛 특성', intensity: '강도', nicotine: '니코틴 옵션', vgpg: '제품 ID', category: '카테고리' },
  };
  const st = slotText[language as keyof typeof slotText] || slotText.zh;

  const filtered = allProducts.filter(
    (p) =>
      search === '' ||
      p.name.toLowerCase().includes(search.toLowerCase())
  ).slice(0, 8);

  if (!product) {
    return (
      <div className="flex-1 min-w-0">
        <div className="relative">
          <div
            className="h-48 rounded-2xl border-2 border-dashed border-white/10 flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-[oklch(0.76_0.12_75/0.30)] transition-colors"
            onClick={() => setShowDropdown(true)}
          >
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
              <Plus size={20} className="text-white/30" />
            </div>
            <p className="text-white/30 text-sm">{t.products.selectProduct}</p>
          </div>

          {showDropdown && (
            <div className="absolute top-full mt-2 left-0 right-0 z-10 glass-card rounded-xl overflow-hidden shadow-2xl">
              <div className="p-2">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={searchPH[language as keyof typeof searchPH] || searchPH.zh}
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none"
                  autoFocus
                />
              </div>
              <div className="max-h-48 overflow-y-auto">
                {filtered.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => { onSelect?.(p); setShowDropdown(false); setSearch(''); }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition-colors text-left"
                  >
                    <img src={p.image} alt={p.name} className="w-8 h-8 object-contain rounded" />
                    <div>
                      <p className="text-white text-sm font-medium">{p.name}</p>
                      <p className="text-white/40 text-xs capitalize">{p.category}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  const colors = categoryColors[product.category];

  return (
    <div className="flex-1 min-w-0">
      <div className="rounded-2xl overflow-hidden" style={{ background: 'oklch(0.18 0.03 38)', border: '1px solid oklch(1 0 0 / 0.1)' }}>
        {/* Image */}
        <div className="relative h-48 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #1A2B6B 0%, #0F1F5C 60%, #162055 100%)' }}>
          <img src={product.image} alt={product.name} className="h-full w-full object-contain p-4" />
          <div className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold ${colors.bg} ${colors.text} border ${colors.border}`}>
            {t.categories[product.category as keyof typeof t.categories]}
          </div>
          <button
            onClick={onRemove}
            className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/40 flex items-center justify-center text-white/60 hover:text-white hover:bg-black/60 transition-all"
          >
            <X size={14} />
          </button>
        </div>

        {/* Info */}
        <div className="p-5">
          <h3 className="text-white font-bold text-lg mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            {product.name}
          </h3>
          <p className="text-white/50 text-sm mb-4 leading-relaxed">{product.description}</p>

          {/* Flavor Notes */}
          <div className="mb-4">
            <p className="text-white/40 text-xs uppercase tracking-wider mb-2">{st.flavorNotes}</p>
            <div className="flex flex-wrap gap-1.5">
              {product.flavorNotes.map((note) => (
                <span key={note} className="px-2.5 py-1 rounded-full text-xs bg-white/5 text-white/60 border border-white/5">
                  {note}
                </span>
              ))}
            </div>
          </div>

          {/* Intensity */}
          <div className="mb-4">
            <div className="flex justify-between items-center mb-1.5">
              <p className="text-white/40 text-xs uppercase tracking-wider">{st.intensity}</p>
              <span className="text-[oklch(0.76_0.12_75)] text-xs font-semibold">{product.intensity}/5</span>
            </div>
            <IntensityBar value={product.intensity} />
          </div>

          {/* Nicotine */}
          <div className="mb-4">
            <p className="text-white/40 text-xs uppercase tracking-wider mb-2">{st.nicotine}</p>
            <div className="flex flex-wrap gap-1.5">
              {product.nicotineOptions.map((nic) => (
                <span key={nic} className="px-2.5 py-1 rounded-full text-xs bg-white/5 text-white/60 border border-white/5">
                  {nic}
                </span>
              ))}
            </div>
          </div>

          {/* Product ID */}
          <div className="flex justify-between items-center pt-3 border-t border-white/5">
            <span className="text-white/40 text-xs">{st.vgpg}</span>
            <span className="text-white text-sm font-semibold">{product.vgPgRatio}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function FlavorCompare({ products, onClose, onRemove }: FlavorCompareProps) {
  const { t, language } = useLanguage();
  const compareSubtitle = {
    zh: '选择两款口味进行对比',
    en: 'Select two flavors to compare side by side',
    ar: 'اختر نكهتين للمقارنة',
    ru: 'Выберите два вкуса для сравнения',
    ko: '비교할 두 가지 맛을 선택하세요',
  };
  const [localProducts, setLocalProducts] = useState<(Product | undefined)[]>([
    products[0],
    products[1],
  ]);

  const handleSelect = (index: number, product: Product) => {
    setLocalProducts((prev) => {
      const next = [...prev];
      next[index] = product;
      return next;
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'oklch(0 0 0 / 0.8)', backdropFilter: 'blur(8px)' }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl"
        style={{ background: 'oklch(0.15 0.025 40)', border: '1px solid oklch(1 0 0 / 0.1)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[oklch(0.76_0.12_75/0.10)] flex items-center justify-center">
              <ArrowLeftRight className="text-[oklch(0.76_0.12_75)]" size={20} />
            </div>
            <div>
              <h2 className="text-white font-bold text-xl" style={{ fontFamily: 'Syne, sans-serif' }}>
                {t.products.compareTitle}
              </h2>
              <p className="text-white/40 text-sm">{compareSubtitle[language as keyof typeof compareSubtitle] || compareSubtitle.zh}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
          >
            <X size={18} />
          </button>
        </div>

        {/* Compare Grid */}
        <div className="p-6">
          <div className="flex gap-4 items-start">
            <ProductSlot
              product={localProducts[0]}
              onRemove={() => { setLocalProducts([undefined, localProducts[1]]); onRemove(localProducts[0]?.id || ''); }}
              onSelect={(p) => handleSelect(0, p)}
            />

            {/* VS Divider */}
            <div className="flex flex-col items-center justify-center pt-20 shrink-0">
              <div className="w-10 h-10 rounded-full bg-[oklch(0.76_0.12_75/0.10)] border border-orange-500/20 flex items-center justify-center">
                <span className="text-[oklch(0.76_0.12_75)] text-xs font-bold">{t.products.vs}</span>
              </div>
            </div>

            <ProductSlot
              product={localProducts[1]}
              onRemove={() => { setLocalProducts([localProducts[0], undefined]); onRemove(localProducts[1]?.id || ''); }}
              onSelect={(p) => handleSelect(1, p)}
            />
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
