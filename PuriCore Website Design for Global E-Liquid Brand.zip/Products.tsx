// PuriCore Products Page — Enhanced filtering & sorting
// Category filter + nicotine filter + intensity filter + sort + search + compare

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, SlidersHorizontal, X, ArrowLeftRight, ChevronDown, Filter, RotateCcw, Loader2, ArrowUp } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { allProducts, fruitProducts, dessertProducts, tobaccoProducts, drinkProducts, Product, FlavorCategory, categoryColors } from '@/lib/products';
import ProductCard from '@/components/ProductCard';
import FlavorCompare from '@/components/FlavorCompare';

type CategoryFilter = 'all' | FlavorCategory;
type SortOption = 'name-asc' | 'name-desc' | 'intensity-asc' | 'intensity-desc';

const i18n = {
  filterPanel: { zh: '筛选面板', en: 'Filter Panel', ar: 'لوحة التصفية', ru: 'Панель фильтров', ko: '필터 패널' },
  category: { zh: '产品分类', en: 'Category', ar: 'الفئة', ru: 'Категория', ko: '카테고리' },
  nicotine: { zh: '烟碱浓度', en: 'Nicotine', ar: 'النيكوتين', ru: 'Никотин', ko: '니코틴' },
  intensity: { zh: '口味强度', en: 'Intensity', ar: 'الشدة', ru: 'Интенсивность', ko: '강도' },
  sortBy: { zh: '排序方式', en: 'Sort By', ar: 'ترتيب حسب', ru: 'Сортировать', ko: '정렬' },
  nameAsc: { zh: '名称 A→Z', en: 'Name A→Z', ar: 'الاسم أ→ي', ru: 'Имя А→Я', ko: '이름 A→Z' },
  nameDesc: { zh: '名称 Z→A', en: 'Name Z→A', ar: 'الاسم ي→أ', ru: 'Имя Я→А', ko: '이름 Z→A' },
  intensityHigh: { zh: '强度：高→低', en: 'Intensity: High→Low', ar: 'الشدة: عالي→منخفض', ru: 'Интенсивность: ↓', ko: '강도: 높음→낮음' },
  intensityLow: { zh: '强度：低→高', en: 'Intensity: Low→High', ar: 'الشدة: منخفض→عالي', ru: 'Интенсивность: ↑', ko: '강도: 낮음→높음' },
  searchPlaceholder: { zh: '搜索口味...', en: 'Search flavors...', ar: 'بحث عن نكهة...', ru: 'Поиск вкусов...', ko: '맛 검색...' },
  resetFilters: { zh: '重置筛选', en: 'Reset Filters', ar: 'إعادة تعيين', ru: 'Сбросить', ko: '필터 초기화' },
  showFilters: { zh: '显示筛选', en: 'Show Filters', ar: 'إظهار الفلاتر', ru: 'Показать фильтры', ko: '필터 표시' },
  hideFilters: { zh: '隐藏筛选', en: 'Hide Filters', ar: 'إخفاء الفلاتر', ru: 'Скрыть фильтры', ko: '필터 숨기기' },
  flavorsFound: { zh: '款口味', en: 'flavors found', ar: 'نكهة', ru: 'вкусов', ko: '맛 발견' },
  showing: { zh: '已显示', en: 'Showing', ar: 'عرض', ru: 'Показано', ko: '표시 중' },
  of: { zh: '/', en: 'of', ar: 'من', ru: 'из', ko: '/' },
  loadingMore: { zh: '加载更多...', en: 'Loading more...', ar: 'جار التحميل...', ru: 'Загрузка...', ko: '더 불러오는 중...' },
  allLoaded: { zh: '已显示全部产品', en: 'All products loaded', ar: 'تم تحميل جميع المنتجات', ru: 'Все продукты загружены', ko: '모든 제품 로드됨' },
  noResults: { zh: '未找到口味', en: 'No flavors found', ar: 'لم يتم العثور على نكهات', ru: 'Вкусы не найдены', ko: '맛을 찾을 수 없습니다' },
  tryAdjust: { zh: '请尝试调整搜索或筛选条件', en: 'Try adjusting your search or filters', ar: 'حاول تعديل البحث أو الفلاتر', ru: 'Попробуйте изменить поиск или фильтры', ko: '검색 또는 필터를 조정해 보세요' },
  all: { zh: '全部', en: 'All', ar: 'الكل', ru: 'Все', ko: '전체' },
  anyNicotine: { zh: '全部浓度', en: 'Any Nicotine', ar: 'أي نيكوتين', ru: 'Любой никотин', ko: '모든 니코틴' },
  anyIntensity: { zh: '全部强度', en: 'Any Intensity', ar: 'أي شدة', ru: 'Любая интенсивность', ko: '모든 강도' },
  activeFilters: { zh: '个筛选条件', en: 'active filters', ar: 'فلاتر نشطة', ru: 'активных фильтров', ko: '활성 필터' },
};

const nicotineOptions = ['0mg', '3mg', '6mg', '9.8mg', '20mg', '30mg', '50mg'];
const intensityLevels = [
  { value: 2, label: { zh: '轻柔', en: 'Mild', ar: 'خفيف', ru: 'Мягкий', ko: '마일드' } },
  { value: 3, label: { zh: '中等', en: 'Medium', ar: 'متوسط', ru: 'Средний', ko: '미디엄' } },
  { value: 4, label: { zh: '浓郁', en: 'Strong', ar: 'قوي', ru: 'Крепкий', ko: '스트롱' } },
  { value: 5, label: { zh: '极浓', en: 'Intense', ar: 'شديد', ru: 'Интенсивный', ko: '인텐스' } },
];

function tl(obj: Record<string, string>, lang: string) {
  return obj[lang] || obj.en;
}

export default function Products() {
  const { t, language } = useLanguage();

  const [activeCategory, setActiveCategory] = useState<CategoryFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [compareProducts, setCompareProducts] = useState<Product[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('name-asc');
  const [selectedNicotine, setSelectedNicotine] = useState<string | null>(null);
  const [selectedIntensity, setSelectedIntensity] = useState<number | null>(null);
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [visibleCount, setVisibleCount] = useState(12);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // Show/hide scroll-to-top button based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 600);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = useCallback(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const ITEMS_PER_BATCH = 12;

  // Read URL params for category
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cat = params.get('category') as FlavorCategory;
    if (cat && ['fruit', 'dessert', 'tobacco', 'drink'].includes(cat)) {
      setActiveCategory(cat);
    }
  }, []);

  // Reset visible count when filters change
  useEffect(() => {
    setVisibleCount(12);
  }, [activeCategory, selectedNicotine, selectedIntensity, searchQuery, sortBy]);

  // Infinite scroll with IntersectionObserver
  const loadMore = useCallback(() => {
    setIsLoadingMore(true);
    // Simulate a brief loading delay for smooth UX
    setTimeout(() => {
      setVisibleCount((prev) => prev + ITEMS_PER_BATCH);
      setIsLoadingMore(false);
    }, 300);
  }, []);

  const categories: { id: CategoryFilter; label: string; count: number }[] = [
    { id: 'all', label: t.categories.all, count: allProducts.length },
    { id: 'fruit', label: t.categories.fruit, count: fruitProducts.length },
    { id: 'dessert', label: t.categories.dessert, count: dessertProducts.length },
    { id: 'tobacco', label: t.categories.tobacco, count: tobaccoProducts.length },
    { id: 'drink', label: t.categories.drink, count: drinkProducts.length },
  ];

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (activeCategory !== 'all') count++;
    if (selectedNicotine) count++;
    if (selectedIntensity !== null) count++;
    if (searchQuery) count++;
    return count;
  }, [activeCategory, selectedNicotine, selectedIntensity, searchQuery]);

  const filteredProducts = useMemo(() => {
    return allProducts
      .filter((p) => activeCategory === 'all' || p.category === activeCategory)
      .filter((p) => selectedNicotine === null || p.nicotineOptions.includes(selectedNicotine))
      .filter((p) => selectedIntensity === null || p.intensity === selectedIntensity)
      .filter((p) =>
        searchQuery === '' ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.flavorNotes.some((n) => n.toLowerCase().includes(searchQuery.toLowerCase()))
      )
      .sort((a, b) => {
        switch (sortBy) {
          case 'name-asc': return a.name.localeCompare(b.name);
          case 'name-desc': return b.name.localeCompare(a.name);
          case 'intensity-desc': return b.intensity - a.intensity;
          case 'intensity-asc': return a.intensity - b.intensity;
          default: return 0;
        }
      });
  }, [activeCategory, selectedNicotine, selectedIntensity, searchQuery, sortBy]);

  const visibleProducts = useMemo(() => {
    return filteredProducts.slice(0, visibleCount);
  }, [filteredProducts, visibleCount]);

  const hasMore = visibleCount < filteredProducts.length;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting && !isLoadingMore && visibleCount < filteredProducts.length) {
          loadMore();
        }
      },
      { rootMargin: '200px' }
    );
    const el = loadMoreRef.current;
    if (el) observer.observe(el);
    return () => { if (el) observer.unobserve(el); };
  }, [loadMore, isLoadingMore, visibleCount, filteredProducts.length]);

  const resetFilters = () => {
    setActiveCategory('all');
    setSelectedNicotine(null);
    setSelectedIntensity(null);
    setSearchQuery('');
    setSortBy('name-asc');
  };

  const handleCompare = (product: Product) => {
    setCompareProducts((prev) => {
      if (prev.find((p) => p.id === product.id)) {
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= 2) {
        return [prev[1], product];
      }
      return [...prev, product];
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.04 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <p className="text-[oklch(0.76_0.12_75)] text-sm font-semibold uppercase tracking-wider mb-2">
            {t.products.title}
          </p>
          <h1 className="text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            {t.products.subtitle}
          </h1>
        </motion.div>

        {/* Top Bar: Search + Filter Toggle + Sort + Compare */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col md:flex-row gap-4 mb-6"
        >
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={tl(i18n.searchPlaceholder, language)}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] transition-all"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white">
                <X size={14} />
              </button>
            )}
          </div>

          <div className="flex gap-3 flex-wrap">
            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilterPanel(!showFilterPanel)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                showFilterPanel || activeFilterCount > 0
                  ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-lg shadow-[oklch(0.76_0.12_75/0.2)]'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              <SlidersHorizontal size={16} />
              <span>{showFilterPanel ? tl(i18n.hideFilters, language) : tl(i18n.showFilters, language)}</span>
              {activeFilterCount > 0 && (
                <span className="bg-white/20 text-xs px-1.5 py-0.5 rounded-full font-bold">
                  {activeFilterCount}
                </span>
              )}
            </button>

            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="appearance-none pl-3 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-[oklch(0.76_0.12_75/0.50)] cursor-pointer"
              >
                <option value="name-asc" className="bg-[oklch(0.17_0.03_38)]">{tl(i18n.nameAsc, language)}</option>
                <option value="name-desc" className="bg-[oklch(0.17_0.03_38)]">{tl(i18n.nameDesc, language)}</option>
                <option value="intensity-desc" className="bg-[oklch(0.17_0.03_38)]">{tl(i18n.intensityHigh, language)}</option>
                <option value="intensity-asc" className="bg-[oklch(0.17_0.03_38)]">{tl(i18n.intensityLow, language)}</option>
              </select>
              <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
            </div>

            {/* Compare Button */}
            <button
              onClick={() => setShowCompare(true)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                compareProducts.length > 0
                  ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              <ArrowLeftRight size={16} />
              {t.products.compare}
              {compareProducts.length > 0 && (
                <span className="bg-white/20 text-xs px-1.5 py-0.5 rounded-full">
                  {compareProducts.length}
                </span>
              )}
            </button>
          </div>
        </motion.div>

        {/* Expandable Filter Panel */}
        <AnimatePresence>
          {showFilterPanel && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="overflow-hidden"
            >
              <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 mb-6 backdrop-blur-sm">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Category Filter */}
                  <div>
                    <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                      <Filter size={12} />
                      {tl(i18n.category, language)}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {categories.map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => setActiveCategory(cat.id)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            activeCategory === cat.id
                              ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-md'
                              : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          <span>{cat.label}</span>
                          <span className={`text-[10px] px-1 py-0.5 rounded ${
                            activeCategory === cat.id ? 'bg-black/15' : 'bg-white/5'
                          }`}>
                            {cat.count}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Nicotine Filter */}
                  <div>
                    <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                      <Filter size={12} />
                      {tl(i18n.nicotine, language)}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setSelectedNicotine(null)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          selectedNicotine === null
                            ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-md'
                            : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        {tl(i18n.anyNicotine, language)}
                      </button>
                      {nicotineOptions.map((nic) => (
                        <button
                          key={nic}
                          onClick={() => setSelectedNicotine(selectedNicotine === nic ? null : nic)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            selectedNicotine === nic
                              ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-md'
                              : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          {nic}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Intensity Filter */}
                  <div>
                    <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                      <Filter size={12} />
                      {tl(i18n.intensity, language)}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setSelectedIntensity(null)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          selectedIntensity === null
                            ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-md'
                            : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        {tl(i18n.anyIntensity, language)}
                      </button>
                      {intensityLevels.map((level) => (
                        <button
                          key={level.value}
                          onClick={() => setSelectedIntensity(selectedIntensity === level.value ? null : level.value)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            selectedIntensity === level.value
                              ? 'bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] shadow-md'
                              : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          {/* Intensity dots */}
                          <span className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map((dot) => (
                              <span
                                key={dot}
                                className={`w-1.5 h-1.5 rounded-full ${
                                  dot <= level.value
                                    ? selectedIntensity === level.value ? 'bg-[oklch(0.15_0.04_38)]' : 'bg-[oklch(0.76_0.12_75)]'
                                    : 'bg-white/15'
                                }`}
                              />
                            ))}
                          </span>
                          <span>{tl(level.label, language)}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Reset Button */}
                {activeFilterCount > 0 && (
                  <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
                    <span className="text-white/30 text-xs">
                      {activeFilterCount} {tl(i18n.activeFilters, language)}
                    </span>
                    <button
                      onClick={resetFilters}
                      className="flex items-center gap-1.5 text-[oklch(0.76_0.12_75)] text-xs font-medium hover:text-[oklch(0.85_0.12_75)] transition-colors"
                    >
                      <RotateCcw size={12} />
                      {tl(i18n.resetFilters, language)}
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Active Filter Tags (shown when panel is collapsed) */}
        {!showFilterPanel && activeFilterCount > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-wrap gap-2 mb-6"
          >
            {activeCategory !== 'all' && (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[oklch(0.76_0.12_75/0.15)] text-[oklch(0.76_0.12_75)] text-xs font-medium border border-[oklch(0.76_0.12_75/0.2)]">
                {categories.find(c => c.id === activeCategory)?.label}
                <button onClick={() => setActiveCategory('all')} className="hover:text-white"><X size={12} /></button>
              </span>
            )}
            {selectedNicotine && (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[oklch(0.76_0.12_75/0.15)] text-[oklch(0.76_0.12_75)] text-xs font-medium border border-[oklch(0.76_0.12_75/0.2)]">
                {selectedNicotine}
                <button onClick={() => setSelectedNicotine(null)} className="hover:text-white"><X size={12} /></button>
              </span>
            )}
            {selectedIntensity !== null && (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[oklch(0.76_0.12_75/0.15)] text-[oklch(0.76_0.12_75)] text-xs font-medium border border-[oklch(0.76_0.12_75/0.2)]">
                {tl(intensityLevels.find(l => l.value === selectedIntensity)?.label || {en:''}, language)}
                <button onClick={() => setSelectedIntensity(null)} className="hover:text-white"><X size={12} /></button>
              </span>
            )}
            <button
              onClick={resetFilters}
              className="flex items-center gap-1 px-3 py-1 rounded-full text-white/40 text-xs hover:text-white/70 transition-colors"
            >
              <RotateCcw size={10} />
              {tl(i18n.resetFilters, language)}
            </button>
          </motion.div>
        )}

        {/* Results Count */}
        <div className="mb-6 text-white/40 text-sm flex items-center gap-2">
          <span>
            {tl(i18n.showing, language)} {Math.min(visibleCount, filteredProducts.length)} {tl(i18n.of, language)} {filteredProducts.length} {tl(i18n.flavorsFound, language)}
          </span>
          {searchQuery && <span>— "{searchQuery}"</span>}
          {/* Progress bar */}
          {filteredProducts.length > 0 && (
            <div className="hidden sm:flex items-center gap-2 ml-auto">
              <div className="w-24 h-1 rounded-full bg-white/10 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-[oklch(0.76_0.12_75)]" 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((visibleCount / filteredProducts.length) * 100, 100)}%` }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                />
              </div>
              <span className="text-xs text-white/30">
                {Math.round(Math.min((visibleCount / filteredProducts.length) * 100, 100))}%
              </span>
            </div>
          )}
        </div>

        {/* Products Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory + searchQuery + sortBy + (selectedNicotine || '') + (selectedIntensity || '')}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {visibleProducts.map((product) => (
              <motion.div key={product.id} variants={itemVariants}>
                <ProductCard
                  product={product}
                  showCompare
                  onCompare={handleCompare}
                  isCompared={compareProducts.some((p) => p.id === product.id)}
                />
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Infinite Scroll Sentinel & Loading Indicator */}
        {filteredProducts.length > 0 && (
          <div ref={loadMoreRef} className="flex flex-col items-center justify-center py-10">
            {isLoadingMore && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-3 text-white/40 text-sm"
              >
                <Loader2 size={18} className="animate-spin text-[oklch(0.76_0.12_75)]" />
                <span>{tl(i18n.loadingMore, language)}</span>
              </motion.div>
            )}
            {!hasMore && filteredProducts.length > ITEMS_PER_BATCH && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 text-white/25 text-xs"
              >
                <div className="w-8 h-px bg-white/10" />
                <span>{tl(i18n.allLoaded, language)}</span>
                <div className="w-8 h-px bg-white/10" />
              </motion.div>
            )}
          </div>
        )}

        {filteredProducts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-white text-xl font-semibold mb-2">{tl(i18n.noResults, language)}</h3>
            <p className="text-white/40 mb-6">{tl(i18n.tryAdjust, language)}</p>
            <button
              onClick={resetFilters}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[oklch(0.76_0.12_75)] text-[oklch(0.15_0.04_38)] text-sm font-semibold hover:brightness-110 transition-all"
            >
              <RotateCcw size={14} />
              {tl(i18n.resetFilters, language)}
            </button>
          </motion.div>
        )}
      </div>

      {/* Compare Modal */}
      <AnimatePresence>
        {showCompare && (
          <FlavorCompare
            products={compareProducts}
            onClose={() => setShowCompare(false)}
            onRemove={(id) => setCompareProducts((prev) => prev.filter((p) => p.id !== id))}
          />
        )}
      </AnimatePresence>

      {/* Scroll to Top Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            onClick={scrollToTop}
            className="fixed bottom-24 right-6 z-40 w-12 h-12 rounded-full bg-gradient-to-br from-[oklch(0.78_0.12_75)] to-[oklch(0.65_0.15_55)] text-[oklch(0.15_0.04_38)] shadow-lg shadow-[oklch(0.76_0.12_75/0.3)] hover:shadow-xl hover:shadow-[oklch(0.76_0.12_75/0.4)] hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center backdrop-blur-sm border border-[oklch(0.85_0.10_75/0.3)]"
            aria-label="Scroll to top"
          >
            <ArrowUp size={20} strokeWidth={2.5} />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
