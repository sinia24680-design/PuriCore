// PuriCore Home Page — "Tropical Drift" design
// Deep ocean blue + blazing orange, organic shapes, color-coded categories

import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { motion, useInView } from 'framer-motion';
import { ArrowRight, Star, ChevronLeft, ChevronRight, Play } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { featuredProducts, fruitProducts, dessertProducts, tobaccoProducts, drinkProducts, FlavorCategory } from '@/lib/products';
import ProductCard from '@/components/ProductCard';
import QuickPreviewModal from '@/components/QuickPreviewModal';
import { Product } from '@/lib/products';

const HERO_IMAGE = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-hero-label-style-NxsGgmoZDEZcX7r8DMRKa5.webp';
const STATS_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-stats-bg-nkyePzyuNMMU7wWKPhnfRk.webp';
const FRUIT_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-fruit-label-fvUU5KTK5HuhJCyPHevnCt.webp';
const DESSERT_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-label-BSFWK9cJZD6UKCeDJyFRq7.webp';
const TOBACCO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-label-V6ULjKJATUtRoGATM5atx3.webp';
const TOBACCO_HERO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-hero-R3ZtC4D95fb4QfknjDHFsv.webp';
const DESSERT_HERO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-hero-E82upMVx742WuEuBj7yApY.webp';
const SIGNATURE_SHOWCASE_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-signature-showcase-kYZJebqkGJz6tW2mANFzqZ.webp';
const TOBACCO_SHOWCASE_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-tobacco-showcase-bg-oHwiKnfLbLedsouFXtTsaL.webp';
const DESSERT_SHOWCASE_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-dessert-showcase-bg-MNGZAKK62BKuLmkkhaRtjK.webp';

// Signature Collections Section — Tobacco & Dessert brand manifesto
const signatureContent = {
  zh: {
    eyebrow: '招牌系列',
    headline: '烟草与甜品 — 我们的传世之作',
    body: 'PuriCore 的烟草与甜品系列远销全球，已成为行业内众多知名品牌产品的核心香气来源。我们的调香师以极致的工艺提炼每一滴精华，让您在 PuriCore 的香气中，感受到那些令世界著名品牌引以为傲的经典气息 — 只需一滴，即可找到世界级香气的共鸣。',
    tobaccoTitle: '烟草系列',
    tobaccoDesc: '从弗吉尼亚金叶到古巴雪茄，每款烟草口味均经过精密调配，呈现出层次丰富的烟草本味与细腻的木质、焦糖余韵。',
    dessertTitle: '甜品系列',
    dessertDesc: '法式马卡龙、奶油泡芙、香草焦糖 — 我们的甜品系列将糕点师的精湛工艺转化为令人沉醉的香气体验，每一口都是一场甜蜜的旅行。',
    cta: '探索系列',
  },
  en: {
    eyebrow: 'Signature Collections',
    headline: 'Tobacco & Dessert — Our Masterworks',
    body: "PuriCore's Tobacco and Dessert collections are distributed worldwide, serving as the foundational flavor profiles behind many of the industry's most recognized products. Our master perfumers distill each essence to its purest form — so when you experience a PuriCore aroma, you may find yourself recognizing the very same notes that define the world's most celebrated brands. One drop. A world of familiar excellence.",
    tobaccoTitle: 'Tobacco Collection',
    tobaccoDesc: 'From Virginia golden leaf to Cuban cigar, each tobacco expression is meticulously crafted to deliver rich, layered depth — with subtle undertones of wood, caramel, and aged complexity.',
    dessertTitle: 'Dessert Collection',
    dessertDesc: 'French macarons, vanilla cream puffs, salted caramel — our Dessert collection translates the artistry of the finest patisseries into captivating aromatic experiences. Every note is a journey into indulgence.',
    cta: 'Explore Collections',
  },
  ar: {
    eyebrow: 'المجموعات المميزة',
    headline: 'التبغ والحلويات — روائعنا الخالدة',
    body: 'تُوزَّع مجموعتا PuriCore للتبغ والحلويات في جميع أنحاء العالم، وتُشكّلان الأساس العطري لكثير من أبرز المنتجات في الصناعة. يُقطّر عطّارونا كل جوهر إلى أنقى صوره — فحين تستنشق عطر PuriCore، ستجد نفسك تتعرّف على ذات النوتات التي تُعرَّف بها أشهر العلامات التجارية في العالم.',
    tobaccoTitle: 'مجموعة التبغ',
    tobaccoDesc: 'من الورق الذهبي الفيرجيني إلى السيجار الكوبي، كل نكهة تبغ مُصمَّمة بعناية لتقديم عمق غني ومتعدد الطبقات مع نبرات خشبية وكراميل وتعقيد ناضج.',
    dessertTitle: 'مجموعة الحلويات',
    dessertDesc: 'ماكارون فرنسي، كريمة فانيليا، كراميل مملّح — تُترجم مجموعة الحلويات فن أرقى المعجنات إلى تجارب عطرية آسرة. كل نوتة رحلة إلى عالم الإغراء.',
    cta: 'استكشف المجموعات',
  },
  ru: {
    eyebrow: 'Фирменные коллекции',
    headline: 'Табак и десерты — наши шедевры',
    body: 'Коллекции табака и десертов PuriCore распространяются по всему миру и служат основой вкусовых профилей многих ведущих продуктов отрасли. Наши мастера-парфюмеры доводят каждую эссенцию до чистейшей формы — и когда вы ощущаете аромат PuriCore, вы можете узнать те самые ноты, которые определяют самые известные мировые бренды.',
    tobaccoTitle: 'Табачная коллекция',
    tobaccoDesc: 'От золотого листа Вирджинии до кубинской сигары — каждый табачный вкус тщательно создан для передачи богатой, многослойной глубины с тонкими нотами дерева, карамели и выдержанной сложности.',
    dessertTitle: 'Коллекция десертов',
    dessertDesc: 'Французские макаруны, ванильные эклеры, солёная карамель — наша коллекция десертов превращает искусство лучших кондитерских в захватывающие ароматические переживания.',
    cta: 'Исследовать коллекции',
  },
  ko: {
    eyebrow: '시그니처 컬렉션',
    headline: '담배 & 디저트 — 우리의 걸작',
    body: 'PuriCore의 담배 및 디저트 컬렉션은 전 세계에 유통되며, 업계에서 가장 잘 알려진 많은 제품의 핵심 향미 프로파일로 사용됩니다. 저희 마스터 조향사들은 각 에센스를 가장 순수한 형태로 증류합니다 — PuriCore의 향을 경험할 때, 세계적으로 유명한 브랜드를 정의하는 바로 그 노트를 발견하실 수 있습니다.',
    tobaccoTitle: '담배 컬렉션',
    tobaccoDesc: '버지니아 황금잎부터 쿠바 시가까지, 각 담배 향미는 나무, 캐러멜, 숙성된 복잡함의 미묘한 음조와 함께 풍부하고 다층적인 깊이를 전달하도록 정교하게 제작되었습니다.',
    dessertTitle: '디저트 컬렉션',
    dessertDesc: '프렌치 마카롱, 바닐라 크림 퍼프, 솔티드 캐러멜 — 디저트 컬렉션은 최고의 파티세리 예술을 매혹적인 향기 경험으로 변환합니다.',
    cta: '컬렉션 탐색',
  },
};

function SignatureCollectionsSection({ language }: { language: string }) {
  const content = signatureContent[language as keyof typeof signatureContent] || signatureContent.en;
  return (
    <section className="py-24 overflow-hidden" style={{ background: 'oklch(0.12 0.02 38)' }}>
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs font-semibold uppercase tracking-widest mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            {content.eyebrow}
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 max-w-3xl mx-auto leading-tight"
            style={{ fontFamily: 'Syne, sans-serif' }}>
            {content.headline}
          </h2>
          <p className="text-white/60 text-lg leading-relaxed max-w-3xl mx-auto">
            {content.body}
          </p>
        </motion.div>

        {/* Showcase Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-3xl overflow-hidden mb-16 shadow-2xl"
          style={{ border: '1px solid oklch(1 0 0 / 0.07)' }}
        >
          <img
            src={SIGNATURE_SHOWCASE_IMG}
            alt="PuriCore Tobacco & Dessert Signature Collections"
            className="w-full h-[420px] md:h-[520px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.12_0.025_240)] via-transparent to-transparent" />
        </motion.div>

        {/* Two-Column Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Tobacco Card */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="group relative overflow-hidden rounded-2xl"
            style={{ border: '1px solid oklch(1 0 0 / 0.08)' }}
          >
            <img
              src={TOBACCO_HERO_IMG}
              alt="Tobacco Collection"
              className="w-full h-72 object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-600/30 border border-amber-500/40 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                {content.tobaccoTitle}
              </div>
              <h3 className="text-white text-2xl font-bold mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
                {content.tobaccoTitle}
              </h3>
              <p className="text-white/65 text-sm leading-relaxed mb-5">{content.tobaccoDesc}</p>
              <Link href="/products?category=tobacco">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600/20 border border-amber-500/30 text-amber-300 text-sm font-medium hover:bg-amber-600/30 transition-all"
                >
                  {content.cta} <ArrowRight size={14} />
                </motion.button>
              </Link>
            </div>
          </motion.div>

          {/* Dessert Card */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="group relative overflow-hidden rounded-2xl"
            style={{ border: '1px solid oklch(1 0 0 / 0.08)' }}
          >
            <img
              src={DESSERT_HERO_IMG}
              alt="Dessert Collection"
              className="w-full h-72 object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-600/30 border border-pink-500/40 text-pink-300 text-xs font-semibold uppercase tracking-wider mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                {content.dessertTitle}
              </div>
              <h3 className="text-white text-2xl font-bold mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
                {content.dessertTitle}
              </h3>
              <p className="text-white/65 text-sm leading-relaxed mb-5">{content.dessertDesc}</p>
              <Link href="/products?category=dessert">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-pink-600/20 border border-pink-500/30 text-pink-300 text-sm font-medium hover:bg-pink-600/30 transition-all"
                >
                  {content.cta} <ArrowRight size={14} />
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Animated counter hook
function useCounter(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -50px 0px' });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target, duration]);

  // Fallback: if not triggered after 3s, show target
  useEffect(() => {
    const fallback = setTimeout(() => setCount(target), 3000);
    return () => clearTimeout(fallback);
  }, [target]);

  return { count, ref };
}

// Stats Counter Component
function StatItem({ value, label, suffix = '' }: { value: number; label: string; suffix?: string }) {
  const { count, ref } = useCounter(value);
  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-bold text-white mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
        {count.toLocaleString()}{suffix}
      </div>
      <div className="text-white/50 text-sm uppercase tracking-wider">{label}</div>
    </div>
  );
}

// Category Card Component
function CategoryCard({
  title,
  description,
  image,
  href,
  color,
  count,
  flavorsLabel,
  exploreLabel,
}: {
  title: string;
  description: string;
  image: string;
  href: string;
  color: string;
  count: number;
  flavorsLabel: string;
  exploreLabel: string;
}) {
  return (
    <Link href={href}>
      <motion.div
        whileHover={{ y: -8, scale: 1.02 }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className="relative overflow-hidden rounded-2xl cursor-pointer group h-64"
      >
        <img
          src={image}
          alt={title}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end p-6">
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium mb-2 w-fit ${color}`}>
            {count} {flavorsLabel}
          </div>
          <h3 className="text-white text-xl font-bold mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>{title}</h3>
          <p className="text-white/70 text-sm">{description}</p>
          <div className="flex items-center gap-1 mt-3 text-[oklch(0.76_0.12_75)] text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
            <span>{exploreLabel}</span>
            <ArrowRight size={14} />
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

// ===== PRODUCT SHOWCASE SECTION: TOBACCO & DESSERT =====
function ProductShowcaseSection({
  tobaccoList,
  dessertList,
}: {
  tobaccoList: Product[];
  dessertList: Product[];
}) {
  const [activeTab, setActiveTab] = useState<'tobacco' | 'dessert'>('tobacco');
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);

  const showcaseTobacco = tobaccoList.slice(0, 6);
  const showcaseDessert = dessertList.slice(0, 6);
  const activeList = activeTab === 'tobacco' ? showcaseTobacco : showcaseDessert;
  const activeBg = activeTab === 'tobacco' ? TOBACCO_SHOWCASE_BG : DESSERT_SHOWCASE_BG;

  const tabConfig = {
    tobacco: {
      label: 'Tobacco Series',
      labelZh: '烟草系列',
      eyebrow: 'SIGNATURE COLLECTION',
      headline: 'Aged, Bold & Timeless',
      sub: 'Inspired by the world\'s finest tobacco traditions — from Virginia leaf to Cuban cigar — each blend is a masterclass in depth and character.',
      accent: 'oklch(0.76 0.12 75)',
      accentBg: 'oklch(0.76 0.12 75 / 0.12)',
      accentBorder: 'oklch(0.76 0.12 75 / 0.3)',
      badge: '🍂 Premium Tobacco',
    },
    dessert: {
      label: 'Dessert Series',
      labelZh: '甜品系列',
      eyebrow: 'INDULGENT COLLECTION',
      headline: 'Sweet, Rich & Irresistible',
      sub: 'Crafted from the finest dessert inspirations — velvety caramel, warm vanilla, rich coffee — every drop is a moment of pure indulgence.',
      accent: 'oklch(0.82 0.14 55)',
      accentBg: 'oklch(0.82 0.14 55 / 0.12)',
      accentBorder: 'oklch(0.82 0.14 55 / 0.3)',
      badge: '🍮 Premium Dessert',
    },
  };
  const cfg = tabConfig[activeTab];

  return (
    <section className="py-0 overflow-hidden">
      {/* Full-width hero panel with background image */}
      <div className="relative min-h-[520px] flex items-center" style={{ background: 'oklch(0.10 0.02 38)' }}>
        {/* Background image with parallax-like overlay */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.img
            key={activeBg}
            src={activeBg}
            alt=""
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="w-full h-full object-cover"
          />
          {/* Dark gradient overlay — left side for text readability */}
          <div className="absolute inset-0" style={{
            background: 'linear-gradient(105deg, oklch(0.08 0.02 38 / 0.92) 0%, oklch(0.08 0.02 38 / 0.75) 45%, oklch(0.08 0.02 38 / 0.20) 100%)'
          }} />
        </div>

        <div className="container relative z-10 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text + Tab switcher */}
            <div>
              {/* Tab switcher */}
              <div className="inline-flex rounded-xl p-1 mb-8" style={{ background: 'oklch(1 0 0 / 0.08)', border: '1px solid oklch(1 0 0 / 0.12)' }}>
                {(['tobacco', 'dessert'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className="relative px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300"
                    style={{
                      color: activeTab === tab ? 'oklch(0.10 0.02 38)' : 'oklch(1 0 0 / 0.55)',
                      background: activeTab === tab
                        ? (tab === 'tobacco' ? 'linear-gradient(135deg, oklch(0.76 0.12 75), oklch(0.68 0.24 42))' : 'linear-gradient(135deg, oklch(0.82 0.14 55), oklch(0.76 0.12 75))')
                        : 'transparent',
                      boxShadow: activeTab === tab ? '0 2px 12px oklch(0.76 0.12 75 / 0.35)' : 'none',
                    }}
                  >
                    {tab === 'tobacco' ? '🍂 Tobacco' : '🍮 Dessert'}
                  </button>
                ))}
              </div>

              {/* Eyebrow */}
              <motion.p
                key={`eyebrow-${activeTab}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="text-xs font-bold uppercase tracking-[0.2em] mb-3"
                style={{ color: cfg.accent }}
              >
                {cfg.eyebrow}
              </motion.p>

              {/* Headline */}
              <motion.h2
                key={`headline-${activeTab}`}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.05 }}
                className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight"
                style={{ fontFamily: 'Syne, sans-serif' }}
              >
                {cfg.headline}
              </motion.h2>

              {/* Sub text */}
              <motion.p
                key={`sub-${activeTab}`}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-white/60 text-base leading-relaxed mb-8 max-w-md"
              >
                {cfg.sub}
              </motion.p>

              {/* Stats row */}
              <motion.div
                key={`stats-${activeTab}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.15 }}
                className="flex gap-8 mb-8"
              >
                <div>
                  <div className="text-2xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
                    {activeTab === 'tobacco' ? tobaccoList.length : dessertList.length}
                  </div>
                  <div className="text-white/40 text-xs uppercase tracking-wider">Flavors</div>
                </div>
                <div style={{ width: '1px', background: 'oklch(1 0 0 / 0.12)' }} />
                <div>
                  <div className="text-2xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>100+</div>
                  <div className="text-white/40 text-xs uppercase tracking-wider">Countries</div>
                </div>
                <div style={{ width: '1px', background: 'oklch(1 0 0 / 0.12)' }} />
                <div>
                  <div className="text-2xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>Est. 2004</div>
                  <div className="text-white/40 text-xs uppercase tracking-wider">Heritage</div>
                </div>
              </motion.div>

              {/* CTA */}
              <Link href={`/products?category=${activeTab}`}>
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-7 py-3.5 rounded-xl text-white font-semibold shadow-xl transition-all"
                  style={{
                    background: activeTab === 'tobacco'
                      ? 'linear-gradient(135deg, oklch(0.68 0.24 42), oklch(0.76 0.12 75))'
                      : 'linear-gradient(135deg, oklch(0.76 0.12 75), oklch(0.82 0.14 55))',
                    boxShadow: `0 8px 24px ${cfg.accent.replace(')', ' / 0.35)')}`,
                  }}
                >
                  Explore {activeTab === 'tobacco' ? 'Tobacco' : 'Dessert'} Series
                  <ArrowRight size={16} />
                </motion.button>
              </Link>
            </div>

            {/* Right: Product grid */}
            <div>
              <motion.div
                key={`grid-${activeTab}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="grid grid-cols-2 sm:grid-cols-3 gap-3"
              >
                {activeList.map((product, i) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: i * 0.06 }}
                    onHoverStart={() => setHoveredId(product.id)}
                    onHoverEnd={() => setHoveredId(null)}
                  >
                    {/* Clickable card — opens quick preview modal */}
                    <div
                      onClick={() => setPreviewProduct(product)}
                      className="relative rounded-xl overflow-hidden cursor-pointer transition-all duration-300"
                      style={{
                        background: 'linear-gradient(135deg, oklch(0.18 0.04 240), oklch(0.22 0.06 235))',
                        border: hoveredId === product.id
                          ? `1px solid ${cfg.accent}`
                          : '1px solid oklch(1 0 0 / 0.08)',
                        transform: hoveredId === product.id ? 'translateY(-4px)' : 'translateY(0)',
                        boxShadow: hoveredId === product.id
                          ? `0 12px 32px ${cfg.accent.replace(')', ' / 0.25)')}`
                          : '0 2px 8px oklch(0 0 0 / 0.3)',
                      }}
                    >
                      {/* Product image */}
                      <div className="aspect-square relative overflow-hidden">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover transition-transform duration-500"
                          style={{ transform: hoveredId === product.id ? 'scale(1.08)' : 'scale(1)' }}
                        />
                        {/* Quick preview hint on hover */}
                        {hoveredId === product.id && (
                          <div
                            className="absolute inset-0 flex items-center justify-center"
                            style={{ background: 'oklch(0 0 0 / 0.35)' }}
                          >
                            <span
                              className="text-xs font-semibold px-3 py-1.5 rounded-full"
                              style={{ background: cfg.accent, color: 'oklch(0.10 0.02 38)' }}
                            >
                              Quick View
                            </span>
                          </div>
                        )}
                        {/* Intensity badge */}
                        <div className="absolute top-2 right-2 flex gap-0.5">
                          {Array.from({ length: 5 }).map((_, j) => (
                            <div
                              key={j}
                              className="w-1.5 h-1.5 rounded-full"
                              style={{
                                background: j < product.intensity ? cfg.accent : 'oklch(1 0 0 / 0.2)',
                              }}
                            />
                          ))}
                        </div>
                      </div>
                      {/* Product info */}
                      <div className="p-3">
                        <p className="text-white text-xs font-semibold truncate mb-1">{product.name}</p>
                        <div className="flex flex-wrap gap-1">
                          {product.flavorNotes.slice(0, 2).map(note => (
                            <span
                              key={note}
                              className="text-[10px] px-1.5 py-0.5 rounded-full"
                              style={{ background: cfg.accentBg, color: cfg.accent, border: `1px solid ${cfg.accentBorder}` }}
                            >
                              {note}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>

              {/* View all link */}
              <div className="mt-4 text-right">
                <Link href={`/products?category=${activeTab}`}>
                  <span
                    className="text-sm font-medium inline-flex items-center gap-1 hover:gap-2 transition-all"
                    style={{ color: cfg.accent }}
                  >
                    View all {activeTab === 'tobacco' ? tobaccoList.length : dessertList.length} flavors
                    <ArrowRight size={14} />
                  </span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Quick Preview Modal */}
      <QuickPreviewModal
        product={previewProduct}
        onClose={() => setPreviewProduct(null)}
        accentColor={cfg.accent}
      />
    </section>
  );
}

export default function Home() {
  const { t, language } = useLanguage();

  // Localized CTA banner text
  const ctaContent = {
    zh: { title: '发现您的完美口味', desc: '160 款独特口味，四大类别，您理想的电子烟体验正在等待。' },
    en: { title: 'Discover Your Perfect Flavor', desc: 'With 160 unique flavors across four categories, your ideal vaping experience is waiting.' },
    ar: { title: 'اكتشف نكهتك المثالية', desc: 'مع أكثر من 160 نكهة فريدة عبر أربع فئات، تجربة التدخين الإلكتروني المثالية تنتظرك.' },
    ru: { title: 'Найдите свой идеальный вкус', desc: 'С 160 уникальными вкусами в четырёх категориях, ваш идеальный опыт вейпинга ждёт вас.' },
    ko: { title: '완벽한 맛을 발견하세요', desc: '4가지 카테고리에 걸쳐 160개 이상의 독특한 맛으로 이상적인 베이핑 경험이 기다립니다.' },
  };
  const cta = ctaContent[language as keyof typeof ctaContent] || ctaContent.zh;

  // Localized browse category tag
  const browseCategoryTag = {
    zh: '按类别浏览',
    en: 'Browse by Category',
    ar: 'تصفح حسب الفئة',
    ru: 'Обзор по категориям',
    ko: '카테고리별 탐색',
  };
  const browseCategoryText = browseCategoryTag[language as keyof typeof browseCategoryTag] || browseCategoryTag.zh;

  // Localized scroll text
  const scrollText = { zh: '滚动', en: 'Scroll', ar: 'مرر', ru: 'Прокрутить', ko: '스크롤' };
  const scrollLabel = scrollText[language as keyof typeof scrollText] || scrollText.zh;

  // Localized flavors count text
  const flavorsText = { zh: '款口味', en: 'flavors', ar: 'نكهة', ru: 'вкусов', ko: '가지 맛' };
  const flavorsLabel = flavorsText[language as keyof typeof flavorsText] || flavorsText.zh;

  // Localized explore text
  const exploreText = { zh: '探索', en: 'Explore', ar: 'استكشف', ru: 'Изучить', ko: '탐색' };
  const exploreLabel = exploreText[language as keyof typeof exploreText] || exploreText.zh;
  const [heroSlide, setHeroSlide] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);
  const heroInView = useInView(heroRef, { once: true });

  const heroSlides = [
    {
      title: t.hero.tagline,
      subtitle: t.hero.subtitle,
      badge: t.hero.badge,
      cta: t.hero.exploreBtn,
      href: '/products',
    },
    {
      title: t.categories.fruit,
      subtitle: t.categories.fruitDesc,
      badge: `14 ${t.products.title}`,
      cta: t.hero.exploreBtn,
      href: '/products?category=fruit',
    },
    {
      title: t.categories.dessert,
      subtitle: t.categories.dessertDesc,
      badge: `17+ ${t.products.title}`,
      cta: t.hero.exploreBtn,
      href: '/products?category=dessert',
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setHeroSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen">
      {/* ===== HERO SECTION ===== */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMAGE}
            alt="PuriCore Premium E-Liquid"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.10_0.03_240/0.90)] via-[oklch(0.10_0.03_240/0.60)] to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.10_0.03_240)] via-transparent to-transparent" />
        </div>

        {/* Floating Blob */}
        <div className="absolute top-20 right-20 w-96 h-96 opacity-10 pointer-events-none blob-shape"
          style={{ background: 'oklch(0.65 0.22 45)' }} />

        {/* Hero Content */}
        <div className="container relative z-10">
          <div className="max-w-2xl" ref={heroRef}>
            <motion.div
              key={heroSlide}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.6 }}
            >
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[oklch(0.76_0.12_75/0.15)] border border-[oklch(0.76_0.12_75/0.30)] text-[oklch(0.76_0.12_75)] text-xs font-medium mb-6">
                <Star size={12} className="fill-current" />
                {heroSlides[heroSlide].badge}
              </div>

              {/* Title */}
              <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6"
                style={{ fontFamily: 'Syne, sans-serif' }}>
                {heroSlides[heroSlide].title}
              </h1>

              {/* Subtitle */}
              <p className="text-white/70 text-lg leading-relaxed mb-8 max-w-lg">
                {heroSlides[heroSlide].subtitle}
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap gap-4">
                <Link href={heroSlides[heroSlide].href}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[oklch(0.68_0.24_42)] to-[oklch(0.76_0.12_75)] text-white font-semibold shadow-xl hover:shadow-[oklch(0.76_0.12_75/0.30)] transition-all"
                  >
                    {heroSlides[heroSlide].cta}
                    <ArrowRight size={18} />
                  </motion.button>
                </Link>
                <Link href="/case-studies">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 px-6 py-3.5 rounded-xl glass-card text-white font-medium hover:bg-white/10 transition-all"
                  >
                    <Play size={16} className="fill-current" />
                    {t.hero.watchVideo}
                  </motion.button>
                </Link>
              </div>
            </motion.div>

            {/* Slide Indicators */}
            <div className="flex gap-2 mt-10">
              {heroSlides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setHeroSlide(i)}
                  className={`h-1 rounded-full transition-all duration-300 ${
                    i === heroSlide ? 'w-8 bg-orange-400' : 'w-2 bg-white/30'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30"
        >
          <div className="w-px h-12 bg-gradient-to-b from-transparent to-white/30" />
          <span className="text-xs uppercase tracking-widest">{scrollLabel}</span>
        </motion.div>
      </section>

      {/* ===== STATS SECTION ===== */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img src={STATS_BG} alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-[oklch(0.13_0.025_40/0.85)]" />
        </div>
        <div className="container relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="text-center mb-12"
          >
            <motion.h2 variants={itemVariants} className="text-3xl font-bold text-white mb-3"
              style={{ fontFamily: 'Syne, sans-serif' }}>
              {t.stats.title}
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-3 gap-8 max-w-3xl mx-auto">
            <StatItem value={20} label={t.stats.flavorsLabel} suffix="" />
            <StatItem value={100} label={t.stats.countriesLabel} suffix="+" />
            <StatItem value={3} label={t.stats.customersLabel} suffix="" />
          </div>
        </div>
      </section>

      {/* ===== CATEGORIES SECTION ===== */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="mb-12"
          >
            <motion.p variants={itemVariants} className="text-[oklch(0.76_0.12_75)] text-sm font-semibold uppercase tracking-wider mb-2">
              {browseCategoryText}
            </motion.p>
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-white"
              style={{ fontFamily: 'Syne, sans-serif' }}>
              {t.products.title}
            </motion.h2>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <motion.div variants={itemVariants}>
              <CategoryCard
                title={t.categories.fruit}
                description={t.categories.fruitDesc}
                image={FRUIT_IMG}
                href="/products?category=fruit"
                color="badge-fruit"
                count={fruitProducts.length}
                flavorsLabel={flavorsLabel}
                exploreLabel={exploreLabel}
              />
            </motion.div>
            <motion.div variants={itemVariants}>
              <CategoryCard
                title={t.categories.dessert}
                description={t.categories.dessertDesc}
                image={DESSERT_IMG}
                href="/products?category=dessert"
                color="badge-dessert"
                count={dessertProducts.length}
                flavorsLabel={flavorsLabel}
                exploreLabel={exploreLabel}
              />
            </motion.div>
            <motion.div variants={itemVariants}>
              <CategoryCard
                title={t.categories.tobacco}
                description={t.categories.tobaccoDesc}
                image={TOBACCO_IMG}
                href="/products?category=tobacco"
                color="badge-tobacco"
                count={tobaccoProducts.length}
                flavorsLabel={flavorsLabel}
                exploreLabel={exploreLabel}
              />
            </motion.div>
            <motion.div variants={itemVariants}>
              <CategoryCard
                title={t.categories.drink}
                description={t.categories.drinkDesc}
                image="https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-drink-label-eySVoLDhmpgTwbbD6JdwaD.webp"
                href="/products?category=drink"
                color="badge-drink"
                count={drinkProducts.length}
                flavorsLabel={flavorsLabel}
                exploreLabel={exploreLabel}
              />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ===== FEATURED PRODUCTS ===== */}
      <section className="py-20 bg-[oklch(0.15_0.025_40)]">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="flex items-end justify-between mb-12"
          >
            <div>
              <motion.p variants={itemVariants} className="text-[oklch(0.76_0.12_75)] text-sm font-semibold uppercase tracking-wider mb-2">
                {t.products.featured}
              </motion.p>
              <motion.h2 variants={itemVariants} className="text-4xl font-bold text-white"
                style={{ fontFamily: 'Syne, sans-serif' }}>
                {t.products.subtitle}
              </motion.h2>
            </div>
            <motion.div variants={itemVariants}>
              <Link href="/products">
                <button className="flex items-center gap-2 text-[oklch(0.76_0.12_75)] hover:text-[oklch(0.82_0.10_78)] text-sm font-medium transition-colors">
                  {t.products.viewAll}
                  <ArrowRight size={16} />
                </button>
              </Link>
            </motion.div>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {featuredProducts.slice(0, 8).map((product) => (
              <motion.div key={product.id} variants={itemVariants}>
                <ProductCard product={product} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ===== SIGNATURE COLLECTIONS: TOBACCO & DESSERT ===== */}
      <SignatureCollectionsSection language={language} />

      {/* ===== PRODUCT SHOWCASE: TOBACCO & DESSERT ===== */}
      <ProductShowcaseSection tobaccoList={tobaccoProducts} dessertList={dessertProducts} />

      {/* ===== CTA BANNER ===== */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative overflow-hidden rounded-3xl p-10 md:p-16 text-center"
            style={{
              background: 'linear-gradient(135deg, oklch(0.18 0.03 38) 0%, oklch(0.22 0.04 38) 50%, oklch(0.18 0.03 38) 100%)',
              border: '1px solid oklch(1 0 0 / 0.08)',
            }}
          >
            {/* Decorative blobs */}
            <div className="absolute top-0 left-0 w-64 h-64 opacity-20 blob-shape"
              style={{ background: 'oklch(0.65 0.22 45)', transform: 'translate(-30%, -30%)' }} />
            <div className="absolute bottom-0 right-0 w-48 h-48 opacity-15 blob-shape"
              style={{ background: 'oklch(0.76 0.12 75)', transform: 'translate(30%, 30%)', animationDelay: '4s' }} />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[oklch(0.76_0.12_75/0.15)] border border-[oklch(0.76_0.12_75/0.30)] text-[oklch(0.76_0.12_75)] text-xs font-medium mb-6">
                <Star size={12} className="fill-current" />
                {t.hero.badge}
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4"
                style={{ fontFamily: 'Syne, sans-serif' }}>
                {cta.title}
              </h2>
              <p className="text-white/60 text-lg mb-8 max-w-xl mx-auto">
                {cta.desc}
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Link href="/products">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[oklch(0.68_0.24_42)] to-[oklch(0.76_0.12_75)] text-white font-semibold shadow-xl hover:shadow-[oklch(0.76_0.12_75/0.30)] transition-all text-lg"
                  >
                    {t.hero.exploreBtn}
                    <ArrowRight size={20} />
                  </motion.button>
                </Link>
                <Link href="/flavors">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 px-8 py-4 rounded-xl glass-card text-white font-medium hover:bg-white/10 transition-all text-lg"
                  >
                    {t.nav.flavors}
                  </motion.button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
