#!/usr/bin/env python3
"""
Match website product names to Excel IDs and replace vgPgRatio values.
The Excel has various naming conventions, so we need fuzzy matching.
"""
import json
import re

# Load the Excel name->ID mapping
with open("/home/ubuntu/name_to_id.json") as f:
    excel_map = json.load(f)

# Read the products.ts file
with open("/home/ubuntu/puricore/client/src/lib/products.ts") as f:
    content = f.read()

# Extract all product names from products.ts
product_names = re.findall(r"name:\s*'([^']+)'", content)
print(f"Total products in website: {len(product_names)}")

# Build a comprehensive lookup with normalized keys
# Normalize: lowercase, strip, remove extra spaces
def normalize(s):
    return re.sub(r'\s+', ' ', s.strip().lower())

excel_normalized = {}
for name, id_val in excel_map.items():
    n = normalize(name)
    excel_normalized[n] = id_val

# Build manual mapping for website product names that don't directly match Excel names
# Website Name -> Excel Name (or direct ID)
manual_mapping = {
    # Tobacco products
    'Nutty Cream Catsle Long': 'Nutty Cream(Catsle long)',
    'Apple Majesty Gambit': 'Apple Majesty(Gambit)',
    'Tobacco Valen Cigars': 'Valen Cigars',
    'Tobacco Vgod Cubano': 'Vgod Cubano',
    'Tobacco Master': 'Master',
    'Tobacco Mild': 'Mild',
    'Tobacco Cream': 'Cream',
    'Gold Tobacco': 'Gold tobacco（Ignis）',
    'PuriCore Almond Cream': 'Almond Cream',
    'PuriCore Cigar': 'Cigar',
    'Cubana Cigar': 'Cubana Cigar',
    'Dry Tobacco': 'Dry Tobacco',
    'RY4 Tobacco': 'RY4',
    'Grand Master': 'Grand Master',
    'Vanilla Cigar': 'Vanilla Cigar',
    'Cream of the Crop': 'Cream of the crop',
    'Wizzle': 'Wizzle',
    
    # Dessert/Food products
    'Lemon Cake': 'Lemon cake',
    'Banana Cake': 'Banana cake',
    'Apple Pie': 'Apple pie',
    'Apple Mango Binsu': 'Apple mango  binsu',
    'Cheese Chips': 'Cheese Chips',
    'Gold Ccin': 'Gold Ccin',
    'Milk Tea': 'Milk Tea',
    'Butterscotch': 'Butterscotch',
    'Coconut Rum': 'Coconut Rum',
    'Popcorn': 'Popcorn',
    'Caramel Popcorn': 'Caramel popcorn',
    'Cheese Crisps': 'Cheese crisps',
    'Macadamia Nut Cream': 'Macadamia nut cream',
    'Milk Soda Milk': 'Soda Milk',
    'Sweet Milk': 'Sweet Milk',
    'Coffee Milk': 'Coffee milk',
    'Strawberry Milk': 'Strawberry milk',
    'Matcha Latte': 'Matcha Latte',
    'Lemon Candy': 'Lemon Candy',
    'Coffee Flavor': 'Coffee Flavor',
    'Coffee Einspanner': 'Einspanner',
    'Coffee Toffee Nut Latte': 'Toffee Nut Latte',
    'Luwak Americano': 'Luwak americano',
    'Caramel Macchiato': 'Caramel Macchiato',
    'Milk Strawberry Yogurt': 'Strawberry Yogurt',
    
    # Drink products
    'Carbonated': 'Carbonated',
    'Cola': 'Cola',
    'Ice Soda': 'Ice Soda',
    'Drinks Soda': 'Soda',
    'Drinks Soda Flavor': 'Soda Flavor',
    'Soft Drink': 'Soft drink',
    'Orange Soda': 'Orange soda',
    'Zero Cider': 'Zero Cider',
    'PuriCore Energy Drink': 'Energy Drink',
    'LAPOSA': 'LAPOSA',
    'Red Wings': 'Red Wings',
    'PuriCore Ice Yacool': 'Ice Yacool',
    'Ice Aloe Punch': 'ICE ALOE PUNCH',
    'Ice Cherry Punch': 'ICE CHERRY PUNCH',
    'Ice Grape Punch': 'ICE GRAPE PUNCH',
    'Pine D Lemon Soda': 'PINE D LEMON SODA',
    'Green Titan Punch': 'GREEN TITAN PUNCH',
    'Lemon Green Tea': 'Lemon Green Tea',
    'Grapes Lemon Green Tea': 'Lemon green tea',
    'Green Tea Ice': 'GREEN TEA ICE',
    'Honey Green Tea': 'Honey green Tea',
    'Boss Honey Green Tea': 'BOSS HONEY GREEN TEA',
    'PuriCore Honey Green Tea': 'HONEY GREEN TEA',
    'Black Tea': 'Black Tea',
    'Bing Hong Cha': 'Bing Hong Cha',
    'Jasmine Muscat Tea': 'Jasmine Muscat tea',
    'Lil.S.Long': 'Lil.S.Long',
    'Lemon Fine Lemonade': 'Fine Lemonade',
    
    # Fruit products
    'Peach and Mango': None,  # Korean name in Excel: 피치 망고（Peach&Mango）
    'Sweet Lemon': 'Sweet Lemon',
    'Passion Fruit': 'Passion fruit',
    'Cherry Origin': 'Cherry origin',
    'Grape Flavor': 'Grape Flavor',
    'Grape Kick': 'Grape Kick',
    'Grape Kick Ice': 'GRAPE KICK ICE',
    'Grapes': None,  # Multiple grape entries
    'Grapes Deep Shine': 'Deep Shine',
    'Grapes Grape Snow': 'Grape snow',
    'Grapes Green Grape': None,  # Korean: 청포도（Green Grape）
    'Grapes Shine': 'Shine(no ice)',
    'Grapes Shinemuscat Ice': 'Shinemuscat ice',
    'Grapes no Ice': 'grape(no ice)',
    'Green Grape': 'Green Grape',
    'Fantasie Grape': 'Fantasie Grape',
    'PuriCore Grape': None,  # grape
    'Kyoho Grape': 'Kyoho',
    'Sour Grape': 'Sour Grape',
    'Sapphire Grape Ice': 'Sapphire Grape ice',
    'Red Grape': 'Red grape',
    'Aloe Vera': 'Aloe vera',
    'Aloe Snow': 'Aloe snow',
    'Aloe Vera Aloe Kick': 'Aloe Kick',
    'Apple': 'Apple',
    'Apple Lime': 'Apple lime',
    'PuriCore Apple': 'Apple',
    'Blackberry Ice': 'Blackberry ice',
    'Berry Kick': 'Berry Kick',
    'Berry PuriCore': 'Berry',
    'Berry Snow': 'Berry snow',
    'Kingsberry': 'Kingsberry',
    'Sourberry': None,  # Korean: 샤워베리（树莓）（Sourberry）
    'Cherry Pomegranate': 'Cherry pomegranate',
    'Sweet Cherry': 'Sweet Cherry',
    'Densuke Watermelon Ice': 'Densuke subak ice',
    'Golden Kiwifruit and Lemon': None,  # Korean
    'Jackfruit Kick': 'Jackfruit Kick',
    'Jackfruit Kick Ice': 'JACKFRUIT KICK ICE',
    'Kiwi': 'Kiwi',
    'Kiwi Passion Wave': 'Kiwi Passion Wave',
    'Lamongsa PuriCore': 'LAMONGSA',
    'Lemon': 'lemon',
    'Lemon Ice': None,  # Not directly in Excel
    'Lemon Lime D Lime': 'LIME D LIME',
    'Lemon Lime Flavor': 'Lime Flavor',
    'Lemon Sweet Lemon': 'Sweet Lemon',
    'Lemon Sweet Lime': 'Sweet Lime',
    'PuriCore Lemon': 'lemon',
    'PuriCore Lemon Lime': 'Lime',
    'Lychee Korean': 'Lychee',
    'PuriCore Lychee': 'Lychee',
    'Mangosteen': 'Mangosteen',
    'Mangosteen Ice': 'Mangosteen ice',
    'Melon': 'Melon',
    'Mint': 'Mint',
    'Mint Black Menthol': 'Black Menthol',
    'PuriCore Mint Green Menthol': 'Green menthol',
    'Sweet Mint': 'Sweet Mint',
    'Orange': 'Orange',
    'PuriCore Fantasie Orange': 'Fantasie Orange',
    'Passion Fruit Fashion Fruits': None,  # Korean
    'Passion Fruit Golden Markisa Ice': 'Golden markisa ice',
    'Passion Fruit Markisa': 'Markisa',
    'Peach Blossom': 'Peach Blossom',
    'Peach Plum': 'Peach Plum',
    'Pineapple': 'Pineapple',
    'Pineapple Pink Pineapple Ice': 'Pink pineapple ice',
    'Plum': 'Plum',
    'Plum Grape': 'Plum  grape',
    'PuriCore Grapefruit': 'Grapefruit',
    'PuriCore Grapefruit Ice': 'Grapefruit ice',
    'PuriCore Strawberry Grape': None,  # Korean: 딸기 포도
    'Rock Sugar Pear': 'Rock Sugar Pear',
    'Rozelle Heart': 'Rozelle Heart',
    'Strawberry': 'Strawberry',
    'Strawberry Banana': 'Strawberry banana',
    'Strawberry Ice': None,  # Korean: 딸기 아이스（Strawberry Ice）
    'Tropical Wave': 'Tropical Wave',
    'Mix Flavors Grapefruit Orange': None,  # Korean
    'Mix Flavors Lime Green Apple': 'Lime Green Apple',
    'Apricot Korean': None,  # Korean: 아프리콧（Apricot）
    'Apricot PuriCore': 'Yellow apricot',
    'Grape Ice': None,  # Korean: 포도 아이스（Grape Ice）
    
    # New dessert products (from the latest batch)
    'French Croissant': None,
    'Toffee': None,
    'Strawberry Cheesecake': None,
    'Irish Cream': None,
    'Rum Raisin': None,
    'Blueberry Cheesecake': None,
    'Cream Whiskey': None,
    'Toasted Marshmallow': None,
    'Matcha Ice Cream': None,
    'Apple Cookie': None,
    'Black Coffee': None,
    'Apple Cinnamon Roll': None,
    'Cappuccino': None,
    'Vanilla Caramel Cream Coffee': None,
    'Blueberry Muffin': None,
    'Cinnamon Apple Pie': None,
    'Hazelnut Latte': None,
    'Custard Donut': None,
    'Chocolate Lava Cake': None,
    'Cotton Candy': None,
    'Maple Waffle': None,
    'Lemon Tart': None,
    'Coconut Cream Pie': None,
    'Honey Butter': None,
    'Strawberry Cream Cake': None,
    'Brown Sugar Bubble Tea': None,
    'Caramel Pudding': None,
    'Vanilla Ice Cream': None,
    'Vanilla Panna Cotta': None,
    'Cinnamon Roll': None,
    'Hazelnut Chocolate': None,
    'White Chocolate Raspberry': None,
    
    # New tobacco products
    'Menthol Tobacco': None,
    'Honey Tobacco': None,
    'Vanilla Tobacco': None,
    'Nutty Tobacco': None,
    'Virginia Tobacco': None,
    'Cigar Tobacco': None,
    'Classic Tobacco': None,
}

# Also handle Korean name lookups
korean_mappings = {
    'Peach and Mango': '피치 망고（Peach&Mango）',
    'Grapes Green Grape': '청포도（Green Grape）',
    'Golden Kiwifruit and Lemon': '골든키위 레몬（Golden Kiwifruit & Lemon）',
    'Passion Fruit Fashion Fruits': '패션후루츠（Fashion Fruits）',
    'PuriCore Strawberry Grape': '딸기 포도（ Strawberry & Grape）',
    'Strawberry Ice': '딸기 아이스（Strawberry Ice）',
    'Mix Flavors Grapefruit Orange': '자몽 오렌지（Grapefruit Orange）',
    'Apricot Korean': '아프리콧（Apricot）',
    'Grape Ice': '포도 아이스（Grape Ice）',
    'Sourberry': '샤워베리（树莓）（Sourberry）',
}

# Resolve all mappings
def get_id_for_product(product_name):
    """Try multiple strategies to find the Excel ID for a product name."""
    
    # Strategy 1: Direct manual mapping
    if product_name in manual_mapping:
        excel_name = manual_mapping[product_name]
        if excel_name is not None and excel_name in excel_map:
            return excel_map[excel_name]
    
    # Strategy 2: Korean name mapping
    if product_name in korean_mappings:
        korean_name = korean_mappings[product_name]
        if korean_name in excel_map:
            return excel_map[korean_name]
    
    # Strategy 3: Direct match in Excel
    if product_name in excel_map:
        return excel_map[product_name]
    
    # Strategy 4: Case-insensitive match
    pn = normalize(product_name)
    if pn in excel_normalized:
        return excel_normalized[pn]
    
    # Strategy 5: Try removing "PuriCore" prefix
    cleaned = product_name.replace('PuriCore ', '').replace('puricore ', '')
    if cleaned in excel_map:
        return excel_map[cleaned]
    cn = normalize(cleaned)
    if cn in excel_normalized:
        return excel_normalized[cn]
    
    # Strategy 6: Try the grape special case
    if 'Grapes' in product_name:
        # Try without "Grapes " prefix
        short = product_name.replace('Grapes ', '')
        if short in excel_map:
            return excel_map[short]
        sn = normalize(short)
        if sn in excel_normalized:
            return excel_normalized[sn]
    
    return None

# Process all products and build replacement map
print("\n=== MATCHING RESULTS ===")
matched = 0
unmatched = 0
replacements = {}  # product_name -> id

for name in product_names:
    id_val = get_id_for_product(name)
    if id_val:
        replacements[name] = id_val
        matched += 1
        print(f"  ✓ {name} -> {id_val}")
    else:
        unmatched += 1
        print(f"  ✗ {name} -> NO MATCH")

print(f"\nMatched: {matched}, Unmatched: {unmatched}")

# Now perform the replacement in the file
# We need to find each product block and replace its vgPgRatio
lines = content.split('\n')
new_lines = []
current_name = None
replacements_made = 0

for i, line in enumerate(lines):
    # Track current product name
    name_match = re.match(r"\s+name:\s*'([^']+)'", line)
    if name_match:
        current_name = name_match.group(1)
    
    # Replace vgPgRatio if we have a mapping for current product
    vgpg_match = re.match(r"(\s+vgPgRatio:\s*)'[^']+'", line)
    if vgpg_match and current_name and current_name in replacements:
        new_id = replacements[current_name]
        new_line = f"{vgpg_match.group(1)}'{new_id}'"
        # Keep trailing comma if present
        if line.rstrip().endswith(','):
            new_line += ','
        new_lines.append(new_line)
        replacements_made += 1
    else:
        new_lines.append(line)

print(f"\nReplacements made in file: {replacements_made}")

# Write the updated file
with open("/home/ubuntu/puricore/client/src/lib/products.ts", "w") as f:
    f.write('\n'.join(new_lines))

print("File updated successfully!")
