#!/usr/bin/env python3
"""Read the Excel file and extract Name -> ID mapping from Sheet1."""
import openpyxl
import json

wb = openpyxl.load_workbook("/home/ubuntu/upload/PuriCore.Flavorlist.xlsx")

# Read Sheet1 (the main flavor list)
ws = wb["Sheet1"]

# Print all rows to understand the full structure
print("=== Sheet1 Full Data ===")
mappings = {}
current_category = None
for row in ws.iter_rows(min_row=3, values_only=True):  # Skip header rows
    no, category, name, id_val = row
    if category:
        current_category = category
    if name and id_val:
        name_clean = str(name).strip()
        id_clean = str(id_val).strip()
        print(f"  [{current_category}] {name_clean} -> {id_clean}")
        mappings[name_clean] = id_clean

print(f"\nTotal mappings: {len(mappings)}")

# Also read 30ml sheet
ws2 = wb["30ml"]
print("\n=== 30ml Sheet Data ===")
for row in ws2.iter_rows(min_row=1, values_only=True):
    no, name, cn_name, id_val = row
    if name and id_val and str(name).strip() != "Name":
        name_clean = str(name).strip()
        id_clean = str(id_val).strip()
        print(f"  {name_clean} -> {id_clean}")
        # Don't overwrite Sheet1 mappings
        if name_clean not in mappings:
            mappings[name_clean] = id_clean

print(f"\nTotal mappings after 30ml: {len(mappings)}")

# Save to JSON
with open("/home/ubuntu/name_to_id.json", "w") as f:
    json.dump(mappings, f, indent=2, ensure_ascii=False)

print("\nSaved to /home/ubuntu/name_to_id.json")
