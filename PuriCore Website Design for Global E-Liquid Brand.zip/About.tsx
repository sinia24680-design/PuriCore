// PuriCore About Page — "Tropical Drift" design
// Design: Deep navy #0B1F3A base, orange #F97316 accent, Syne display + Inter body
import { motion } from 'framer-motion';
import { Shield, Globe, Users, FlaskConical, Microscope, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const STATS_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-stats-bg-nkyePzyuNMMU7wWKPhnfRk.webp';

export default function About() {
  const { t, language } = useLanguage();

  const content = {
    zh: {
      heroTitle: '源自中国的\n顶级香精工厂',
      heroDesc: '扎根中国，深耕行业二十年。我们是韩国市场最大的电子烟油香精供应商，也是全球顶级烟油品牌背后值得信赖的源头。',
      storyTag: '我们的故事',
      storyTitle: '我们不只是供应商，我们是源头',
      storyP1: 'PuriCore 是一家总部位于中国的顶级香精工厂，深耕行业已逾二十年。作为韩国市场规模最大的电子烟油香精供应商，我们自豪地成为全球众多知名烟油品牌与电子烟油生产商的核心合作伙伴。我们的 ISO 认证生产设施确保每一滴产品都符合最高品质标准。',
      storyP2: '我们不只是供应商——我们是源头。无论您需要定制香精开发，还是完整的研发支持，我们的专业团队都将与您紧密协作，将创意变为现实。依托与多所高校建立的深度合作关系，我们将实战经验与前沿创新融为一体。',
      storyP3: '从我们的实验室走向世界——让我们携手，共创非凡。',
      timeline: [
        { year: '2014', event: '公司于中国正式成立' },
        { year: '2019', event: '正式进入韩国市场' },
        { year: '2020', event: '与韩国企业初步达成合作' },
        { year: '2021', event: '与英国电子烟生产企业达成合作' },
        { year: '2022', event: '成为韩国市场电子烟油香精主力企业' },
        { year: '2025', event: '覆盖韩国、英国、美国等国，100+ 款口味' },
      ],
      valuesTag: '我们的价值观',
      valuesTitle: '我们的坚守',
      values: [
        { title: 'ISO 认证品质', description: '我们的生产设施通过 ISO 认证，每一批次产品均经过严格检测，确保品质稳定如一。' },
        { title: '定制研发支持', description: '从概念到成品，我们的研发团队全程陪伴，为您量身打造专属香精配方。' },
        { title: '全球市场覆盖', description: '产品远销韩国、英国、美国等多个国家，深受国际顶级品牌的长期信赖。' },
        { title: '高校联合创新', description: '与多所知名高校建立战略合作，将学术前沿研究转化为领先市场的产品创新。' },
      ],
      rdTag: '现场研发服务',
      rdTitle: '您的品牌，在我们的实验室诞生',
      rdDesc: '我们深知，一款真正出色的口味，不只是配方——它是品牌灵魂的延伸。这就是为什么我们邀请客户亲赴我们的研发中心，与专业调香师面对面协作，将您对品牌的理解直接融入每一个香气层次之中。',
      rdFeatures: [
        {
          icon: 'flask',
          title: '专属调香工作坊',
          description: '客户可亲临我们的研发中心，与资深调香师共同参与口味的创作过程。从初步概念到最终定稿，每一个细节都由您亲自把关。',
        },
        {
          icon: 'microscope',
          title: '专业调香师团队',
          description: '我们的调香师拥有深厚的香精化学背景，擅长将品牌愿景转化为精准的感官体验。他们不只是技术专家，更是您口味故事的共同创作者。',
        },
        {
          icon: 'star',
          title: '全程品牌定制',
          description: '无论您追求的是清新果香、馥郁甜韵还是醇厚烟草，我们都能为您量身打造专属配方，确保每一款产品都与您的品牌形象高度契合。',
        },
      ],
      rdCta: '预约现场研发咨询',
    },
    en: {
      heroTitle: 'A Premium Flavor House\nBased in China',
      heroDesc: 'Rooted in China. Refined over 20 years. The largest supplier of e-liquid flavors in South Korea — and the trusted source behind the world\'s top vape brands.',
      storyTag: 'Our Story',
      storyTitle: 'We\'re Not Just a Supplier — We\'re the Source',
      storyP1: 'PuriCore is a premium flavor house based in China, and we\'ve been in the game for 20 years. As the largest supplier of e-liquid flavors in South Korea, we\'re proud to be the go-to source for some of the world\'s top vape brands and e-liquid producers. Our ISO-certified facilities ensure every drop meets the highest standards.',
      storyP2: 'But we\'re more than just a supplier — we\'re the source. Whether you need custom flavor development or full R&D support, our team works closely with you to bring your ideas to life. With strong partnerships across multiple universities, we combine real-world expertise with cutting-edge innovation.',
      storyP3: 'From our lab to the world — let\'s create something great together.',
      timeline: [
        { year: '2014', event: 'Founded in China' },
        { year: '2019', event: 'Officially entered the South Korean market' },
        { year: '2020', event: 'Initial partnerships with Korean enterprises' },
        { year: '2021', event: 'Partnership with UK e-liquid manufacturers' },
        { year: '2022', event: 'Became the leading e-liquid flavor supplier in Korea' },
        { year: '2025', event: 'Covering Korea, UK, USA & more — 100+ flavors' },
      ],
      valuesTag: 'Our Values',
      valuesTitle: 'What We Stand For',
      values: [
        { title: 'ISO-Certified Quality', description: 'Our ISO-certified facilities ensure every batch is rigorously tested, delivering consistent quality in every drop.' },
        { title: 'Custom R&D Support', description: 'From concept to finished product, our R&D team works alongside you to craft bespoke flavor formulas.' },
        { title: 'Global Market Reach', description: 'Trusted by top international brands across South Korea, the UK, the USA, and beyond.' },
        { title: 'University Partnerships', description: 'Strategic collaborations with leading universities translate cutting-edge research into market-leading innovations.' },
      ],
      rdTag: 'On-Site R&D Experience',
      rdTitle: 'Your Brand, Born in Our Lab',
      rdDesc: 'Great flavor is more than chemistry — it\'s the expression of your brand\'s identity. That\'s why we open our doors to clients, inviting you to step into our R&D center and co-create alongside our master flavorists. Your vision, your brief, your brand DNA — translated into every aromatic note.',
      rdFeatures: [
        {
          icon: 'flask',
          title: 'Dedicated Flavor Workshops',
          description: 'Clients are welcome to visit our R&D facility and work directly with our senior flavorists. From initial concept to final sign-off, every decision is yours to make — in real time.',
        },
        {
          icon: 'microscope',
          title: 'Master Flavorist Team',
          description: 'Our flavorists bring deep expertise in flavor chemistry and a sharp creative instinct. They don\'t just formulate — they listen, interpret, and craft sensory experiences that speak for your brand.',
        },
        {
          icon: 'star',
          title: 'Full Brand Customization',
          description: 'Whether you\'re after a crisp fruit burst, a rich dessert finish, or a smooth tobacco draw, we engineer every profile to align precisely with your brand positioning and target market.',
        },
      ],
      rdCta: 'Book an On-Site Consultation',
    },
    ar: {
      heroTitle: 'دار نكهات فاخرة\nمقرها الصين',
      heroDesc: 'متجذرون في الصين. مصقولون على مدى 20 عامًا. أكبر مورد لنكهات السائل الإلكتروني في كوريا الجنوبية — والمصدر الموثوق وراء أبرز علامات التدخين الإلكتروني في العالم.',
      storyTag: 'قصتنا',
      storyTitle: 'لسنا مجرد مورد — نحن المصدر',
      storyP1: 'بيوريكور هي دار نكهات فاخرة مقرها الصين، ونحن في هذا المجال منذ 20 عامًا. بوصفنا أكبر مورد لنكهات السائل الإلكتروني في كوريا الجنوبية، نفخر بكوننا المصدر الأول لبعض أبرز علامات التدخين الإلكتروني في العالم. تضمن منشآتنا المعتمدة بمعايير ISO أن كل قطرة تلبي أعلى المعايير.',
      storyP2: 'لكننا أكثر من مجرد مورد — نحن المصدر. سواء كنت بحاجة إلى تطوير نكهة مخصصة أو دعم بحث وتطوير كامل، يعمل فريقنا معك عن كثب لتحويل أفكارك إلى واقع.',
      storyP3: 'من مختبرنا إلى العالم — لنبتكر معًا شيئًا عظيمًا.',
      timeline: [
        { year: '2014', event: 'التأسيس في الصين' },
        { year: '2019', event: 'الدخول الرسمي للسوق الكورية' },
        { year: '2020', event: 'شراكات أولية مع شركات كورية' },
        { year: '2021', event: 'شراكة مع مصنعي السائل الإلكتروني البريطانيين' },
        { year: '2022', event: 'أكبر مورد نكهات في السوق الكورية' },
        { year: '2025', event: 'تغطية كوريا والمملكة المتحدة وأمريكا — 100+ نكهة' },
      ],
      valuesTag: 'قيمنا',
      valuesTitle: 'ما نؤمن به',
      values: [
        { title: 'جودة معتمدة ISO', description: 'تضمن منشآتنا المعتمدة بمعايير ISO اختبار كل دفعة بصرامة لتحقيق جودة ثابتة.' },
        { title: 'دعم البحث والتطوير المخصص', description: 'من المفهوم إلى المنتج النهائي، يعمل فريق البحث والتطوير لدينا معك لصياغة تركيبات نكهة مخصصة.' },
        { title: 'وصول عالمي', description: 'موثوق به من قبل أبرز العلامات التجارية الدولية في كوريا الجنوبية والمملكة المتحدة والولايات المتحدة.' },
        { title: 'شراكات جامعية', description: 'تعاون استراتيجي مع جامعات رائدة لتحويل أحدث الأبحاث إلى ابتكارات رائدة في السوق.' },
      ],
      rdTag: 'تجربة البحث والتطوير الميداني',
      rdTitle: 'علامتك التجارية، تولد في مختبرنا',
      rdDesc: 'النكهة الرائعة أكثر من مجرد كيمياء — إنها تعبير عن هوية علامتك التجارية. لهذا نفتح أبوابنا للعملاء، ندعوكم للقدوم إلى مركز البحث والتطوير لدينا والمشاركة في الإبداع جنبًا إلى جنب مع خبراء النكهات لدينا.',
      rdFeatures: [
        {
          icon: 'flask',
          title: 'ورش عمل نكهات مخصصة',
          description: 'يُرحَّب بالعملاء لزيارة منشأة البحث والتطوير لدينا والعمل مباشرة مع كبار خبراء النكهات. من المفهوم الأولي إلى الموافقة النهائية، كل قرار بيدك.',
        },
        {
          icon: 'microscope',
          title: 'فريق خبراء النكهات',
          description: 'يجمع خبراؤنا بين الخبرة العميقة في كيمياء النكهات والحدس الإبداعي الحاد. لا يصيغون فحسب — بل يستمعون ويفسرون ويبتكرون تجارب حسية تعبر عن علامتك.',
        },
        {
          icon: 'star',
          title: 'تخصيص كامل للعلامة التجارية',
          description: 'سواء كنت تبحث عن انفجار فواكه منعش أو لمسة حلوى غنية أو نكهة تبغ ناعمة، نصمم كل ملف تعريف ليتوافق بدقة مع موقع علامتك التجارية.',
        },
      ],
      rdCta: 'احجز استشارة ميدانية',
    },
    ru: {
      heroTitle: 'Премиальный дом вкусов\nиз Китая',
      heroDesc: 'Основаны в Китае. Совершенствуемся 20 лет. Крупнейший поставщик вкусов для жидкостей в Южной Корее — и надёжный источник для ведущих мировых брендов.',
      storyTag: 'Наша история',
      storyTitle: 'Мы не просто поставщик — мы источник',
      storyP1: 'PuriCore — премиальный дом вкусов из Китая с 20-летним опытом работы. Являясь крупнейшим поставщиком вкусов для жидкостей в Южной Корее, мы гордимся тем, что служим основным источником для ведущих мировых брендов вейпинга. Наши объекты с сертификацией ISO гарантируют соответствие каждой капли высочайшим стандартам.',
      storyP2: 'Но мы больше, чем просто поставщик — мы источник. Нужна ли вам разработка индивидуального вкуса или полная поддержка НИОКР, наша команда тесно сотрудничает с вами, чтобы воплотить ваши идеи в жизнь.',
      storyP3: 'Из нашей лаборатории — в мир. Давайте вместе создадим что-то великое.',
      timeline: [
        { year: '2014', event: 'Основана в Китае' },
        { year: '2019', event: 'Официальный выход на рынок Южной Кореи' },
        { year: '2020', event: 'Первые партнёрства с корейскими компаниями' },
        { year: '2021', event: 'Партнёрство с британскими производителями' },
        { year: '2022', event: 'Ведущий поставщик вкусов в Корее' },
        { year: '2025', event: 'Корея, Великобритания, США и другие — 100+ вкусов' },
      ],
      valuesTag: 'Наши ценности',
      valuesTitle: 'Наши принципы',
      values: [
        { title: 'Качество ISO', description: 'Наши объекты с сертификацией ISO обеспечивают строгое тестирование каждой партии для стабильного качества.' },
        { title: 'Поддержка НИОКР', description: 'От концепции до готового продукта — наша команда работает с вами для создания индивидуальных формул.' },
        { title: 'Глобальный охват', description: 'Доверие ведущих международных брендов в Южной Корее, Великобритании, США и других странах.' },
        { title: 'Университетские партнёрства', description: 'Стратегическое сотрудничество с ведущими университетами для превращения исследований в инновации.' },
      ],
      rdTag: 'Выездной R&D-опыт',
      rdTitle: 'Ваш бренд рождается в нашей лаборатории',
      rdDesc: 'Великий вкус — это больше, чем химия. Это выражение идентичности вашего бренда. Именно поэтому мы открываем двери нашего R&D-центра для клиентов, приглашая вас лично участвовать в создании вкусов вместе с нашими мастерами-флейвористами.',
      rdFeatures: [
        {
          icon: 'flask',
          title: 'Индивидуальные мастерские вкусов',
          description: 'Клиенты могут посетить наш R&D-центр и работать напрямую с нашими старшими флейвористами. От первоначальной концепции до финального утверждения — каждое решение принимаете вы.',
        },
        {
          icon: 'microscope',
          title: 'Команда мастеров-флейвористов',
          description: 'Наши флейвористы сочетают глубокую экспертизу в химии ароматов с острым творческим чутьём. Они не просто создают формулы — они слушают, интерпретируют и создают сенсорные впечатления.',
        },
        {
          icon: 'star',
          title: 'Полная кастомизация бренда',
          description: 'Будь то свежий фруктовый взрыв, насыщенный десертный финиш или мягкий табачный оттенок — мы разрабатываем каждый профиль в точном соответствии с позиционированием вашего бренда.',
        },
      ],
      rdCta: 'Записаться на консультацию',
    },
    ko: {
      heroTitle: '중국에 본사를 둔\n프리미엄 향미 하우스',
      heroDesc: '중국에 뿌리를 두고 20년간 쌓아온 전문성. 한국 최대 전자담배 액상 향미 공급업체 — 세계 최고 브랜드들이 신뢰하는 원천.',
      storyTag: '우리의 이야기',
      storyTitle: '우리는 단순한 공급업체가 아닙니다 — 우리는 원천입니다',
      storyP1: 'PuriCore는 중국에 본사를 둔 프리미엄 향미 하우스로, 업계에서 20년의 경험을 쌓아왔습니다. 한국 시장 최대 전자담배 액상 향미 공급업체로서, 세계 유수의 베이프 브랜드와 전자담배 액상 생산업체들의 핵심 파트너임을 자랑스럽게 생각합니다. ISO 인증 시설은 모든 제품이 최고 기준을 충족하도록 보장합니다.',
      storyP2: '우리는 단순한 공급업체 이상입니다 — 우리는 원천입니다. 맞춤형 향미 개발이든 완전한 R&D 지원이든, 우리 팀은 여러분의 아이디어를 현실로 만들기 위해 긴밀히 협력합니다.',
      storyP3: '우리 연구실에서 세계로 — 함께 위대한 것을 만들어 봅시다.',
      timeline: [
        { year: '2014', event: '중국에서 설립' },
        { year: '2019', event: '한국 시장 공식 진출' },
        { year: '2020', event: '한국 기업과 초기 파트너십 체결' },
        { year: '2021', event: '영국 전자담배 제조업체와 협력' },
        { year: '2022', event: '한국 시장 최대 액상 향미 공급업체' },
        { year: '2025', event: '한국, 영국, 미국 등 커버 — 100가지+ 향미' },
      ],
      valuesTag: '우리의 가치',
      valuesTitle: '우리가 지향하는 것',
      values: [
        { title: 'ISO 인증 품질', description: 'ISO 인증 시설에서 모든 배치를 엄격히 테스트하여 일관된 품질을 보장합니다.' },
        { title: '맞춤형 R&D 지원', description: '개념부터 완제품까지, R&D 팀이 함께 맞춤형 향미 공식을 개발합니다.' },
        { title: '글로벌 시장 도달', description: '한국, 영국, 미국 등 세계 유수 브랜드들이 신뢰하는 파트너.' },
        { title: '대학 파트너십', description: '주요 대학과의 전략적 협력으로 최신 연구를 시장 선도 혁신으로 전환합니다.' },
      ],
      rdTag: '현장 R&D 경험',
      rdTitle: '당신의 브랜드, 우리 연구실에서 탄생합니다',
      rdDesc: '훌륭한 향미는 단순한 화학 이상입니다 — 그것은 브랜드 정체성의 표현입니다. 그래서 우리는 고객에게 문을 열고, R&D 센터를 직접 방문하여 마스터 플레이버리스트와 함께 향미를 공동 창작하도록 초대합니다.',
      rdFeatures: [
        {
          icon: 'flask',
          title: '전용 향미 워크숍',
          description: '고객은 저희 R&D 시설을 방문하여 시니어 플레이버리스트와 직접 협력할 수 있습니다. 초기 개념부터 최종 승인까지, 모든 결정은 고객의 손에 있습니다.',
        },
        {
          icon: 'microscope',
          title: '마스터 플레이버리스트 팀',
          description: '저희 플레이버리스트들은 향미 화학에 대한 깊은 전문성과 예리한 창의적 직관을 결합합니다. 단순히 공식을 만드는 것이 아니라, 브랜드를 대변하는 감각적 경험을 창조합니다.',
        },
        {
          icon: 'star',
          title: '완전한 브랜드 커스터마이징',
          description: '상쾌한 과일 향, 풍부한 디저트 마무리, 부드러운 담배 향 — 어떤 것이든 브랜드 포지셔닝에 정확히 맞는 프로파일을 설계합니다.',
        },
      ],
      rdCta: '현장 상담 예약',
    },
  };

  const c = content[language as keyof typeof content] || content.zh;

  const valueIcons = [Shield, Globe, Users, FlaskConical];
  const valueColors = ['text-blue-400', 'text-emerald-400', 'text-orange-400', 'text-purple-400'];
  const valueBgs = ['bg-blue-500/10', 'bg-emerald-500/10', 'bg-orange-500/10', 'bg-purple-500/10'];

  const rdIcons = { flask: FlaskConical, microscope: Microscope, star: Star };
  const rdColors = ['text-orange-400', 'text-blue-400', 'text-emerald-400'];
  const rdBgs = ['bg-orange-500/10', 'bg-blue-500/10', 'bg-emerald-500/10'];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <img src={STATS_BG} alt="" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-[oklch(0.12_0.03_240/0.85)]" />
        </div>
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-4">
              {t.nav.about}
            </p>
            <h1 className="text-6xl font-bold text-white mb-6 whitespace-pre-line" style={{ fontFamily: 'Syne, sans-serif' }}>
              {c.heroTitle.split('\n')[0]}<br />
              <span className="text-gradient">{c.heroTitle.split('\n')[1]}</span>
            </h1>
            <p className="text-white/60 text-xl leading-relaxed">
              {c.heroDesc}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-4">{c.storyTag}</p>
              <h2 className="text-4xl font-bold text-white mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
                {c.storyTitle}
              </h2>
              <div className="space-y-4 text-white/60 leading-relaxed">
                <p>{c.storyP1}</p>
                <p>{c.storyP2}</p>
                <p className="text-orange-300 font-medium italic">{c.storyP3}</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="grid grid-cols-2 gap-4"
            >
              {c.timeline.map((item) => (
                <div
                  key={item.year}
                  className="p-4 rounded-xl"
                  style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
                >
                  <div className="text-orange-400 font-bold text-lg mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>
                    {item.year}
                  </div>
                  <div className="text-white/60 text-sm">{item.event}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-[oklch(0.14_0.03_240)]">
        <div className="container">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <motion.div variants={itemVariants} className="text-center mb-12">
              <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-3">{c.valuesTag}</p>
              <h2 className="text-4xl font-bold text-white" style={{ fontFamily: 'Syne, sans-serif' }}>
                {c.valuesTitle}
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {c.values.map((value, idx) => {
                const Icon = valueIcons[idx];
                return (
                  <motion.div
                    key={value.title}
                    variants={itemVariants}
                    whileHover={{ y: -6 }}
                    className="p-6 rounded-2xl"
                    style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
                  >
                    <div className={`w-12 h-12 rounded-xl ${valueBgs[idx]} flex items-center justify-center mb-4`}>
                      <Icon className={valueColors[idx]} size={22} />
                    </div>
                    <h3 className="text-white font-bold text-lg mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
                      {value.title}
                    </h3>
                    <p className="text-white/50 text-sm leading-relaxed">{value.description}</p>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>

      {/* On-Site R&D Service */}
      <section className="py-24 relative overflow-hidden">
        {/* Decorative background */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-orange-500/5 blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full bg-blue-500/5 blur-3xl" />
        </div>

        <div className="container relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            {/* Section header */}
            <motion.div variants={itemVariants} className="max-w-3xl mb-16">
              <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-4">{c.rdTag}</p>
              <h2 className="text-5xl font-bold text-white mb-6 leading-tight" style={{ fontFamily: 'Syne, sans-serif' }}>
                {c.rdTitle}
              </h2>
              <p className="text-white/60 text-lg leading-relaxed">
                {c.rdDesc}
              </p>
            </motion.div>

            {/* Feature cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {c.rdFeatures.map((feature, idx) => {
                const Icon = rdIcons[feature.icon as keyof typeof rdIcons];
                return (
                  <motion.div
                    key={feature.title}
                    variants={itemVariants}
                    whileHover={{ y: -8, scale: 1.02 }}
                    className="p-8 rounded-3xl relative overflow-hidden group"
                    style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
                  >
                    {/* Hover glow */}
                    <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${rdBgs[idx]} blur-xl`} />

                    <div className="relative z-10">
                      <div className={`w-14 h-14 rounded-2xl ${rdBgs[idx]} flex items-center justify-center mb-6`}>
                        <Icon className={rdColors[idx]} size={26} />
                      </div>
                      <h3 className="text-white font-bold text-xl mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
                        {feature.title}
                      </h3>
                      <p className="text-white/55 text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* CTA */}
            <motion.div variants={itemVariants} className="flex justify-center">
              <motion.a
                href="/contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                className="inline-flex items-center gap-3 px-10 py-4 rounded-full bg-gradient-to-r from-orange-500 to-amber-400 text-white font-bold text-lg shadow-2xl hover:shadow-orange-500/40 transition-all"
              >
                <FlaskConical size={20} />
                {c.rdCta}
              </motion.a>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
