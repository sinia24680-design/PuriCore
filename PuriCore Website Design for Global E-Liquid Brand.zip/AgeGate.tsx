// PuriCore Age Gate — "Tropical Drift" design
import { motion } from 'framer-motion';
import { Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import PuriCoreLogo from '@/components/PuriCoreLogo';

interface AgeGateProps {
  onConfirm: () => void;
  onDeny: () => void;
}

export default function AgeGate({ onConfirm, onDeny }: AgeGateProps) {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{
        background: 'linear-gradient(135deg, oklch(0.10 0.02 38) 0%, oklch(0.08 0.015 35) 100%)',
      }}
    >
      {/* Background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-1/4 left-1/4 w-96 h-96 opacity-10 blob-shape"
          style={{ background: 'oklch(0.76 0.12 75)' }}
        />
        <div
          className="absolute bottom-1/4 right-1/4 w-64 h-64 opacity-10 blob-shape"
          style={{ background: 'oklch(0.68 0.24 42)', animationDelay: '3s' }}
        />
      </div>

      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ delay: 0.2, type: 'spring', stiffness: 300, damping: 25 }}
        className="relative glass-card rounded-2xl p-8 max-w-md w-full mx-4 text-center"
      >
        {/* Logo */}
        <div className="flex items-center justify-center mb-6">
          <div className="gold-glow">
            <PuriCoreLogo size={60} showText={true} showTagline={false} />
          </div>
        </div>

        {/* Shield Icon */}
        <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-5" style={{ background: 'oklch(0.76 0.12 75 / 0.12)', border: '1px solid oklch(0.76 0.12 75 / 0.25)' }}>
          <Shield style={{ color: 'oklch(0.76 0.12 75)' }} size={28} />
        </div>

        <h2 className="text-2xl font-bold text-white mb-3">{t.ageGate.title}</h2>
        <p className="text-white/60 text-sm leading-relaxed mb-2">{t.ageGate.subtitle}</p>
        <p className="text-white/40 text-xs mb-8">{t.ageGate.warning}</p>

        <div className="flex gap-3">
          <button
            onClick={onDeny}
            className="flex-1 py-3 rounded-xl border border-white/10 text-white/60 hover:bg-white/5 hover:text-white transition-all text-sm font-medium"
          >
            {t.ageGate.no}
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-3 rounded-xl text-white font-semibold transition-all shadow-lg text-sm"
            style={{ background: 'linear-gradient(135deg, oklch(0.68 0.24 42), oklch(0.76 0.12 75))' }}
          >
            {t.ageGate.yes}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
