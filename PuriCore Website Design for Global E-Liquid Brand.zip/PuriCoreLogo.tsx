// PuriCore Logo — uses the actual brand identity image (waterdrop + PC lettermark)
// Cropped directly from the official brand reference image
// CDN URL: https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-logo-icon_50adabc0.png

const LOGO_ICON_URL =
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663419893423/AahNXat3ACD4MVYQgKXXq4/puricore-logo-icon_50adabc0.png';

interface PuriCoreLogoProps {
  size?: number;
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
}

export default function PuriCoreLogo({
  size = 40,
  showText = true,
  showTagline = false,
  className = '',
}: PuriCoreLogoProps) {
  return (
    <div
      className={`inline-flex flex-col items-center ${className}`}
      style={{ gap: `${Math.round(size * 0.04)}px`, lineHeight: 1 }}
    >
      {/* Actual brand logo icon image */}
      <img
        src={LOGO_ICON_URL}
        alt="PuriCore logo"
        width={size}
        height={size}
        style={{
          width: `${size}px`,
          height: `${size}px`,
          objectFit: 'contain',
          display: 'block',
          filter: 'drop-shadow(0 0 4px rgba(212, 168, 67, 0.35))',
        }}
      />

      {/* PuriCore wordmark */}
      {showText && (
        <span
          style={{
            fontFamily: "'Cormorant Garamond', 'Playfair Display', 'Times New Roman', Georgia, serif",
            fontSize: `${Math.round(size * 0.54)}px`,
            fontWeight: 600,
            letterSpacing: '0.06em',
            background: 'linear-gradient(135deg, #F5D78E 0%, #C9A84C 35%, #E8C96A 65%, #A87B2F 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            display: 'block',
            textAlign: 'center',
            whiteSpace: 'nowrap',
          }}
        >
          PuriCore
        </span>
      )}

      {showTagline && (
        <span
          style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: `${Math.round(size * 0.14)}px`,
            fontWeight: 500,
            letterSpacing: '0.22em',
            color: 'oklch(0.76 0.12 75 / 0.55)',
            textTransform: 'uppercase',
            textAlign: 'center',
            display: 'block',
            whiteSpace: 'nowrap',
          }}
        >
          Essence of Food
        </span>
      )}
    </div>
  );
}
