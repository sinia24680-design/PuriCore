import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { useState, useEffect } from "react";
import Home from "./pages/Home";
import Products from "./pages/Products";
import FlavorDetail from "./pages/FlavorDetail";
import Flavors from "./pages/Flavors";
import CaseStudies from "./pages/CaseStudies";

import About from "./pages/About";
import Contact from "./pages/Contact";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AgeGate from "./components/AgeGate";
import WhatsAppButton from "./components/WhatsAppButton";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-[oklch(0.12_0.03_240)]">
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/products" component={Products} />
        <Route path="/flavors" component={Flavors} />
        <Route path="/flavors/:id" component={FlavorDetail} />
        <Route path="/case-studies" component={CaseStudies} />
        <Route path="/about" component={About} />
        <Route path="/contact" component={Contact} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  const [ageVerified, setAgeVerified] = useState<boolean>(() => {
    return localStorage.getItem('puricore-age-verified') === 'true';
  });

  const handleAgeConfirm = () => {
    localStorage.setItem('puricore-age-verified', 'true');
    setAgeVerified(true);
  };

  const handleAgeDeny = () => {
    window.location.href = 'https://www.google.com';
  };

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <LanguageProvider>
          <TooltipProvider>
            <Toaster richColors position="top-right" />
            {!ageVerified ? (
              <AgeGate onConfirm={handleAgeConfirm} onDeny={handleAgeDeny} />
            ) : (
              <Router />
            )}
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
