// PuriCore i18n — Chinese, English, Arabic, Russian, Korean
// RTL support: Arabic requires dir="rtl"

export type Language = 'zh' | 'en' | 'ar' | 'ru' | 'ko';

export interface Translations {
  // Navigation
  nav: {
    home: string;
    products: string;
    flavors: string;
    caseStudies: string;
    blog: string;
    about: string;
    contact: string;
    shopNow: string;
  };
  // Hero
  hero: {
    tagline: string;
    subtitle: string;
    exploreBtn: string;
    watchVideo: string;
    badge: string;
  };
  // Categories
  categories: {
    all: string;
    fruit: string;
    dessert: string;
    tobacco: string;
    drink: string;
    fruitDesc: string;
    dessertDesc: string;
    tobaccoDesc: string;
    drinkDesc: string;
  };
  // Products
  products: {
    title: string;
    subtitle: string;
    featured: string;
    viewAll: string;
    addToCart: string;
    learnMore: string;
    nicotine: string;
    vgPg: string;
    intensity: string;
    flavorNotes: string;
    compare: string;
    compareTitle: string;
    selectProduct: string;
    vs: string;
  };
  // Stats
  stats: {
    title: string;
    flavors: string;
    flavorsLabel: string;
    countries: string;
    countriesLabel: string;
    customers: string;
    customersLabel: string;
    awards: string;
    awardsLabel: string;
  };
  // Case Studies
  caseStudies: {
    title: string;
    subtitle: string;
    readMore: string;
    close: string;
    challenge: string;
    solution: string;
    result: string;
  };
  // Blog
  blog: {
    title: string;
    subtitle: string;
    readMore: string;
    by: string;
    minRead: string;
    categories: {
      all: string;
      industry: string;
      flavors: string;
      lifestyle: string;
      science: string;
    };
  };
  // Footer
  footer: {
    tagline: string;
    products: string;
    company: string;
    legal: string;
    followUs: string;
    newsletter: string;
    newsletterPlaceholder: string;
    subscribe: string;
    rights: string;
    warning: string;
  };
  // Age Gate
  ageGate: {
    title: string;
    subtitle: string;
    yes: string;
    no: string;
    warning: string;
  };
  // Language names
  languages: {
    zh: string;
    en: string;
    ar: string;
    ru: string;
    ko: string;
  };
}

export const translations: Record<Language, Translations> = {
  zh: {
    nav: {
      home: '首页',
      products: '产品',
      flavors: '口味',
      caseStudies: '案例研究',
      blog: '博客',
      about: '关于我们',
      contact: '联系我们',
      shopNow: '立即购买',
    },
    hero: {
      tagline: '世界顶级电子烟油口味',
      subtitle: '精工细作，灵感源自世界。体验 PuriCore 的顶级电子烟油。',
      exploreBtn: '探索口味',
      watchVideo: '观看视频',
      badge: '顶级品质',
    },
    categories: {
      all: '全部口味',
      fruit: '水果',
      dessert: '甜品',
      tobacco: '烟草',
      drink: '饮料',
      fruitDesc: '新鲜热带水果与浆果混合',
      dessertDesc: '醇厚甜蜜的甜品创作',
      tobaccoDesc: '经典精致的烟草口味',
      drinkDesc: '清爽饮品与茶饮口味',
    },
    products: {
      title: '我们的口味',
      subtitle: '探索我们精心调配的顶级电子烟油系列',
      featured: '精选',
      viewAll: '查看全部',
      addToCart: '加入购物车',
      learnMore: '了解更多',
      nicotine: '尼古丁',
      vgPg: 'Product ID',
      intensity: '浓度',
      flavorNotes: '口味描述',
      compare: '对比',
      compareTitle: '口味对比',
      selectProduct: '选择口味',
      vs: 'VS',
    },
    stats: {
      title: '全球信赖之选',
      flavors: '20',
      flavorsLabel: '年行业经验',
      countries: '100+',
      countriesLabel: '款口味',
      customers: '3',
      customersLabel: '大洲市场覆盖',
      awards: '',
      awardsLabel: '',
    },
    caseStudies: {
      title: '成功案例',
      subtitle: '了解 PuriCore 如何在全球范围内改变电子烟体验',
      readMore: '阅读完整故事',
      close: '关闭',
      challenge: '面临挑战',
      solution: '我们的方案',
      result: '最终成果',
    },
    blog: {
      title: '洞见与资讯',
      subtitle: '关于口味、行业趋势和电子烟文化的专家观点',
      readMore: '阅读更多',
      by: '作者',
      minRead: '分钟阅读',
      categories: {
        all: '全部',
        industry: '行业',
        flavors: '口味',
        lifestyle: '生活方式',
        science: '科学',
      },
    },
    footer: {
      tagline: '为全球打造的顶级电子烟油口味。',
      products: '产品',
      company: '公司',
      legal: '法律信息',
      followUs: '关注我们',
      newsletter: '订阅资讯',
      newsletterPlaceholder: '输入您的邮箱',
      subscribe: '订阅',
      rights: '© 2025 PuriCore. 保留所有权利。',
      warning: '警告：本产品含有尼古丁。尼古丁是一种令人上瘾的化学物质。仅限成人使用。',
    },
    ageGate: {
      title: '年龄验证',
      subtitle: '您必须年满21岁才能进入本网站。您是否已达到法定年龄？',
      yes: '是的，我已满21岁',
      no: '否，退出',
      warning: '本网站包含有关烟草和尼古丁产品的内容。',
    },
    languages: {
      zh: '中文',
      en: 'English',
      ar: 'العربية',
      ru: 'Русский',
      ko: '한국어',
    },
  },

  en: {
    nav: {
      home: 'Home',
      products: 'Products',
      flavors: 'Flavors',
      caseStudies: 'Case Studies',
      blog: 'Blog',
      about: 'About',
      contact: 'Contact',
      shopNow: 'Shop Now',
    },
    hero: {
      tagline: "World's Finest E-Liquid Flavors",
      subtitle: 'Crafted with precision. Inspired by the world. Experience premium vaping with PuriCore.',
      exploreBtn: 'Explore Flavors',
      watchVideo: 'Watch Video',
      badge: 'Premium Quality',
    },
    categories: {
      all: 'All Flavors',
      fruit: 'Fruit',
      dessert: 'Dessert',
      tobacco: 'Tobacco',
      drink: 'Drinks',
      fruitDesc: 'Fresh tropical & berry blends',
      dessertDesc: 'Indulgent sweet creations',
      tobaccoDesc: 'Classic & refined tobacco',
      drinkDesc: 'Refreshing beverages & tea blends',
    },
    products: {
      title: 'Our Flavors',
      subtitle: 'Discover our carefully crafted collection of premium e-liquid flavors',
      featured: 'Featured',
      viewAll: 'View All',
      addToCart: 'Add to Cart',
      learnMore: 'Learn More',
      nicotine: 'Nicotine',
      vgPg: 'Product ID',
      intensity: 'Intensity',
      flavorNotes: 'Flavor Notes',
      compare: 'Compare',
      compareTitle: 'Compare Flavors',
      selectProduct: 'Select a flavor',
      vs: 'VS',
    },
    stats: {
      title: 'Trusted Worldwide',
      flavors: '20',
      flavorsLabel: 'Years of Expertise',
      countries: '100+',
      countriesLabel: 'Flavor Profiles',
      customers: '3',
      customersLabel: 'Continents Served',
      awards: '',
      awardsLabel: '',
    },
    caseStudies: {
      title: 'Success Stories',
      subtitle: 'See how PuriCore is transforming the vaping experience worldwide',
      readMore: 'Read Full Story',
      close: 'Close',
      challenge: 'The Challenge',
      solution: 'Our Solution',
      result: 'The Result',
    },
    blog: {
      title: 'Insights & News',
      subtitle: 'Expert perspectives on flavors, industry trends, and vaping culture',
      readMore: 'Read More',
      by: 'By',
      minRead: 'min read',
      categories: {
        all: 'All',
        industry: 'Industry',
        flavors: 'Flavors',
        lifestyle: 'Lifestyle',
        science: 'Science',
      },
    },
    footer: {
      tagline: 'Premium e-liquid flavors crafted for the world.',
      products: 'Products',
      company: 'Company',
      legal: 'Legal',
      followUs: 'Follow Us',
      newsletter: 'Stay Updated',
      newsletterPlaceholder: 'Enter your email',
      subscribe: 'Subscribe',
      rights: '© 2025 PuriCore. All rights reserved.',
      warning: 'WARNING: This product contains nicotine. Nicotine is an addictive chemical. For adults only.',
    },
    ageGate: {
      title: 'Age Verification',
      subtitle: 'You must be 21 or older to enter this site. Are you of legal age?',
      yes: 'Yes, I am 21+',
      no: 'No, Exit',
      warning: 'This site contains content about tobacco and nicotine products.',
    },
    languages: {
      zh: '中文',
      en: 'English',
      ar: 'العربية',
      ru: 'Русский',
      ko: '한국어',
    },
  },

  ar: {
    nav: {
      home: 'الرئيسية',
      products: 'المنتجات',
      flavors: 'النكهات',
      caseStudies: 'دراسات الحالة',
      blog: 'المدونة',
      about: 'من نحن',
      contact: 'اتصل بنا',
      shopNow: 'تسوق الآن',
    },
    hero: {
      tagline: 'أفضل نكهات السائل الإلكتروني في العالم',
      subtitle: 'مصنوعة بدقة. مستوحاة من العالم. اختبر التدخين الإلكتروني الفاخر مع بيوريكور.',
      exploreBtn: 'استكشف النكهات',
      watchVideo: 'شاهد الفيديو',
      badge: 'جودة ممتازة',
    },
    categories: {
      all: 'جميع النكهات',
      fruit: 'فواكه',
      dessert: 'حلويات',
      tobacco: 'تبغ',
      drink: 'مشروبات',
      fruitDesc: 'مزيج استوائي وتوت طازج',
      dessertDesc: 'إبداعات حلوة فاخرة',
      tobaccoDesc: 'تبغ كلاسيكي ومكرر',
      drinkDesc: 'مشروبات منعشة وخلطات الشاي',
    },
    products: {
      title: 'نكهاتنا',
      subtitle: 'اكتشف مجموعتنا المصممة بعناية من نكهات السائل الإلكتروني الفاخرة',
      featured: 'مميز',
      viewAll: 'عرض الكل',
      addToCart: 'أضف إلى السلة',
      learnMore: 'اعرف المزيد',
      nicotine: 'النيكوتين',
      vgPg: 'Product ID',
      intensity: 'الشدة',
      flavorNotes: 'ملاحظات النكهة',
      compare: 'قارن',
      compareTitle: 'قارن النكهات',
      selectProduct: 'اختر نكهة',
      vs: 'مقابل',
    },
    stats: {
      title: 'موثوق به عالمياً',
      flavors: '20',
      flavorsLabel: 'عاماً من الخبرة',
      countries: '+100',
      countriesLabel: 'نكهة متاحة',
      customers: '3',
      customersLabel: 'قارات نخدمها',
      awards: '',
      awardsLabel: '',
    },
    caseStudies: {
      title: 'قصص النجاح',
      subtitle: 'اكتشف كيف تحول بيوريكور تجربة التدخين الإلكتروني حول العالم',
      readMore: 'اقرأ القصة كاملة',
      close: 'إغلاق',
      challenge: 'التحدي',
      solution: 'حلنا',
      result: 'النتيجة',
    },
    blog: {
      title: 'رؤى وأخبار',
      subtitle: 'وجهات نظر خبراء حول النكهات واتجاهات الصناعة وثقافة التدخين الإلكتروني',
      readMore: 'اقرأ المزيد',
      by: 'بقلم',
      minRead: 'دقيقة قراءة',
      categories: {
        all: 'الكل',
        industry: 'الصناعة',
        flavors: 'النكهات',
        lifestyle: 'أسلوب الحياة',
        science: 'العلوم',
      },
    },
    footer: {
      tagline: 'نكهات سائل إلكتروني فاخرة مصنوعة للعالم.',
      products: 'المنتجات',
      company: 'الشركة',
      legal: 'قانوني',
      followUs: 'تابعنا',
      newsletter: 'ابق على اطلاع',
      newsletterPlaceholder: 'أدخل بريدك الإلكتروني',
      subscribe: 'اشترك',
      rights: '© 2025 بيوريكور. جميع الحقوق محفوظة.',
      warning: 'تحذير: يحتوي هذا المنتج على النيكوتين. النيكوتين مادة مسببة للإدمان. للبالغين فقط.',
    },
    ageGate: {
      title: 'التحقق من العمر',
      subtitle: 'يجب أن يكون عمرك 21 عامًا أو أكثر لدخول هذا الموقع. هل أنت في السن القانوني؟',
      yes: 'نعم، عمري 21+',
      no: 'لا، خروج',
      warning: 'يحتوي هذا الموقع على محتوى حول منتجات التبغ والنيكوتين.',
    },
    languages: {
      zh: '中文',
      en: 'English',
      ar: 'العربية',
      ru: 'Русский',
      ko: '한국어',
    },
  },

  ru: {
    nav: {
      home: 'Главная',
      products: 'Продукты',
      flavors: 'Вкусы',
      caseStudies: 'Кейсы',
      blog: 'Блог',
      about: 'О нас',
      contact: 'Контакты',
      shopNow: 'Купить',
    },
    hero: {
      tagline: 'Лучшие вкусы жидкостей для вейпа в мире',
      subtitle: 'Создано с точностью. Вдохновлено миром. Испытайте премиальный вейпинг с PuriCore.',
      exploreBtn: 'Исследовать вкусы',
      watchVideo: 'Смотреть видео',
      badge: 'Премиум качество',
    },
    categories: {
      all: 'Все вкусы',
      fruit: 'Фрукты',
      dessert: 'Десерты',
      tobacco: 'Табак',
      drink: 'Напитки',
      fruitDesc: 'Свежие тропические и ягодные смеси',
      dessertDesc: 'Изысканные сладкие творения',
      tobaccoDesc: 'Классический и утончённый табак',
      drinkDesc: 'Освежающие напитки и чайные смеси',
    },
    products: {
      title: 'Наши вкусы',
      subtitle: 'Откройте для себя нашу тщательно подобранную коллекцию премиальных жидкостей',
      featured: 'Рекомендуем',
      viewAll: 'Смотреть все',
      addToCart: 'В корзину',
      learnMore: 'Подробнее',
      nicotine: 'Никотин',
      vgPg: 'Product ID',
      intensity: 'Интенсивность',
      flavorNotes: 'Нотки вкуса',
      compare: 'Сравнить',
      compareTitle: 'Сравнить вкусы',
      selectProduct: 'Выберите вкус',
      vs: 'VS',
    },
    stats: {
      title: 'Доверие по всему миру',
      flavors: '20',
      flavorsLabel: 'Лет опыта',
      countries: '100+',
      countriesLabel: 'Вкусовых профилей',
      customers: '3',
      customersLabel: 'Континента охвата',
      awards: '',
      awardsLabel: '',
    },
    caseStudies: {
      title: 'Истории успеха',
      subtitle: 'Узнайте, как PuriCore меняет опыт вейпинга по всему миру',
      readMore: 'Читать полностью',
      close: 'Закрыть',
      challenge: 'Задача',
      solution: 'Наше решение',
      result: 'Результат',
    },
    blog: {
      title: 'Новости и аналитика',
      subtitle: 'Экспертные взгляды на вкусы, тенденции отрасли и культуру вейпинга',
      readMore: 'Читать далее',
      by: 'Автор',
      minRead: 'мин чтения',
      categories: {
        all: 'Все',
        industry: 'Индустрия',
        flavors: 'Вкусы',
        lifestyle: 'Стиль жизни',
        science: 'Наука',
      },
    },
    footer: {
      tagline: 'Премиальные жидкости для вейпа, созданные для всего мира.',
      products: 'Продукты',
      company: 'Компания',
      legal: 'Правовая информация',
      followUs: 'Следите за нами',
      newsletter: 'Будьте в курсе',
      newsletterPlaceholder: 'Введите email',
      subscribe: 'Подписаться',
      rights: '© 2025 PuriCore. Все права защищены.',
      warning: 'ПРЕДУПРЕЖДЕНИЕ: Этот продукт содержит никотин. Никотин — вызывающее привыкание химическое вещество. Только для взрослых.',
    },
    ageGate: {
      title: 'Проверка возраста',
      subtitle: 'Вам должно быть 21 год или больше для входа на этот сайт. Вы достигли совершеннолетия?',
      yes: 'Да, мне 21+',
      no: 'Нет, выйти',
      warning: 'Этот сайт содержит информацию о табачных и никотиновых продуктах.',
    },
    languages: {
      zh: '中文',
      en: 'English',
      ar: 'العربية',
      ru: 'Русский',
      ko: '한국어',
    },
  },

  ko: {
    nav: {
      home: '홈',
      products: '제품',
      flavors: '맛',
      caseStudies: '사례 연구',
      blog: '블로그',
      about: '회사 소개',
      contact: '문의',
      shopNow: '지금 구매',
    },
    hero: {
      tagline: '세계 최고의 전자담배 액상 맛',
      subtitle: '정밀하게 제조되었습니다. 세계에서 영감을 받았습니다. PuriCore로 프리미엄 베이핑을 경험하세요.',
      exploreBtn: '맛 탐색하기',
      watchVideo: '동영상 보기',
      badge: '프리미엄 품질',
    },
    categories: {
      all: '모든 맛',
      fruit: '과일',
      dessert: '디저트',
      tobacco: '담배',
      drink: '음료',
      fruitDesc: '신선한 열대 및 베리 블렌드',
      dessertDesc: '달콤한 디저트 창작물',
      tobaccoDesc: '클래식하고 세련된 담배',
      drinkDesc: '상쾌한 음료 및 차 블렌드',
    },
    products: {
      title: '우리의 맛',
      subtitle: '신중하게 제조된 프리미엄 전자담배 액상 컬렉션을 발견하세요',
      featured: '추천',
      viewAll: '전체 보기',
      addToCart: '장바구니에 추가',
      learnMore: '자세히 보기',
      nicotine: '니코틴',
      vgPg: 'Product ID',
      intensity: '강도',
      flavorNotes: '맛 노트',
      compare: '비교',
      compareTitle: '맛 비교',
      selectProduct: '맛 선택',
      vs: 'VS',
    },
    stats: {
      title: '전 세계에서 신뢰받는',
      flavors: '20',
      flavorsLabel: '년 업계 경험',
      countries: '100+',
      countriesLabel: '가지 향미',
      customers: '3',
      customersLabel: '개 대륙 시장',
      awards: '',
      awardsLabel: '',
    },
    caseStudies: {
      title: '성공 사례',
      subtitle: 'PuriCore가 전 세계 베이핑 경험을 어떻게 변화시키고 있는지 알아보세요',
      readMore: '전체 이야기 읽기',
      close: '닫기',
      challenge: '도전',
      solution: '우리의 해결책',
      result: '결과',
    },
    blog: {
      title: '인사이트 & 뉴스',
      subtitle: '맛, 업계 트렌드, 베이핑 문화에 대한 전문가 관점',
      readMore: '더 읽기',
      by: '작성자',
      minRead: '분 읽기',
      categories: {
        all: '전체',
        industry: '업계',
        flavors: '맛',
        lifestyle: '라이프스타일',
        science: '과학',
      },
    },
    footer: {
      tagline: '세계를 위해 제조된 프리미엄 전자담배 액상.',
      products: '제품',
      company: '회사',
      legal: '법적 고지',
      followUs: '팔로우',
      newsletter: '최신 정보 받기',
      newsletterPlaceholder: '이메일 입력',
      subscribe: '구독',
      rights: '© 2025 PuriCore. 모든 권리 보유.',
      warning: '경고: 이 제품에는 니코틴이 포함되어 있습니다. 니코틴은 중독성 화학 물질입니다. 성인 전용.',
    },
    ageGate: {
      title: '나이 확인',
      subtitle: '이 사이트에 입장하려면 21세 이상이어야 합니다. 법적 나이가 되셨나요?',
      yes: '예, 21세 이상입니다',
      no: '아니오, 나가기',
      warning: '이 사이트에는 담배 및 니코틴 제품에 관한 내용이 포함되어 있습니다.',
    },
    languages: {
      zh: '中文',
      en: 'English',
      ar: 'العربية',
      ru: 'Русский',
      ko: '한국어',
    },
  },
};

export const rtlLanguages: Language[] = ['ar'];

export function isRTL(lang: Language): boolean {
  return rtlLanguages.includes(lang);
}
