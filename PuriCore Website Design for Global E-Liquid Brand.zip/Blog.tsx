              </div>
            </div>
          </div>
        </motion.div>
      </Link>
    );
  }

  return (
    <Link href={`/blog/${post.id}`}>
      <motion.div
        whileHover={{ y: -6 }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className="rounded-2xl overflow-hidden cursor-pointer group h-full flex flex-col"
        style={{ background: 'oklch(0.16 0.03 240)', border: '1px solid oklch(1 0 0 / 0.08)' }}
      >
        {/* Image */}
        <div className="relative h-48 overflow-hidden">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.16_0.03_240/0.7)] to-transparent" />
          <div className="absolute top-3 left-3">
            <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${categoryColors[post.category]}`}>
              {t.blog.categories[post.category]}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col flex-1">
          <div className="flex items-center gap-2 mb-3 text-white/30 text-xs">
            <Clock size={12} />
            <span>{post.readTime} {t.blog.minRead}</span>
            <span>•</span>
            <span>{post.date}</span>
          </div>

          <h3 className="text-white font-bold text-base mb-2 group-hover:text-orange-300 transition-colors leading-snug"
            style={{ fontFamily: 'Syne, sans-serif' }}>
            {post.title}
          </h3>

          <p className="text-white/50 text-sm leading-relaxed mb-4 line-clamp-2 flex-1">
            {post.excerpt}
          </p>

          {/* Author */}
          <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <div className="flex items-center gap-2">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="w-7 h-7 rounded-full object-cover border border-orange-500/30"
              />
              <div>
                <p className="text-white text-xs font-medium">{post.author.name}</p>
              </div>
            </div>
            <span className="text-orange-400 text-xs font-medium flex items-center gap-1">
              {t.blog.readMore}
              <ArrowRight size={12} />
            </span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export default function Blog() {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<BlogCategory>('all');

  const categories: { id: BlogCategory; label: string }[] = [
    { id: 'all', label: t.blog.categories.all },
    { id: 'industry', label: t.blog.categories.industry },
    { id: 'flavors', label: t.blog.categories.flavors },
    { id: 'lifestyle', label: t.blog.categories.lifestyle },
    { id: 'science', label: t.blog.categories.science },
  ];

  const filteredPosts = blogPosts.filter(
    (p) => activeCategory === 'all' || p.category === activeCategory
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <p className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-2">
            {t.blog.title}
          </p>
          <h1 className="text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            {t.blog.title}
          </h1>
          <p className="text-white/50 text-lg max-w-2xl">{t.blog.subtitle}</p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}